# 低压服务助手框架搭建设计文档

## 1. 项目概述

### 1.1 背景
基于低压服务助手原型（Vue2 + Vite + TypeScript）源码，参考 `plugin-igw-customer-label` 项目结构，进行框架搭建和代码迁移。

### 1.2 目标
- 建立符合企业标准的 Vue2 + Vue CLI + JavaScript 项目框架
- 支持混合模式：既可打包为插件库，也可独立部署为应用
- 迁移原型全部6个功能模块的页面
- 保持与 IGW 平台的集成能力

### 1.3 技术选型
| 项目 | 选择 | 说明 |
|------|------|------|
| 构建工具 | Vue CLI | 与参考项目一致，自动打包zip |
| 代码语言 | JavaScript | 与参考项目一致，稳定成熟 |
| UI框架 | Vant 2.x | 移动端组件库 |
| 状态管理 | Vuex 3.x | Vue2配套版本 |
| 路由 | Vue Router 3.x | Vue2配套版本 |
| 样式 | LESS | 支持变量和混入 |
| px转rem | postcss-pxtorem | rootValue: 37.5 |

---

## 2. 项目架构

### 2.1 混合模式结构

```
plugin-lowvoltage-assistant/
├── packages/                    # 库源码（用于打包插件）
│   ├── api/                     # API层
│   │   ├── index.js             # 统一请求入口
│   │   └── const.js             # API定义
│   ├── assets/                  # 库资源
│   │   ├── images/              # 图片资源
│   │   ├── less/                # LESS样式
│   │   └── style/               # 其他样式
│   ├── components/              # 共享组件
│   ├── config/                  # 配置
│   │   ├── const.js             # 常量定义
│   │   └── igw-config.js        # IGW平台配置
│   ├── utils/                   # 工具函数
│   │   ├── index.js
│   │   ├── toast.js
│   │   ├── dialog.js
│   │   ├── storage.js
│   │   └── camelCase.js
│   ├── views/                   # 页面组件
│   │   ├── home/
│   │   ├── user-query/
│   │   ├── engineer/
│   │   ├── panorama/
│   │   ├── register/
│   │   ├── workbench/
│   │   └── lowvoltagePlugin.vue # 主插件入口
│   └── index.js                 # 库导出
├── src/                         # 应用入口（开发调试）
│   ├── api/
│   ├── assets/
│   ├── components/
│   ├── config/
│   ├── libs/                    # 编译后的库文件
│   ├── router/
│   │   ├── index.js
│   │   └── modules/
│   │       ├── home.route.js
│   │       ├── user-query.route.js
│   │       ├── engineer.route.js
│   │       ├── panorama.route.js
│   │       ├── register.route.js
│   │       └── workbench.route.js
│   ├── store/
│   │   ├── index.js
│   │   ├── getters.js
│   │   └── modules/
│   │       ├── app.js
│   │       ├── user.js
│   │       ├── workorder.js
│   │       ├── schedule.js
│   │       └── common.js
│   ├── utils/
│   ├── views/                   # 开发用页面（可选）
│   ├── App.vue
│   └── main.js
├── public/
│   └── index.html
├── dist_zip/                    # 自动打包输出
├── .env.dev
├── .env.uat
├── .env.prod
├── .env.site-prod
├── package.json
├── vue.config.js
├── babel.config.js
├── jsconfig.json
└── CLAUDE.md
```

### 2.2 路径别名
- `@` → `src/`
- `#` → `packages/`

---

## 3. 核心模块设计

### 3.1 API层设计

**api/index.js**：
```javascript
import { callRestful } from '@utils/vegeta-base'
import apiList from './const'

const request = (api, body, headers = {}, config = {}) => {
  return callRestful(api, { body, headers, config })
}

window.$Api = { request }
export default { request }
```

**api/const.js** - API定义模式：
```javascript
export const queryUserList = {
  code: "EMSS_xxxxx",
  srvCode: "EMSS_xxxxx",
  type: "rest"
}
```

### 3.2 路由模块设计

**router/index.js** - 自动加载路由模块：
```javascript
const routeList = () => {
  let list = []
  const routerModules = require.context('./modules', true, /\.route\.js/)
  routerModules.keys().forEach((key) => {
    list = list.concat(routerModules(key).default)
  })
  return list
}
```

**路由模块示例**（router/modules/*.route.js）：
```javascript
export default [
  {
    path: "/home",
    name: "home",
    component: () => import('@/views/home'),
    meta: {
      title: '首页',
      keepAlive: true
    }
  },
]
```

### 3.3 Store模块设计

**store/index.js**：
```javascript
import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import user from './modules/user'
import workorder from './modules/workorder'
import schedule from './modules/schedule'
import common from './modules/common'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: { app, user, workorder, schedule, common },
  getters: {}
})
```

---

## 4. 共享组件设计

### 4.1 组件列表

| 组件名 | 用途 | Props |
|--------|------|-------|
| container-view.vue | 页面容器（导航栏+内容区） | title, leftArrow, closeWindow |
| empty-view.vue | 空状态展示 | description, image |
| cell-item.vue | 标签-值展示项 | name, value, unit, fontSize |
| button-view.vue | 双按钮布局 | leftStr, rightStr, clickLeft, clickRight |
| field-item.vue | 多类型字段 | type(text/picker/switch/radio), label, required |
| status-tag.vue | 状态标签 | status, color |
| info-card.vue | 信息卡片 | title, data |
| filter-panel.vue | 筛选面板 | filters, onFilter |
| timeline-item.vue | 时间线项 | time, content |

### 4.2 组件自动注册

**components/index.js**：
```javascript
let components = []
const componentList = require.context(".", true, /\.vue$/)
componentList.keys().forEach((val) => {
  const value = componentList(val)
  components.push(value.default)
})

const install = (vue) => {
  if (install.installed) return
  components.forEach((component) => {
    vue.component(component.name, component)
  })
}

export default { install }
```

---

## 5. 样式系统设计

### 5.1 LESS文件结构

```
assets/less/
├── var.less             # 全局变量
├── mixin.less           # 混入
├── border.less          # 1px边框
├── reset.less           # 样式重置
├── default.less         # 默认样式
└── index.less           # 入口
```

### 5.2 关键混入

**Flex布局**：
```less
.flex-center()    // 居中布局
.flex-between()   // 两端对齐
.flex-align()     // 垂直居中
.flex-justify()   // 水平居中
```

**文本溢出**：
```less
.overflow()                     // 单行溢出
.overflow-multiline(@line:1)    // N行溢出
```

**1px边框**（高清屏适配）：
```less
.veg-hairline(@color, @radius)
.veg-hairline-top(@color, @radius)
.veg-hairline-bottom(@color, @radius)
```

### 5.3 颜色变量

```less
// 基础色
@black: #000;
@white: #fff;
@gray-1: #f7f8fa;
@blue: #1989fa;
@green: #07c160;
@red: #ee0a24;

// Vant主题色（CSS变量）
@van-color-primary: var(--van-color-primary);
@van-color-danger: var(--van-color-danger);
@van-color-success: var(--van-color-success);

// 渐变
@gradient-button: linear-gradient(270deg, #0ca2ef 1%, #15b9f6 97%);
```

---

## 6. 工具函数设计

### 6.1 Toast工具

```javascript
window.$toast = {
  show(message),       // 显示提示
  loading(message),    // 显示加载
  hidden(),            // 隐藏
  clear()              // 清除所有
}

// 使用
$toast.loading()
await fetchData()
$toast.clear()
```

### 6.2 Dialog工具

```javascript
window.$dialog = {
  alert(message, title),    // 提示弹窗
  confirm(message, title)   // 确认弹窗
}

// 使用
await $dialog.alert('操作成功')
const confirmed = await $dialog.confirm('确定删除吗？')
```

### 6.3 Storage工具

```javascript
// 存储（自动转JSON）
setStorage(key, value)

// 获取（自动解析）
getStorage(key)
```

---

## 7. 页面模块设计

### 7.1 首页模块
- **index.vue**: 功能入口卡片展示
- 功能入口：用户查询、工程师档案、服务全景、现场登记、我的台账

### 7.2 用户查询模块
- **index.vue**: 查询表单（输入条件）
- **result.vue**: 查询结果列表

### 7.3 工程师档案模块
- **index.vue**: 工程师列表
- **detail.vue**: 档案详情（基本信息、服务记录）
- **history.vue**: 历史变更记录

### 7.4 服务全景模块
- **index.vue**: 服务全景总览
- **user-select.vue**: 用户选择
- **record-detail.vue**: 服务记录详情

### 7.5 现场登记模块
- **index.vue**: 登记表单（用户信息、服务内容、照片）
- **success.vue**: 提交成功页

### 7.6 我的台账模块
- **index.vue**: 工单列表
- **detail.vue**: 工单详情
- **filter.vue**: 筛选条件
- **task-handle.vue**: 任务处理

---

## 8. 构建配置

### 8.1 package.json脚本

```json
{
  "scripts": {
    "dev": "vue-cli-service serve --mode dev",
    "build": "vue-cli-service build --mode prod",
    "uat": "vue-cli-service build --mode uat",
    "site:prod": "vue-cli-service build --mode site-prod",
    "lib": "vue-cli-service build --target lib --name lowvoltagePlugin --dest lib ./packages/index.js"
  }
}
```

### 8.2 vue.config.js核心配置

```javascript
module.exports = {
  publicPath: './',
  productionSourceMap: false,
  transpileDependencies: ['*'],
  css: {
    extract: isLibBuild ? false : true,
    loaderOptions: {
      postcss: {
        plugins: [pxtorem({ rootValue: 37.5, propList: ['*'] })]
      },
      less: {
        lessOptions: {
          modifyVars: {
            hack: `true; @import "./src/assets/less/var.less";`
          }
        }
      }
    }
  }
}
```

### 8.3 自动打包zip

使用 filemanager-webpack-plugin：
```javascript
{
  onEnd: {
    delete: [`./dist_zip`],
    archive: [{
      source: './dist',
      destination: `./dist_zip/${process.env.VUE_APP_TYPE}-${moment().format('MMDDHHmm')}.zip`
    }]
  }
}
```

---

## 9. IGW平台集成

### 9.1 IGW配置

```javascript
let appConfig = {
  needAuth: false,
  serviceUrl: '...',
  appName: 'lowvoltage-assistant',
  iscpIP: '...',
  iscpPort: '...',
  env: 'uat',
  resource: 'masp',
  appId: '...',
  encryp: true,
  openSign: true,
  uploadUrl: '...'
}
```

### 9.2 Vegeta桥接

```javascript
// 初始化标题样式
Vegeta.hyDock.initTitleStyle({ showTitleBar: false })

// 关闭窗口
Vegeta.hyDock.close()

// API请求
Vegeta.hyDock.request(params)
```

---

## 10. 插件导出模式

**packages/index.js**：
```javascript
import lowvoltagePlugin from './views/lowvoltagePlugin'
import homeView from './views/home'
import userQueryView from './views/user-query'
// ...其他组件

const components = [
  lowvoltagePlugin,
  homeView,
  userQueryView,
  // ...
]

const install = (Vue) => {
  if (install.installed) return
  install.installed = true
  components.map((component) => Vue.component(component.name, component))
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install,
  ...components
}
```

---

## 11. 开发规范

### 11.1 Keep-Alive缓存

```vue
<!-- App.vue -->
<keep-alive :max="5">
  <router-view :key="$route.fullPath" v-if="$route.meta.keepAlive"/>
</keep-alive>
<router-view v-if="!$route.meta.keepAlive"/>
```

### 11.2 安全区域适配

```less
.div-container {
  padding-top: constant(safe-area-inset-top);
  padding-top: env(safe-area-inset-top);
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
}
```

### 11.3 Vant样式覆盖

```less
/deep/ .van-nav-bar {
  background-color: transparent;
  .van-nav-bar__title {
    color: white;
    font-size: 18px;
  }
}
```

---

## 12. 迁移清单

### 12.1 框架搭建
- [ ] 创建项目基础结构（packages/, src/, public/）
- [ ] 配置 package.json 依赖和脚本
- [ ] 配置 vue.config.js、babel.config.js、jsconfig.json
- [ ] 创建环境配置文件（.env.*）
- [ ] 创建 CLAUDE.md 开发文档

### 12.2 核心模块
- [ ] API层（api/index.js, api/const.js）
- [ ] 路由系统（router/index.js + modules/*.route.js）
- [ ] Vuex Store（store/index.js + modules/*.js）
- [ ] 工具函数（utils/*.js）
- [ ] 样式系统（assets/less/*.less）

### 12.3 共享组件
- [ ] container-view.vue
- [ ] empty-view.vue
- [ ] cell-item.vue
- [ ] button-view.vue
- [ ] field-item.vue
- [ ] 其他组件

### 12.4 页面迁移
- [ ] 首页模块
- [ ] 用户查询模块
- [ ] 工程师档案模块
- [ ] 服务全景模块
- [ ] 现场登记模块
- [ ] 我的台账模块

### 12.5 IGW集成
- [ ] IGW配置文件
- [ ] Vegeta桥接调用
- [ ] 主入口初始化

### 12.6 插件导出
- [ ] packages/index.js 导出配置
- [ ] lowvoltagePlugin.vue 主插件入口
- [ ] 库构建测试