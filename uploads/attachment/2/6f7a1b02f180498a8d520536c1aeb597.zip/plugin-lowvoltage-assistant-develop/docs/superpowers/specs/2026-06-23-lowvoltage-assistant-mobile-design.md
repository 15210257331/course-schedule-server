# 现场服务助手移动端前端设计文档

**创建时间**：2026-06-23
**状态**：已批准
**技术栈**：Vue 2 + Vant 2 + TypeScript（i国网掌上营销）
**主题风格**：科技蓝

---

## 1. 项目概述

### 1.1 项目背景

本项目为"现场服务助手"移动端前端开发，用于i国网App内嵌H5形式运行。面向现场服务工作人员，提供工程师档案查询、服务全景看板、现场登记、个人台账等功能。

### 1.2 开发策略

采用**分阶段开发**：
- **第一阶段（当前）**：P0+P1核心页面（首页+工程师档案+服务全景+现场登记），使用Mock数据，标准Vue CLI工程结构
- **第二阶段（后续）**：P2页面（我的台账完整功能），重构为packages/插件结构，对接真实API

### 1.3 核心约束

- 技术栈：Vue 2.6.x + Vant 2.12.x + Less
- UI风格：Vant默认组件 + 科技蓝主色微调（#2B6EF7）
- Mock数据：通过配置`window.Vegeta.hyDock`模拟IGW平台桥接
- 导航方式：首页卡片导航，无底部TabBar

---

## 2. 技术架构

### 2.1 技术栈选型

| 层级 | 技术选型 | 版本 | 说明 |
|------|---------|------|------|
| 框架 | Vue | 2.6.x | 规格文档要求 |
| UI库 | Vant | 2.12.x | 规格文档要求，按需引入 |
| 路由 | Vue Router | 3.x | 嵌套路由、路由守卫 |
| 状态 | Vuex | 3.x | 用户信息、工单状态共享 |
| 请求 | Axios（预留） | - | Mock阶段封装为`window.Api.request` |
| 构建 | Vue CLI | 4.x | 标准构建工具链 |
| 样式 | Less | - | 主题变量覆盖 |

### 2.2 目录结构

```
src/
├── api/
│   ├── index.js          # request封装（兼容IGW桥接）
│   └── const.js          # API常量定义
├── assets/
│   ├── images/
│   │   ├── icons/        # 功能图标
│   │   └── backgrounds/  # 背景图
│   └── less/
│       ├── var.less      # 主题变量覆盖
│       ├── mixin.less    # 通用混入
│       └── reset.less    # 样式重置
├── components/
│   ├── index.js          # 组件自动注册
│   ├── container-view/   # 页面容器组件
│   ├── empty-view/       # 空状态组件
│   ├── user-card/        # 用户卡片组件
│   ├── service-timeline/ # 服务时间轴组件
│   ├── order-card/       # 工单卡片组件
│   ├── stat-card/        # 统计指标卡片
│   └── filter-panel/     # 筛选条件面板
├── router/
│   ├── index.js          # 路由入口
│   └── modules/
│       ├── home.route.js
│       ├── engineer.route.js
│       ├── panorama.route.js
│       ├── register.route.js
│       └── workbench.route.js
├── store/
│   ├── index.js          # Vuex入口
│   └── modules/
│       ├── user.js       # 用户信息状态
│       └── workbench.js  # 台账状态
├── utils/
│   ├── toast.js          # Toast封装
│   ├── dialog.js         # Dialog封装
│   ├── storage.js        # 本地存储
│   └── date.js           # 日期工具
├── mock/
│   ├── index.js          # Mock入口（配置window.Vegeta）
│   ├── engineer.js       # 工程师档案Mock
│   ├── panorama.js       # 服务全景Mock
│   ├── register.js       # 现场登记Mock
│   └── workbench.js      # 台账Mock
├── views/
│   ├── home/             # 首页
│   ├── engineer/         # 工程师档案模块
│   ├── panorama/         # 服务全景模块
│   ├── register/         # 现场登记模块
│   └── workbench/        # 我的台账模块
├── config.json           # 主题开关配置
├── App.vue               # 根组件
└── main.js               # 入口文件
```

---

## 3. Mock数据层设计

### 3.1 Mock架构

遵循CLAUDE.md的Mock规范，通过配置`window.Vegeta.hyDock`模拟IGW平台桥接方法。

**Mock入口文件结构**（`src/mock/index.js`）：

```javascript
// 模拟 hyDock 桥接方法
const hyDock = {
  // 获取用户信息（当前登录人）
  getUserInfo: () => Promise.resolve({
    userName: '张伟',
    userNo: 'EMP001',
    unitName: '长山供电所',
    deptName: '运检一班'
  }),

  // 获取定位信息
  getLocationInfo: () => Promise.resolve({
    latitude: 38.035057,
    longitude: 118.528796,
    address: '长山路168号'
  }),

  // API请求（核心）
  request: (params) => Promise.resolve(mockResult[params.code]),

  // 关闭窗口
  closeWindow: () => {},

  // 本地存储
  saveDBData: (params) => Promise.resolve({ code: '00000' })
}

// 配置到全局
window.Vegeta = { hyDock, hyUtils }
window.Api = { request }
```

### 3.2 Mock数据模块划分

| 模块文件 | 模拟接口 | 关键数据 |
|---------|---------|---------|
| `mock/engineer.js` | 用户查询、档案详情、变更记录 | 用户列表、工程师信息、变更时间轴 |
| `mock/panorama.js` | 服务概览统计、服务记录列表 | 统计指标、时间轴记录 |
| `mock/register.js` | 客户选择、工单提交 | 客户列表、提交结果 |
| `mock/workbench.js` | 台账统计、待办/已办列表 | 概览数据、工单卡片 |

### 3.3 Mock控制开关

通过`src/config.json`控制：
```json
{
  "mockEnabled": true,
  "theme": "techBlue"
}
```

- `mockEnabled: true` → 使用Mock数据
- `mockEnabled: false` → 对接真实API（预留切换能力）

### 3.4 Mock延迟模拟

```javascript
const request = async (params) => {
  // 模拟500ms网络延迟
  await new Promise(resolve => setTimeout(resolve, 500))

  const res = mockResult[params.code]
  if (!res) {
    return { code: '00000', message: 'Mock未定义', data: null }
  }
  return res
}
```

---

## 4. 路由与页面组件设计

### 4.1 路由配置结构

采用模块化路由配置，通过`require.context`自动加载：

**路由入口**（`src/router/index.js`）：
```javascript
const routes = () => {
  let list = []
  const modules = require.context('./modules', true, /\.route\.js$/)
  modules.keys().forEach(key => {
    list = list.concat(modules(key).default)
  })
  return list
}
```

### 4.2 第一阶段页面清单（P0+P1）

| 模块 | 页面 | 路由 | 优先级 | Keep-Alive |
|------|------|------|--------|-----------|
| 首页 | 功能导航首页 | `/` | P0 | ✅ |
| 工程师档案 | 用户查询 | `/user-query` | P1 | ❌ |
| 工程师档案 | 查询结果 | `/user-query/result` | P1 | ✅ |
| 工程师档案 | 档案详情 | `/engineer/detail` | P1 | ❌ |
| 工程师档案 | 变更记录 | `/engineer/history` | P1 | ❌ |
| 服务全景 | 服务全景主页 | `/panorama` | P1 | ❌ |
| 服务全景 | 用户选择 | `/panorama/user-select` | P1 | ✅ |
| 服务全景 | 记录详情 | `/panorama/record-detail` | P1 | ❌ |
| 现场登记 | 现场登记表单 | `/register` | P1 | ❌ |
| 现场登记 | 提交成功 | `/register/success` | P1 | ❌ |

### 4.3 公共组件设计

| 组件名 | 功能 | 使用页面 |
|--------|------|---------|
| `container-view` | 页面容器（NavBar+内容区+安全区域） | 所有页面 |
| `empty-view` | 空状态展示（无数据/无结果） | 列表页、详情页 |
| `user-card` | 用户信息卡片（点击跳转） | 用户列表、查询结果 |
| `service-timeline` | 服务时间轴（Vant Timeline封装） | 服务全景、变更记录 |
| `order-card` | 工单卡片（虚线分隔两区域） | 台账列表 |
| `stat-card` | 统计指标卡片（图标+数值） | 服务全景概览、台账概览 |
| `filter-panel` | 篛选条件面板（可折叠） | 用户查询、台账筛选 |

### 4.4 Keep-Alive策略

| 页面类型 | Keep-Alive | 原因 |
|---------|-----------|------|
| 首页 | ✅ true | 返回首页时保持状态 |
| 查询结果列表 | ✅ true | 避免重复查询 |
| 详情页 | ❌ false | 每次进入刷新数据 |
| 表单页 | ❌ false | 每次进入清空表单 |

---

## 5. 状态管理与数据流

### 5.1 Vuex状态管理结构

采用模块化Vuex，按业务功能划分：

**Store入口**（`src/store/index.js`）：
```javascript
import user from './modules/user'
import workbench from './modules/workbench'

export default new Vuex.Store({
  modules: { user, workbench }
})
```

### 5.2 用户状态模块（user.js）

**状态定义**：
```javascript
state: {
  userInfo: null,        // 当前登录用户信息
  selectedCustomer: null // 当前选中的客户（服务全景用）
}

mutations: {
  SET_USER_INFO(state, info)
  SET_SELECTED_CUSTOMER(state, customer)
}

actions: {
  async getUserInfo({ commit }) {
    const info = await window.Vegeta.hyDock.getUserInfo()
    commit('SET_USER_INFO', info)
  }
}
```

### 5.3 台账状态模块（workbench.js）

**状态定义**：
```javascript
state: {
  statistics: {
    todayTodo: 0,
    weekCompleted: 0,
    monthTotal: 0
  },
  pendingList: [],
  completedList: [],
  currentTab: 'pending'
}

mutations: {
  SET_STATISTICS(state, data)
  SET_PENDING_LIST(state, list)
  SET_COMPLETED_LIST(state, list)
  SET_CURRENT_TAB(state, tab)
}
```

### 5.4 数据流设计

**查询类页面数据流**：
```
页面组件 → 调用Api.request → Mock/真实接口返回 → Vuex存储（可选） → 页面渲染
```

**详情页数据流**：
```
页面组件（接收路由参数） → 调用Api.request查询详情 → 直接渲染（不存Vuex）
```

**表单提交数据流**：
```
表单组件 → 校验 → 调用Api.request提交 → Toast提示 → 跳转结果页/返回列表
```

### 5.5 API请求封装

**封装层**（`src/api/index.js`）：
```javascript
const request = async (apiConst, body, headers = {}, config = {}) => {
  try {
    if (window.Vegeta?.hyDock?.request) {
      return await window.Vegeta.hyDock.request({
        code: apiConst.code,
        body
      })
    }
  } catch (error) {
    $toast.show('请求失败，请重试')
    throw error
  }
}

window.Api = { request }
```

### 5.6 API常量定义

**定义示例**（`src/api/const.js`）：
```javascript
export const queryUserList = {
  code: 'EMSS_0200096',
  type: 'rest'
}

export const getEngineerDetail = {
  code: 'EMSS_0200097',
  type: 'rest'
}

export const getServiceOverview = {
  code: 'EMSS_25122001',
  type: 'rest'
}

export const submitServiceOrder = {
  code: 'EMSS_25122003',
  type: 'rest'
}
```

---

## 6. 主题样式设计

### 6.1 主题变量配置

**Less变量覆盖**（`src/assets/less/var.less`）：

```less
// 主色覆盖（科技蓝）
@blue: #2B6EF7;
@primary-color: #2B6EF7;

// Vant主题色变量
--van-color-primary: #2B6EF7;
--van-color-success: #06C687;
--van-color-warning: #FF976A;
--van-color-danger: #FA541C;

// 文字色覆盖
@text-color: #333333;
@gray-6: #666666;
@gray-7: #9393A2;
@gray-5: #999999;

// 背景色覆盖
@gray-1: #F3F7FC;
@white: #FFFFFF;

// 边框色覆盖
@gray-3: #E5E6EB;
@border-color: #E5E6EB;

// 渐变色
@gradient-primary: linear-gradient(135deg, #2B6EF7 0%, #5B8EF9 100%);
@gradient-card: linear-gradient(180deg, #F3F7FC 0%, #FFFFFF 100%);
```

### 6.2 通用样式混入

**混入定义**（`src/assets/less/mixin.less`）：
```less
.flex-center() {
  display: flex;
  align-items: center;
  justify-content: center;
}

.flex-between() {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.overflow() {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-shadow() {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  border-radius: 8px;
}

.safe-area-bottom() {
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
}
```

### 6.3 页面背景样式

```less
.page-home {
  min-height: 100vh;
  background: linear-gradient(180deg,
    @primary-color 0%,
    @gray-1 20%,
    @white 100%);
}
```

### 6.4 状态标签颜色映射

| 状态类型 | 颜色 | 使用场景 |
|---------|------|---------|
| 已建档 | #06C687（绿色） | 用户卡片状态 |
| 待处理 | #FA541C（红色） | 工单状态标签 |
| 处理中 | #FF976A（橙色） | 工单状态标签 |
| 已完成 | #06C687（绿色） | 工单状态标签 |
| 超时 | #FA541C（红色） | 工单超时标识 |
| 催费 | #FF976A（橙色） | 服务类型标签 |
| 检修 | #2B6EF7（蓝色） | 服务类型标签 |
| 拜访 | #06C687（绿色） | 服务类型标签 |
| 诉求 | #FA541C（红色） | 服务类型标签 |

### 6.5 Vant组件样式微调

**NavBar微调**：
```less
.van-nav-bar {
  background-color: transparent;

  .van-nav-bar__title {
    color: @white;
    font-size: 18px;
    font-weight: 500;
  }

  .van-nav-bar__arrow {
    color: @white;
  }
}

.van-nav-bar--white {
  background-color: @white;

  .van-nav-bar__title {
    color: @text-color;
  }

  .van-nav-bar__arrow {
    color: @text-color;
  }
}
```

**Button微调**：
```less
.van-button--primary {
  background-color: @primary-color;
  border-color: @primary-color;
}

.van-button--plain.van-button--primary {
  color: @primary-color;
  border-color: @primary-color;
}
```

---

## 7. 边界情况与错误处理

### 7.1 边界情况处理策略

| 边界情况 | 处理方式 | 实现位置 |
|---------|---------|---------|
| 网络异常 | Toast提示 + 重试按钮 | API封装层 |
| 数据为空 | EmptyView组件 + 引导文案 | 各列表页 |
| 加载中 | Skeleton骨架屏 | 列表页、详情页 |
| 搜索无结果 | EmptyView + "未找到相关客户" | 查询结果页 |
| 图片上传失败 | Toast提示 + 保留已上传图片 | 现场登记页 |
| 表单提交失败 | Toast提示 + 保留表单内容 | 现场登记页 |
| 接口超时 | Toast + "网络请求超时" | API封装层 |

### 7.2 错误处理统一封装

**API错误处理**（`src/api/index.js`）：
```javascript
const request = async (apiConst, body, headers = {}, config = {}) => {
  try {
    $toast.loading('加载中...')
    const res = await window.Vegeta.hyDock.request(...)
    $toast.clear()

    if (res.code !== '00000') {
      await $dialog.alert(res.message || '操作失败')
      return null
    }
    return res.data
  } catch (error) {
    $toast.clear()
    await $dialog.alert('网络请求失败，请检查网络后重试')
    throw error
  }
}
```

### 7.3 空状态组件设计

**EmptyView组件**（`src/components/empty-view/index.vue`）：
```vue
<template>
  <div class="empty-view">
    <van-empty
      :image="image"
      :description="description">
      <van-button
        v-if="showAction"
        type="primary"
        size="small"
        @click="$emit('action')">
        {{ actionText }}
      </van-button>
    </van-empty>
  </div>
</template>

<script>
export default {
  name: 'EmptyView',
  props: {
    image: { type: String, default: 'default' },
    description: { type: String, default: '暂无数据' },
    showAction: { type: Boolean, default: false },
    actionText: { type: String, default: '重新加载' }
  }
}
</script>
```

### 7.4 表单草稿保留

使用`localStorage`暂存未提交的表单数据：

```javascript
// 页面离开时保存草稿
beforeRouteLeave(to, from, next) {
  if (this.hasUnsavedChanges) {
    saveStorage('register_draft', this.formData)
  }
  next()
}

// 页面进入时恢复草稿
mounted() {
  const draft = getStorage('register_draft')
  if (draft) {
    this.formData = draft
    $dialog.confirm('检测到未提交的草稿，是否恢复？')
      .then(() => this.formData = draft)
      .catch(() => removeStorage('register_draft'))
  }
}
```

### 7.5 下拉刷新与上拉加载

```vue
<template>
  <van-list
    v-model="loading"
    :finished="finished"
    finished-text="没有更多了"
    @load="onLoad">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <user-card v-for="item in list" :key="item.id" :data="item" />
    </van-pull-refresh>
  </van-list>
</template>
```

### 7.6 骨架屏实现

```vue
<template>
  <div v-if="loading">
    <van-skeleton title :row="3" />
    <van-skeleton title :row="3" />
  </div>
  <div v-else>
    <user-card ... />
  </div>
</template>
```

---

## 8. 工具函数设计

### 8.1 Toast封装（`src/utils/toast.js`）

```javascript
window.$toast = {
  show(message) {
    Toast(message)
  },
  loading(message = '加载中...') {
    Toast.loading({
      message,
      forbidClick: true,
      duration: 0
    })
  },
  clear() {
    Toast.clear()
  }
}
```

### 8.2 Dialog封装（`src/utils/dialog.js`）

```javascript
window.$dialog = {
  alert(message, title = '提示') {
    return Dialog.alert({ message, title })
  },
  confirm(message, title = '提示') {
    return Dialog.confirm({ message, title })
  }
}
```

### 8.3 Storage封装（`src/utils/storage.js`）

```javascript
export const setStorage = (key, value) => {
  const data = typeof value === 'object' ? JSON.stringify(value) : value
  localStorage.setItem(key, data)
}

export const getStorage = (key) => {
  const data = localStorage.getItem(key)
  try {
    return JSON.parse(data)
  } catch {
    return data
  }
}

export const removeStorage = (key) => {
  localStorage.removeItem(key)
}
```

### 8.4 日期工具（`src/utils/date.js`）

```javascript
export const formatDate = (date, format = 'YYYY-MM-DD') => {
  // 使用Day.js格式化日期
  return dayjs(date).format(format)
}

export const isOverdue = (endDate) => {
  return new Date(endDate) < new Date()
}
```

---

## 9. 第二阶段重构计划（预留）

### 9.1 重构目标

将第一阶段的标准Vue CLI工程重构为CLAUDE.md定义的**双结构**模式，满足IGW平台插件交付要求。

### 9.2 重构步骤

1. 创建`packages/`目录
2. 迁移`src/views/`和`src/components/`到`packages/`
3. 创建`packages/index.js`插件导出入口
4. 修改`vue.config.js`支持UMD库编译
5. 编译输出到`src/libs/custTagPlugin.umd.min.js`
6. `src/`目录保留为Wrapper应用

### 9.3 重构后结构

```
packages/
├── api/
├── assets/
├── components/
├── views/
│   └── custTagPlugin.vue
└── index.js

src/
├── libs/
│   └── custTagPlugin.umd.min.js
└── main.js（导入插件）
```

---

## 10. 交付物清单

### 10.1 第一阶段交付

- 完整的Vue CLI工程骨架
- 10个页面组件（P0+P1）
- 7个公共组件
- 4个Mock数据模块
- 2个Vuex状态模块
- 5个路由模块
- Less主题变量文件
- 工具函数封装

### 10.2 验收标准

- 所有页面可正常访问
- Mock数据正确加载
- 空状态正确展示
- 表单校验正确触发
- 路由跳转正常工作
- 科技蓝主题正确应用

---

**文档状态**：已批准，待写入实施计划