# 低压服务助手框架搭建实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 建立符合企业标准的 Vue2 + Vue CLI + JavaScript 项目框架，支持混合模式（插件库+独立应用），迁移原型全部6个功能模块。

**Architecture:** 采用混合模式结构：packages/ 作为库源码用于打包插件，src/ 作为应用入口用于开发调试。路径别名 @ 指向 src/，# 指向 packages/。使用 require.context 自动加载路由模块和注册组件。

**Tech Stack:** Vue 2.6, Vue CLI 4.5, Vant 2.x, Vuex 3.x, Vue Router 3.x, LESS, postcss-pxtorem, filemanager-webpack-plugin

---

## Task 1: 项目初始化与基础结构

**Files:**
- Create: `package.json`
- Create: `vue.config.js`
- Create: `babel.config.js`
- Create: `jsconfig.json`
- Create: `.env.dev`
- Create: `.env.uat`
- Create: `.env.prod`
- Create: `.env.site-prod`
- Create: `public/index.html`
- Create: `CLAUDE.md`

- [ ] **Step 1: 创建 package.json**

```json
{
  "name": "plugin-lowvoltage-assistant",
  "version": "1.0.0",
  "private": false,
  "scripts": {
    "dev": "vue-cli-service serve --mode dev",
    "build": "vue-cli-service build --mode prod",
    "uat": "vue-cli-service build --mode uat",
    "site:prod": "vue-cli-service build --mode site-prod",
    "lib": "vue-cli-service build --target lib --name lowvoltagePlugin --dest lib ./packages/index.js"
  },
  "dependencies": {
    "@utils/mas-vue-track-wookong": "0.0.42",
    "@utils/vegeta-base": "0.0.63",
    "babel-polyfill": "^6.26.0",
    "core-js": "^3.6.5",
    "es6-promise": "^4.2.8",
    "lib-flexible": "^0.3.2",
    "vant": "^2.12.54",
    "vue": "^2.6.11",
    "vue-router": "^3.2.0",
    "vuex": "^3.4.0",
    "js-md5": "^0.7.3",
    "moment": "^2.29.1"
  },
  "devDependencies": {
    "@vue/cli-plugin-babel": "~4.5.13",
    "@vue/cli-plugin-router": "~4.5.13",
    "@vue/cli-plugin-vuex": "~4.5.13",
    "@vue/cli-service": "~4.5.13",
    "babel-plugin-import": "^1.13.5",
    "less": "^3.0.4",
    "less-loader": "^6.1.0",
    "postcss-pxtorem": "^5.1.1",
    "filemanager-webpack-plugin": "^7.0.0",
    "vue-template-compiler": "^2.6.11"
  },
  "browserslist": [
    "> 1%",
    "last 2 versions",
    "not dead",
    "iOS >= 8",
    "Android >= 4"
  ]
}
```

- [ ] **Step 2: 创建 vue.config.js**

```javascript
const FileManager = require('filemanager-webpack-plugin')
const pxtorem = require('postcss-pxtorem')
const moment = require('moment')
const path = require('path')

const resolve = (dir) => path.join(__dirname, dir)
const isLibBuild = process.env.npm_lifecycle_event === 'lib'

module.exports = {
  publicPath: './',
  productionSourceMap: false,
  parallel: false,
  devServer: {
    open: true,
    disableHostCheck: true
  },
  pages: {
    index: {
      entry: 'src/main.js',
      template: 'public/index.html',
      filename: 'index.html'
    }
  },
  transpileDependencies: ['*'],
  configureWebpack: (config) => {
    config.plugins.push(new FileManager({
      events: {
        onEnd: {
          delete: ['./dist_zip'],
          archive: [{
            source: './dist',
            destination: `./dist_zip/${process.env.VUE_APP_TYPE}-${moment().format('MMDDHHmm')}.zip`
          }]
        }
      }
    }))
  },
  chainWebpack: (config) => {
    config.resolve.alias.set('#', path.resolve('packages')).set('@', path.resolve('src'))
    config.module.rule('js').include.add(resolve('packages')).end().include.add(resolve('src')).end()
    if (isLibBuild) {
      config.module.rule('images').use('url-loader').tap(() => ({ limit: 999999 }))
    }
    config.entry.app = ['babel-polyfill', resolve('./src/main.js')]
  },
  css: {
    extract: isLibBuild ? false : true,
    loaderOptions: {
      postcss: {
        plugins: isLibBuild ? [] : [pxtorem({ rootValue: 37.5, propList: ['*'] })]
      },
      less: {
        lessOptions: {
          modifyVars: {
            hack: `true; @import "./src/assets/less/var.less";`
          }
        }
      }
    }
  }
}
```

- [ ] **Step 3: 创建 babel.config.js**

```javascript
module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset'
  ],
  plugins: [
    ['import', {
      libraryName: 'vant',
      libraryDirectory: 'es',
      style: true
    }, 'vant']
  ]
}
```

- [ ] **Step 4: 创建 jsconfig.json**

```json
{
  "compilerOptions": {
    "baseUrl": "./",
    "paths": {
      "@/*": ["src/*"],
      "#/*": ["packages/*"]
    }
  },
  "exclude": ["node_modules", "dist", "dist_zip", "lib"]
}
```

- [ ] **Step 5: 创建环境配置文件**

**.env.dev:**
```
NODE_ENV=development
VUE_APP_TYPE=dev
VUE_APP_PLATFORM=app
```

**.env.uat:**
```
NODE_ENV=production
VUE_APP_TYPE=uat
VUE_APP_PLATFORM=app
```

**.env.prod:**
```
NODE_ENV=production
VUE_APP_TYPE=prod
VUE_APP_PLATFORM=app
```

**.env.site-prod:**
```
NODE_ENV=production
VUE_APP_TYPE=site-prod
VUE_APP_PLATFORM=app
```

- [ ] **Step 6: 创建 public/index.html**

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <link rel="icon" href="<%= BASE_URL %>favicon.ico">
    <title>低压服务助手</title>
  </head>
  <body>
    <noscript>
      <strong>请启用JavaScript以运行此应用。</strong>
    </noscript>
    <div id="app"></div>
  </body>
</html>
```

- [ ] **Step 7: 创建 CLAUDE.md**

```markdown
# 低压服务助手开发文档

## 项目结构
- `packages/` - 库源码（打包插件）
- `src/` - 应用入口（开发调试）
- 路径别名：`@` → `src/`，`#` → `packages/`

## 开发命令
- `npm run dev` - 开发模式
- `npm run build` - 生产构建
- `npm run lib` - 打包插件库

## 技术栈
Vue 2.6 + Vant 2.x + Vuex 3.x + Vue Router 3.x + LESS

## IGW平台集成
使用 Vegeta 桥接调用 API，配置在 `packages/config/igw-config.js`
```

- [ ] **Step 8: 安装依赖并验证**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && npm install`
Expected: 依赖安装成功，无报错

- [ ] **Step 9: Commit**

```bash
git add package.json vue.config.js babel.config.js jsconfig.json .env.* public/index.html CLAUDE.md
git commit -m "feat: init project with Vue CLI config and environment files"
```

---

## Task 2: 样式系统搭建

**Files:**
- Create: `src/assets/less/var.less`
- Create: `src/assets/less/mixin.less`
- Create: `src/assets/less/border.less`
- Create: `src/assets/less/reset.less`
- Create: `src/assets/less/index.less`
- Create: `packages/assets/less/var.less`（复制同样内容）

- [ ] **Step 1: 创建 var.less 全局变量**

复制原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/assets/less/var.less` 内容到 `src/assets/less/var.less`（902行完整内容）

- [ ] **Step 2: 创建 mixin.less 混入**

复制原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/assets/less/mixin.less` 内容到 `src/assets/less/mixin.less`

- [ ] **Step 3: 创建 border.less 1px边框**

复制原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/assets/less/border.less` 内容到 `src/assets/less/border.less`

- [ ] **Step 4: 创建 reset.less 样式重置**

复制原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/assets/less/reset.less` 内容到 `src/assets/less/reset.less`

- [ ] **Step 5: 创建 index.less 入口**

```less
@import './var.less';
@import './mixin.less';
@import './border.less';
@import './reset.less';
```

- [ ] **Step 6: 同步到 packages**

将 `src/assets/less/` 目录复制到 `packages/assets/less/`

- [ ] **Step 7: Commit**

```bash
git add src/assets/less/ packages/assets/less/
git commit -m "feat: add LESS style system with variables, mixins, and border utilities"
```

---

## Task 3: 工具函数模块

**Files:**
- Create: `packages/utils/toast.js`
- Create: `packages/utils/dialog.js`
- Create: `packages/utils/storage.js`
- Create: `packages/utils/camelCase.js`
- Create: `packages/utils/index.js`
- Create: `src/utils/index.js`（引用 packages）

- [ ] **Step 1: 创建 toast.js**

```javascript
import { Toast } from 'vant'

Toast.setDefaultOptions('loading', { forbidClick: true })

const show = (message) => {
  let item = message
  if (item instanceof Object) {
    item = JSON.stringify(item)
  }
  if (typeof item !== 'string') {
    console.error(item)
    return
  }
  Toast(item)
}

const loading = (message) => {
  Toast.loading({
    message: message || '加载中...',
    forbidClick: true,
    duration: 0
  })
}

const hidden = () => {
  Toast.clear()
}

const clear = () => {
  Toast.clear()
}

window.$toast = { show, loading, hidden, clear }

export default { show, loading, hidden, clear }
```

- [ ] **Step 2: 创建 dialog.js**

```javascript
import { Dialog } from 'vant'

const alert = (message, title) => {
  return new Promise((resolve) => {
    Dialog.alert({
      title,
      message,
      confirmButtonColor: '#1989fa'
    }).then(() => {
      resolve()
    })
  })
}

const confirm = (message, title = '提示') => {
  return new Promise((resolve) => {
    Dialog.confirm({
      title,
      message,
      confirmButtonColor: '#1989fa'
    })
      .then(() => {
        resolve()
      })
      .catch(() => {})
  })
}

window.$dialog = { alert, confirm }

export default { alert, confirm }
```

- [ ] **Step 3: 创建 storage.js**

```javascript
export function setStorage(key, value) {
  if (typeof value !== 'string') {
    value = JSON.stringify(value)
  }
  window.localStorage.setItem(key, value)
}

export function getStorage(key) {
  let value = window.localStorage.getItem(key)
  if (value !== null) {
    try {
      return JSON.parse(value)
    } catch (e) {
      return value
    }
  } else {
    return null
  }
}
```

- [ ] **Step 4: 创建 camelCase.js**

```javascript
export function camelCaseToLine(str) {
  return str.replace(/([A-Z])/g, '_$1').toLowerCase()
}

export function lineToCamelCase(str) {
  return str.replace(/_(\w)/g, (all, letter) => letter.toUpperCase())
}

export function objectCamelCaseToLine(obj) {
  const result = {}
  for (const key in obj) {
    result[camelCaseToLine(key)] = obj[key]
  }
  return result
}

export function objectLineToCamelCase(obj) {
  const result = {}
  for (const key in obj) {
    result[lineToCamelCase(key)] = obj[key]
  }
  return result
}
```

- [ ] **Step 5: 创建 packages/utils/index.js**

```javascript
import toast from './toast'
import dialog from './dialog'
import { setStorage, getStorage } from './storage'
import { camelCaseToLine, lineToCamelCase, objectCamelCaseToLine, objectLineToCamelCase } from './camelCase'

export { toast, dialog, setStorage, getStorage, camelCaseToLine, lineToCamelCase, objectCamelCaseToLine, objectLineToCamelCase }

export default {
  toast,
  dialog,
  setStorage,
  getStorage,
  camelCaseToLine,
  lineToCamelCase,
  objectCamelCaseToLine,
  objectLineToCamelCase
}
```

- [ ] **Step 6: 创建 src/utils/index.js**

```javascript
export * from '#/utils'
```

- [ ] **Step 7: Commit**

```bash
git add packages/utils/ src/utils/
git commit -m "feat: add utility functions for toast, dialog, storage, and camelCase"
```

---

## Task 4: API层搭建

**Files:**
- Create: `packages/api/index.js`
- Create: `packages/api/const.js`
- Create: `src/api/index.js`
- Create: `src/api/const.js`

- [ ] **Step 1: 创建 packages/api/index.js**

```javascript
import { callRestful } from '@utils/vegeta-base'

const callRestfulApi = async (api, data) => {
  console.table('服务编码', api)
  console.table('body入参', data)
  const params = {
    inputRules: api.type,
    code: api.code,
    data: data.body,
    config: data.config,
    headers: data.headers
  }
  if (api.srvCode) {
    params.data = {
      data: data.body,
      srvCode: api.srvCode,
      appCode: api.appCode || 'EMSS15'
    }
  }
  console.log('请求参数====', JSON.stringify(params))
  return new Promise((resolve, reject) => {
    window.Vegeta.hyDock.request(params).then((res) => {
      console.log('请求返回成功====', JSON.stringify(res))
      let result = res
      if (result instanceof Array && result.length) {
        result = result[0]
      }
      if (process.env.VUE_APP_PLATFORM === 'app') {
        result = result.data
      }
      if (result.data) {
        result = result.data
      }
      resolve(result)
    }).catch((error) => {
      console.log('请求返回失败====')
      console.log(JSON.stringify(error))
      reject(error)
    })
  })
}

const request = (api, body, headers = {}, config = {}) => {
  return callRestfulApi(api, { body, headers, config })
}

window.$Api = { request }

export default { request }
```

- [ ] **Step 2: 创建 packages/api/const.js**

```javascript
/** 接口列表 */

// 用户查询相关接口（待补充实际code）
export const queryUserList = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

export const queryUserDetail = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

// 工程师档案接口
export const queryEngineerList = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

export const queryEngineerDetail = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

// 服务全景接口
export const queryServicePanorama = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

// 现场登记接口
export const submitRegister = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

// 台账接口
export const queryWorkbenchList = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

export const queryWorkbenchDetail = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}
```

- [ ] **Step 3: 创建 src/api/index.js**

```javascript
export * from '#/api'
import api from '#/api'
export default api
```

- [ ] **Step 4: 创建 src/api/const.js**

```javascript
export * from '#/api/const'
```

- [ ] **Step 5: Commit**

```bash
git add packages/api/ src/api/
git commit -m "feat: add API layer with Vegeta bridge request wrapper"
```

---

## Task 5: 配置模块搭建

**Files:**
- Create: `packages/config/const.js`
- Create: `packages/config/igw-config.js`
- Create: `src/config/const.js`
- Create: `src/config/igw-config.js`

- [ ] **Step 1: 创建 packages/config/const.js**

```javascript
/** 常量定义 */

// 功能入口菜单
export const MENU_LIST = [
  { path: '/user-query', title: '用户查询', desc: '查询用户信息及工程师档案', icon: 'contact', bgColor: '#2b6ef7' },
  { path: '/panorama', title: '服务全景', desc: '客户服务概况与时间轴看板', icon: 'chart-trending-o', bgColor: '#07c160' },
  { path: '/register', title: '现场登记', desc: '登记现场服务工单信息', icon: 'edit', bgColor: '#ff976a' },
  { path: '/workbench', title: '我的台账', desc: '个人工作记录与任务台账', icon: 'manager-o', bgColor: '#1989fa' }
]

// 工单状态
export const WORKORDER_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  CLOSED: 'closed'
}

// 状态颜色映射
export const STATUS_COLOR_MAP = {
  pending: '#ff976a',
  processing: '#1989fa',
  completed: '#07c160',
  closed: '#969799'
}
```

- [ ] **Step 2: 创建 packages/config/igw-config.js**

```javascript
/** IGW平台配置 */

let appConfig = {
  needAuth: false,
  serviceUrl: '',
  appName: 'lowvoltage-assistant',
  iscpIP: '',
  iscpPort: '',
  env: 'uat',
  resource: 'masp',
  appId: '',
  encryp: true,
  openSign: true,
  uploadUrl: ''
}

// 根据环境变量动态配置
if (process.env.VUE_APP_TYPE === 'dev') {
  appConfig.env = 'dev'
} else if (process.env.VUE_APP_TYPE === 'uat') {
  appConfig.env = 'uat'
} else if (process.env.VUE_APP_TYPE === 'prod' || process.env.VUE_APP_TYPE === 'site-prod') {
  appConfig.env = 'prod'
}

export default appConfig
```

- [ ] **Step 3: 创建 src/config/const.js**

```javascript
export * from '#/config/const'
```

- [ ] **Step 4: 创建 src/config/igw-config.js**

```javascript
export { default } from '#/config/igw-config'
```

- [ ] **Step 5: Commit**

```bash
git add packages/config/ src/config/
git commit -m "feat: add config modules for constants and IGW platform"
```

---

## Task 6: Vuex Store搭建

**Files:**
- Create: `src/store/index.js`
- Create: `src/store/getters.js`
- Create: `src/store/modules/app.js`
- Create: `src/store/modules/user.js`
- Create: `src/store/modules/workorder.js`
- Create: `src/store/modules/schedule.js`
- Create: `src/store/modules/common.js`

- [ ] **Step 1: 创建 src/store/index.js**

```javascript
import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import user from './modules/user'
import workorder from './modules/workorder'
import schedule from './modules/schedule'
import common from './modules/common'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    user,
    workorder,
    schedule,
    common
  },
  getters: {}
})

export default store
```

- [ ] **Step 2: 创建 src/store/modules/app.js**

```javascript
const state = {
  loading: false,
  title: '低压服务助手',
  showTitleBar: false
}

const mutations = {
  SET_LOADING(state, loading) {
    state.loading = loading
  },
  SET_TITLE(state, title) {
    state.title = title
  },
  SET_SHOW_TITLE_BAR(state, show) {
    state.showTitleBar = show
  }
}

const actions = {
  setLoading({ commit }, loading) {
    commit('SET_LOADING', loading)
  },
  setTitle({ commit }, title) {
    commit('SET_TITLE', title)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
```

- [ ] **Step 3: 创建 src/store/modules/user.js**

```javascript
const state = {
  userInfo: null,
  userList: [],
  selectedUser: null
}

const mutations = {
  SET_USER_INFO(state, info) {
    state.userInfo = info
  },
  SET_USER_LIST(state, list) {
    state.userList = list
  },
  SET_SELECTED_USER(state, user) {
    state.selectedUser = user
  }
}

const actions = {
  setUserInfo({ commit }, info) {
    commit('SET_USER_INFO', info)
  },
  setUserList({ commit }, list) {
    commit('SET_USER_LIST', list)
  },
  selectUser({ commit }, user) {
    commit('SET_SELECTED_USER', user)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
```

- [ ] **Step 4: 创建 src/store/modules/workorder.js**

```javascript
const state = {
  workorderList: [],
  currentWorkorder: null,
  filterConditions: {}
}

const mutations = {
  SET_WORKORDER_LIST(state, list) {
    state.workorderList = list
  },
  SET_CURRENT_WORKORDER(state, order) {
    state.currentWorkorder = order
  },
  SET_FILTER_CONDITIONS(state, conditions) {
    state.filterConditions = conditions
  }
}

const actions = {
  setWorkorderList({ commit }, list) {
    commit('SET_WORKORDER_LIST', list)
  },
  setCurrentWorkorder({ commit }, order) {
    commit('SET_CURRENT_WORKORDER', order)
  },
  setFilterConditions({ commit }, conditions) {
    commit('SET_FILTER_CONDITIONS', conditions)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
```

- [ ] **Step 5: 创建 src/store/modules/schedule.js**

```javascript
const state = {
  scheduleList: [],
  currentDate: null
}

const mutations = {
  SET_SCHEDULE_LIST(state, list) {
    state.scheduleList = list
  },
  SET_CURRENT_DATE(state, date) {
    state.currentDate = date
  }
}

const actions = {
  setScheduleList({ commit }, list) {
    commit('SET_SCHEDULE_LIST', list)
  },
  setCurrentDate({ commit }, date) {
    commit('SET_CURRENT_DATE', date)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
```

- [ ] **Step 6: 创建 src/store/modules/common.js**

```javascript
const state = {
  engineerList: [],
  servicePanorama: null
}

const mutations = {
  SET_ENGINEER_LIST(state, list) {
    state.engineerList = list
  },
  SET_SERVICE_PANORAMA(state, data) {
    state.servicePanorama = data
  }
}

const actions = {
  setEngineerList({ commit }, list) {
    commit('SET_ENGINEER_LIST', list)
  },
  setServicePanorama({ commit }, data) {
    commit('SET_SERVICE_PANORAMA', data)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
```

- [ ] **Step 7: 创建 src/store/getters.js**

```javascript
const getters = {
  loading: state => state.app.loading,
  title: state => state.app.title,
  userInfo: state => state.user.userInfo,
  userList: state => state.user.userList,
  selectedUser: state => state.user.selectedUser,
  workorderList: state => state.workorder.workorderList,
  currentWorkorder: state => state.workorder.currentWorkorder
}

export default getters
```

- [ ] **Step 8: Commit**

```bash
git add src/store/
git commit -m "feat: add Vuex store with app, user, workorder, schedule, and common modules"
```

---

## Task 7: 路由系统搭建

**Files:**
- Create: `src/router/index.js`
- Create: `src/router/modules/home.route.js`
- Create: `src/router/modules/user-query.route.js`
- Create: `src/router/modules/engineer.route.js`
- Create: `src/router/modules/panorama.route.js`
- Create: `src/router/modules/register.route.js`
- Create: `src/router/modules/workbench.route.js`

- [ ] **Step 1: 创建 src/router/index.js**

```javascript
import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routeList = () => {
  let list = []
  const routerModules = require.context('./modules', true, /\.route\.js/)
  routerModules.keys().forEach((key) => {
    list = list.concat(routerModules(key).default)
  })
  return list
}

const router = new VueRouter({
  routes: routeList(),
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    }
    return { x: 0, y: 0 }
  }
})

export default router
```

- [ ] **Step 2: 创建 src/router/modules/home.route.js**

```javascript
export default [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/views/home'),
    meta: {
      title: '首页',
      keepAlive: true
    }
  }
]
```

- [ ] **Step 3: 创建 src/router/modules/user-query.route.js**

```javascript
export default [
  {
    path: '/user-query',
    name: 'user-query',
    component: () => import('@/views/user-query'),
    meta: {
      title: '用户查询',
      keepAlive: true
    }
  },
  {
    path: '/user-query/result',
    name: 'user-query-result',
    component: () => import('@/views/user-query/result'),
    meta: {
      title: '查询结果',
      keepAlive: false
    }
  }
]
```

- [ ] **Step 4: 创建 src/router/modules/engineer.route.js**

```javascript
export default [
  {
    path: '/engineer',
    name: 'engineer',
    component: () => import('@/views/engineer'),
    meta: {
      title: '工程师档案',
      keepAlive: true
    }
  },
  {
    path: '/engineer/detail',
    name: 'engineer-detail',
    component: () => import('@/views/engineer/detail'),
    meta: {
      title: '档案详情',
      keepAlive: false
    }
  },
  {
    path: '/engineer/history',
    name: 'engineer-history',
    component: () => import('@/views/engineer/history'),
    meta: {
      title: '历史变更',
      keepAlive: false
    }
  }
]
```

- [ ] **Step 5: 创建 src/router/modules/panorama.route.js**

```javascript
export default [
  {
    path: '/panorama',
    name: 'panorama',
    component: () => import('@/views/panorama'),
    meta: {
      title: '服务全景',
      keepAlive: false
    }
  },
  {
    path: '/panorama/user-select',
    name: 'panorama-user-select',
    component: () => import('@/views/panorama/user-select'),
    meta: {
      title: '用户选择',
      keepAlive: false
    }
  },
  {
    path: '/panorama/record-detail',
    name: 'panorama-record-detail',
    component: () => import('@/views/panorama/record-detail'),
    meta: {
      title: '服务记录',
      keepAlive: false
    }
  }
]
```

- [ ] **Step 6: 创建 src/router/modules/register.route.js**

```javascript
export default [
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/register'),
    meta: {
      title: '现场登记',
      keepAlive: false
    }
  },
  {
    path: '/register/success',
    name: 'register-success',
    component: () => import('@/views/register/success'),
    meta: {
      title: '提交成功',
      keepAlive: false
    }
  }
]
```

- [ ] **Step 7: 创建 src/router/modules/workbench.route.js**

```javascript
export default [
  {
    path: '/workbench',
    name: 'workbench',
    component: () => import('@/views/workbench'),
    meta: {
      title: '我的台账',
      keepAlive: true
    }
  },
  {
    path: '/workbench/detail',
    name: 'workbench-detail',
    component: () => import('@/views/workbench/detail'),
    meta: {
      title: '工单详情',
      keepAlive: false
    }
  },
  {
    path: '/workbench/filter',
    name: 'workbench-filter',
    component: () => import('@/views/workbench/filter'),
    meta: {
      title: '筛选条件',
      keepAlive: false
    }
  },
  {
    path: '/workbench/task-handle',
    name: 'workbench-task-handle',
    component: () => import('@/views/workbench/task-handle'),
    meta: {
      title: '任务处理',
      keepAlive: false
    }
  }
]
```

- [ ] **Step 8: Commit**

```bash
git add src/router/
git commit -m "feat: add Vue Router with auto-loading modules for all 6 feature sections"
```

---

## Task 8: 应用入口搭建

**Files:**
- Create: `src/main.js`
- Create: `src/App.vue`

- [ ] **Step 1: 创建 src/main.js**

```javascript
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import 'lib-flexible'
import '@/assets/less/index.less'
import '@/api'
import '@/utils'

// 引入 Vant 组件
import Vant from 'vant'
import 'vant/lib/index.less'
Vue.use(Vant)

// 引入 Vegeta 桥接（生产环境）
if (process.env.VUE_APP_PLATFORM === 'app') {
  try {
    window.Vegeta.hyDock.initTitleStyle({ showTitleBar: false })
  } catch (e) {
    console.log('Vegeta 桥接初始化失败', e)
  }
}

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
```

- [ ] **Step 2: 创建 src/App.vue**

```vue
<template>
  <div id="app">
    <keep-alive :max="5">
      <router-view :key="$route.fullPath" v-if="$route.meta.keepAlive" />
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="less">
#app {
  width: 100%;
  min-height: 100vh;
  background: #f5f6fa;
}
</style>
```

- [ ] **Step 3: 验证开发环境**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && npm run dev`
Expected: Vue CLI 服务启动成功，浏览器自动打开

- [ ] **Step 4: Commit**

```bash
git add src/main.js src/App.vue
git commit -m "feat: add main entry and App.vue with keep-alive router view"
```

---

## Task 9: 共享组件 - 容器组件

**Files:**
- Create: `packages/components/container-view.vue`

- [ ] **Step 1: 创建 container-view.vue**

```vue
<template>
  <div class="container-view">
    <van-nav-bar
      :title="title"
      :left-arrow="leftArrow"
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="onClickLeft"
    >
      <template #right>
        <van-icon v-if="closeWindow" name="cross" @click="onClose" />
      </template>
    </van-nav-bar>
    <div class="container-content">
      <slot />
    </div>
  </div>
</template>

<script>
export default {
  name: 'ContainerView',
  props: {
    title: {
      type: String,
      default: ''
    },
    leftArrow: {
      type: Boolean,
      default: true
    },
    closeWindow: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onClickLeft() {
      this.$router.back()
    },
    onClose() {
      if (window.Vegeta && window.Vegeta.hyDock) {
        window.Vegeta.hyDock.close()
      }
    }
  }
}
</script>

<style scoped lang="less">
.container-view {
  min-height: 100vh;
  background: #f5f6fa;
}
.container-content {
  padding: 12px 16px;
}
/deep/ .van-nav-bar {
  background: transparent;
  .van-nav-bar__title {
    color: #323233;
    font-size: 18px;
  }
  .van-nav-bar__arrow {
    color: #1989fa;
  }
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add packages/components/container-view.vue
git commit -m "feat: add container-view component with nav bar and slot"
```

---

## Task 10: 共享组件 - 空状态组件

**Files:**
- Create: `packages/components/empty-view.vue`

- [ ] **Step 1: 创建 empty-view.vue**

```vue
<template>
  <div class="empty-view">
    <van-image v-if="image" :src="image" class="empty-image" />
    <div class="empty-description">{{ description }}</div>
  </div>
</template>

<script>
export default {
  name: 'EmptyView',
  props: {
    description: {
      type: String,
      default: '暂无数据'
    },
    image: {
      type: String,
      default: ''
    }
  }
}
</script>

<style scoped lang="less">
.empty-view {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
}
.empty-image {
  width: 160px;
  height: 160px;
}
.empty-description {
  margin-top: 16px;
  font-size: 14px;
  color: #969799;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add packages/components/empty-view.vue
git commit -m "feat: add empty-view component for empty state display"
```

---

## Task 11: 共享组件 - 单元项组件

**Files:**
- Create: `packages/components/cell-item.vue`

- [ ] **Step 1: 创建 cell-item.vue**

```vue
<template>
  <div class="cell-item">
    <div class="cell-name" :style="{ fontSize: fontSize + 'px' }">{{ name }}</div>
    <div class="cell-value-wrap">
      <span class="cell-value" :style="{ fontSize: fontSize + 'px' }">{{ value }}</span>
      <span v-if="unit" class="cell-unit">{{ unit }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CellItem',
  props: {
    name: {
      type: String,
      default: ''
    },
    value: {
      type: [String, Number],
      default: ''
    },
    unit: {
      type: String,
      default: ''
    },
    fontSize: {
      type: Number,
      default: 14
    }
  }
}
</script>

<style scoped lang="less">
.cell-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0;
}
.cell-name {
  color: #646566;
  flex-shrink: 0;
}
.cell-value-wrap {
  display: flex;
  align-items: center;
}
.cell-value {
  color: #323233;
  font-weight: 500;
}
.cell-unit {
  color: #969799;
  font-size: 12px;
  margin-left: 4px;
}
</style>
```

- [ ] **Step 2: Commit**

```bash
git add packages/components/cell-item.vue
git commit -m "feat: add cell-item component for label-value display"
```

---

## Task 12: 共享组件 - 组件注册入口

**Files:**
- Create: `packages/components/index.js`
- Create: `src/components/index.js`

- [ ] **Step 1: 创建 packages/components/index.js**

```javascript
let components = []
const componentList = require.context('.', true, /\.vue$/)
componentList.keys().forEach((val) => {
  const value = componentList(val)
  components.push(value.default)
})

const install = (Vue) => {
  if (install.installed) return
  install.installed = true
  components.forEach((component) => {
    Vue.component(component.name, component)
  })
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install,
  ...components
}
```

- [ ] **Step 2: 创建 src/components/index.js**

```javascript
export * from '#/components'
import components from '#/components'
export default components
```

- [ ] **Step 3: Commit**

```bash
git add packages/components/index.js src/components/index.js
git commit -m "feat: add component auto-registration entry"
```

---

## Task 13: 首页模块迁移

**Files:**
- Create: `src/views/home/index.vue`
- Create: `packages/views/home/index.vue`

- [ ] **Step 1: 创建 src/views/home/index.vue**

从原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/home/index.vue` 迁移内容，转换为 JavaScript（去除 TypeScript 类型）：

```vue
<template>
  <div class="page-home">
    <van-nav-bar
      title="现场服务助手"
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
    />
    <div class="header-banner">
      <div class="app-title">现场服务助手</div>
      <div class="app-desc">为您提供全方位的现场服务</div>
    </div>
    <div class="content">
      <div
        v-for="item in menuList"
        :key="item.path"
        class="menu-card"
        @click="goPage(item.path)"
      >
        <div class="card-icon" :style="{ background: item.bgColor }">
          <van-icon :name="item.icon" size="28" color="#fff" />
        </div>
        <div class="card-info">
          <div class="card-title">{{ item.title }}</div>
          <div class="card-desc">{{ item.desc }}</div>
        </div>
        <van-icon name="arrow" color="#c8c9cc" class="card-arrow" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
      menuList: [
        { path: '/user-query', title: '用户查询', desc: '查询用户信息及工程师档案', icon: 'contact', bgColor: '#2b6ef7' },
        { path: '/panorama', title: '服务全景', desc: '客户服务概况与时间轴看板', icon: 'chart-trending-o', bgColor: '#07c160' },
        { path: '/register', title: '现场登记', desc: '登记现场服务工单信息', icon: 'edit', bgColor: '#ff976a' },
        { path: '/workbench', title: '我的台账', desc: '个人工作记录与任务台账', icon: 'manager-o', bgColor: '#1989fa' }
      ]
    }
  },
  methods: {
    goPage(path) {
      this.$router.push(path)
    }
  }
}
</script>

<style scoped lang="less">
.page-home {
  min-height: 100vh;
  background: linear-gradient(180deg, #2b6ef7 0%, #4a8af7 100%);
}
.header-banner {
  padding: 20px 24px 40px;
  text-align: center;
  .app-title {
    font-size: 22px;
    font-weight: 600;
    color: #fff;
    margin-bottom: 8px;
  }
  .app-desc {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
  }
}
.content {
  border-radius: 16px 16px 0 0;
  background: #f5f6fa;
  padding: 20px 16px;
  min-height: calc(100vh - 160px);
}
.menu-card {
  display: flex;
  align-items: center;
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}
.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.card-info {
  flex: 1;
  margin-left: 14px;
}
.card-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}
.card-desc {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}
.card-arrow {
  flex-shrink: 0;
}
</style>
```

- [ ] **Step 2: 同步到 packages**

复制 `src/views/home/index.vue` 到 `packages/views/home/index.vue`

- [ ] **Step 3: Commit**

```bash
git add src/views/home/ packages/views/home/
git commit -m "feat: migrate home page module with menu cards"
```

---

## Task 14: 用户查询模块迁移

**Files:**
- Create: `src/views/user-query/index.vue`
- Create: `src/views/user-query/result.vue`
- Create: `packages/views/user-query/index.vue`
- Create: `packages/views/user-query/result.vue`

- [ ] **Step 1: 从原型迁移用户查询首页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/user-query/index.vue`，转换为 JavaScript，保存到 `src/views/user-query/index.vue`

- [ ] **Step 2: 从原型迁移查询结果页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/user-query/result.vue`，转换为 JavaScript，保存到 `src/views/user-query/result.vue`

- [ ] **Step 3: 同步到 packages**

复制 `src/views/user-query/` 到 `packages/views/user-query/`

- [ ] **Step 4: Commit**

```bash
git add src/views/user-query/ packages/views/user-query/
git commit -m "feat: migrate user-query module with search form and result list"
```

---

## Task 15: 工程师档案模块迁移

**Files:**
- Create: `src/views/engineer/index.vue`
- Create: `src/views/engineer/detail.vue`
- Create: `src/views/engineer/history.vue`
- Create: `packages/views/engineer/index.vue`
- Create: `packages/views/engineer/detail.vue`
- Create: `packages/views/engineer/history.vue`

- [ ] **Step 1: 从原型迁移工程师列表页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/engineer/index.vue`，转换为 JavaScript，保存到 `src/views/engineer/index.vue`

- [ ] **Step 2: 从原型迁移档案详情页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/engineer/detail.vue`，转换为 JavaScript，保存到 `src/views/engineer/detail.vue`

- [ ] **Step 3: 从原型迁移历史变更页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/engineer/history.vue`，转换为 JavaScript，保存到 `src/views/engineer/history.vue`

- [ ] **Step 4: 同步到 packages**

复制 `src/views/engineer/` 到 `packages/views/engineer/`

- [ ] **Step 5: Commit**

```bash
git add src/views/engineer/ packages/views/engineer/
git commit -m "feat: migrate engineer module with list, detail, and history pages"
```

---

## Task 16: 服务全景模块迁移

**Files:**
- Create: `src/views/panorama/index.vue`
- Create: `src/views/panorama/user-select.vue`
- Create: `src/views/panorama/record-detail.vue`
- Create: `packages/views/panorama/index.vue`
- Create: `packages/views/panorama/user-select.vue`
- Create: `packages/views/panorama/record-detail.vue`

- [ ] **Step 1: 从原型迁移服务全景首页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/panorama/index.vue`，转换为 JavaScript，保存到 `src/views/panorama/index.vue`

- [ ] **Step 2: 从原型迁移用户选择页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/panorama/user-select.vue`，转换为 JavaScript，保存到 `src/views/panorama/user-select.vue`

- [ ] **Step 3: 从原型迁移服务记录详情页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/panorama/record-detail.vue`，转换为 JavaScript，保存到 `src/views/panorama/record-detail.vue`

- [ ] **Step 4: 同步到 packages**

复制 `src/views/panorama/` 到 `packages/views/panorama/`

- [ ] **Step 5: Commit**

```bash
git add src/views/panorama/ packages/views/panorama/
git commit -m "feat: migrate panorama module with overview, user-select, and record-detail pages"
```

---

## Task 17: 现场登记模块迁移

**Files:**
- Create: `src/views/register/index.vue`
- Create: `src/views/register/success.vue`
- Create: `packages/views/register/index.vue`
- Create: `packages/views/register/success.vue`

- [ ] **Step 1: 从原型迁移现场登记首页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/register/index.vue`，转换为 JavaScript，保存到 `src/views/register/index.vue`

- [ ] **Step 2: 从原型迁移提交成功页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/register/success.vue`，转换为 JavaScript，保存到 `src/views/register/success.vue`

- [ ] **Step 3: 同步到 packages**

复制 `src/views/register/` 到 `packages/views/register/`

- [ ] **Step 4: Commit**

```bash
git add src/views/register/ packages/views/register/
git commit -m "feat: migrate register module with form and success pages"
```

---

## Task 18: 我的台账模块迁移

**Files:**
- Create: `src/views/workbench/index.vue`
- Create: `src/views/workbench/detail.vue`
- Create: `src/views/workbench/filter.vue`
- Create: `src/views/workbench/task-handle.vue`
- Create: `packages/views/workbench/index.vue`
- Create: `packages/views/workbench/detail.vue`
- Create: `packages/views/workbench/filter.vue`
- Create: `packages/views/workbench/task-handle.vue`

- [ ] **Step 1: 从原型迁移台账列表页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/workbench/index.vue`，转换为 JavaScript，保存到 `src/views/workbench/index.vue`

- [ ] **Step 2: 从原型迁移工单详情页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/workbench/detail.vue`，转换为 JavaScript，保存到 `src/views/workbench/detail.vue`

- [ ] **Step 3: 从原型迁移筛选条件页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/workbench/filter.vue`，转换为 JavaScript，保存到 `src/views/workbench/filter.vue`

- [ ] **Step 4: 从原型迁移任务处理页**

读取原型 `D:/workspace/plugin-lowvoltage-assistant/file/extracted/field-service-app/src/views/workbench/task-handle.vue`，转换为 JavaScript，保存到 `src/views/workbench/task-handle.vue`

- [ ] **Step 5: 同步到 packages**

复制 `src/views/workbench/` 到 `packages/views/workbench/`

- [ ] **Step 6: Commit**

```bash
git add src/views/workbench/ packages/views/workbench/
git commit -m "feat: migrate workbench module with list, detail, filter, and task-handle pages"
```

---

## Task 19: 插件主入口组件

**Files:**
- Create: `packages/views/lowvoltagePlugin.vue`
- Create: `packages/index.js`

- [ ] **Step 1: 创建 lowvoltagePlugin.vue**

```vue
<template>
  <div class="lowvoltage-plugin">
    <keep-alive :max="5">
      <router-view v-if="$route.meta.keepAlive" />
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" />
  </div>
</template>

<script>
export default {
  name: 'LowvoltagePlugin',
  props: {
    initialRoute: {
      type: String,
      default: '/home'
    }
  },
  mounted() {
    if (this.initialRoute && this.$router.currentRoute.path === '/') {
      this.$router.replace(this.initialRoute)
    }
  }
}
</script>

<style scoped lang="less">
.lowvoltage-plugin {
  width: 100%;
  min-height: 100vh;
  background: #f5f6fa;
}
</style>
```

- [ ] **Step 2: 创建 packages/index.js**

```javascript
import lowvoltagePlugin from './views/lowvoltagePlugin'
import homeView from './views/home'
import userQueryView from './views/user-query'
import engineerView from './views/engineer'
import panoramaView from './views/panorama'
import registerView from './views/register'
import workbenchView from './views/workbench'
import components from './components'
import utils from './utils'
import api from './api'

const allComponents = [
  lowvoltagePlugin,
  homeView,
  userQueryView,
  engineerView,
  panoramaView,
  registerView,
  workbenchView
]

const install = (Vue, options = {}) => {
  if (install.installed) return
  install.installed = true

  // 注册所有组件
  allComponents.forEach((component) => {
    Vue.component(component.name, component)
  })

  // 注册共享组件
  Vue.use(components)

  // 挂载工具函数
  Vue.prototype.$toast = utils.toast
  Vue.prototype.$dialog = utils.dialog
  window.$Api = api
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install,
  lowvoltagePlugin,
  homeView,
  userQueryView,
  engineerView,
  panoramaView,
  registerView,
  workbenchView,
  components,
  utils,
  api
}

export {
  lowvoltagePlugin,
  homeView,
  userQueryView,
  engineerView,
  panoramaView,
  registerView,
  workbenchView,
  components,
  utils,
  api
}
```

- [ ] **Step 3: Commit**

```bash
git add packages/views/lowvoltagePlugin.vue packages/index.js
git commit -m "feat: add plugin main entry with Vue install method"
```

---

## Task 20: 构建验证与测试

**Files:**
- Modify: `package.json`（已创建）

- [ ] **Step 1: 验证开发模式**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && npm run dev`
Expected: Vue CLI dev server 启动成功，浏览器打开首页

- [ ] **Step 2: 验证生产构建**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && npm run build`
Expected: dist 目录生成，dist_zip 目录生成 zip 文件

- [ ] **Step 3: 验证库构建**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && npm run lib`
Expected: lib 目录生成 lowvoltagePlugin.umd.min.js 等文件

- [ ] **Step 4: 检查构建产物**

Run: `ls D:/workspace/plugin-lowvoltage-assistant/dist_zip/`
Expected: 看到 zip 压缩包

Run: `ls D:/workspace/plugin-lowvoltage-assistant/lib/`
Expected: 看到 lowvoltagePlugin 相关 js/css 文件

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "feat: verify build outputs for dev, prod, and lib modes"
```

---

## Task 21: 最终整合提交

**Files:**
- Modify: `docs/superpowers/specs/2026-06-23-lowvoltage-assistant-framework-design.md`（更新迁移清单）

- [ ] **Step 1: 更新设计文档迁移清单**

将设计文档中的迁移清单全部标记为已完成 `- [x]`

- [ ] **Step 2: 确认所有文件已提交**

Run: `cd D:/workspace/plugin-lowvoltage-assistant && git status`
Expected: working tree clean

- [ ] **Step 3: 创建整合提交**

```bash
git add -A
git commit -m "feat: complete framework setup - all modules migrated and verified"
```

---

## Spec Coverage Check

| Spec Section | Covered Tasks |
|--------------|---------------|
| 1. 项目概述 | Task 1 (init), Task 20 (verify) |
| 2. 项目架构 | Task 1, Task 8, Task 19 |
| 2.2 路径别名 | Task 1 (vue.config.js) |
| 3.1 API层设计 | Task 4 |
| 3.2 路由模块设计 | Task 7 |
| 3.3 Store模块设计 | Task 6 |
| 4. 共享组件设计 | Task 9-12 |
| 5. 样式系统设计 | Task 2 |
| 6. 工具函数设计 | Task 3 |
| 7. 页面模块设计 | Task 13-18 |
| 8. 构建配置 | Task 1, Task 20 |
| 9. IGW平台集成 | Task 5, Task 8 (main.js) |
| 10. 插件导出模式 | Task 19 |
| 12. 迁移清单 | Task 13-18, Task 21 |

---

## Placeholder Scan Results

- ✅ No "TBD" or "TODO" patterns found
- ✅ All code blocks contain complete implementation
- ✅ No "similar to Task N" references
- ✅ All file paths are exact and complete
- ✅ All API codes are placeholders but clearly marked as "待补充实际code"

---

## Type Consistency Check

- ✅ `window.$Api.request` used consistently
- ✅ `window.$toast` and `window.$dialog` used consistently
- ✅ `Vegeta.hyDock` method names consistent across all usages
- ✅ Component names match in definition and registration
- ✅ Route names match path definitions