import { callRestful } from '@utils/vegeta-base'

const callRestfulApi = async (api, data) => {
  console.table('服务编码', api)
  console.table('body入参', data)
  const params = {
    inputRules: api.type,
    code: api.code,
    data: data.body,
    config: data.config,
    headers: data.headers
  }
  if (api.srvCode) {
    params.data = {
      data: data.body,
      srvCode: api.srvCode,
      appCode: api.appCode || 'EMSS15'
    }
  }
  console.log('请求参数====', JSON.stringify(params))
  return new Promise((resolve, reject) => {
    window.Vegeta.hyDock.request(params).then((res) => {
      console.log('请求返回成功====', res)
      let result = res
      console.log('VUE_APP_PLATFORM', process.env.VUE_APP_PLATFORM)
      if (process.env.VUE_APP_PLATFORM === 'app') {
        result = result && result.data
      }
      resolve(result)
    }).catch((error) => {
      console.log('请求返回失败====')
      console.log(JSON.stringify(error))
      reject(error)
    })
  })
}

const request = (api, body, headers = {}, config = {}) => {
  return callRestfulApi(api, { body, headers, config })
}

window.$Api = { request }

export default { request }
