/** 接口列表 */

// 用户查询相关接口
export const queryUserList = {
  code: "EMSS_20260624001",
  srvCode: "EMSS_20260624001",
  type: "rest"
}

export const queryCustomerInfo = {
  code: "EMSS_20260624004",
  srvCode: "EMSS_20260624004",
  type: "rest"
}

// 工程师档案接口
export const queryEngineerDetail = {
  code: "EMSS_20260624002",
  srvCode: "EMSS_20260624002",
  type: "rest"
}

export const queryEngineerHistory = {
  code: "EMSS_20260624003",
  srvCode: "EMSS_20260624003",
  type: "rest"
}

// 服务全景接口
export const queryServicePanorama = {
  code: "EMSS_xxxxxx",
  srvCode: "EMSS_xxxxxx",
  type: "rest"
}

export const queryOrderStats = {
  code: "EMSS_20260624007",
  srvCode: "EMSS_20260624007",
  type: "rest"
}

export const queryOrderList = {
  code: "EMSS_20260624008",
  srvCode: "EMSS_20260624008",
  type: "rest"
}

// 工单接口
export const queryOrderInfo = {
  code: "EMSS_20260624005",
  srvCode: "EMSS_20260624005",
  type: "rest"
}

export const queryProcessHistory = {
  code: "EMSS_20260624006",
  srvCode: "EMSS_20260624006",
  type: "rest"
}

// 现场登记接口
export const queryBizType = {
  code: "EMSS_20260624014",
  srvCode: "EMSS_20260624014",
  type: "rest"
}

export const submitRegister = {
  code: "EMSS_20260624009",
  srvCode: "EMSS_20260624009",
  type: "rest"
}

// 台账接口
export const queryWorkbenchStats = {
  code: "EMSS_20260624010",
  srvCode: "EMSS_20260624010",
  type: "rest"
}

export const queryTodoList = {
  code: "EMSS_20260624011",
  srvCode: "EMSS_20260624011",
  type: "rest"
}

export const queryDoneList = {
  code: "EMSS_20260624012",
  srvCode: "EMSS_20260624012",
  type: "rest"
}

// 任务处理接口
export const submitRecord = {
  code: "EMSS_20260624013",
  srvCode: "EMSS_20260624013",
  type: "rest"
}
