import toast from './toast'
import dialog from './dialog'
import { setStorage, getStorage } from './storage'
import { camelCaseToLine, lineToCamelCase, objectCamelCaseToLine, objectLineToCamelCase } from './camelCase'

export { toast, dialog, setStorage, getStorage, camelCaseToLine, lineToCamelCase, objectCamelCaseToLine, objectLineToCamelCase }

export default {
  toast,
  dialog,
  setStorage,
  getStorage,
  camelCaseToLine,
  lineToCamelCase,
  objectCamelCaseToLine,
  objectLineToCamelCase
}
