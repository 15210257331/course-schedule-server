export function setStorage(key, value) {
  if (typeof value !== 'string') {
    value = JSON.stringify(value)
  }
  window.localStorage.setItem(key, value)
}

export function getStorage(key) {
  let value = window.localStorage.getItem(key)
  if (value !== null) {
    try {
      return JSON.parse(value)
    } catch (e) {
      return value
    }
  } else {
    return null
  }
}
