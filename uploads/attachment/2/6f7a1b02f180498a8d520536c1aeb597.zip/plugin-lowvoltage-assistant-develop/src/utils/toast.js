import { Toast } from 'vant'

Toast.setDefaultOptions('loading', { forbidClick: true })

const show = (message) => {
  let item = message
  if (item instanceof Object) {
    item = JSON.stringify(item)
  }
  if (typeof item !== 'string') {
    console.error(item)
    return
  }
  Toast(item)
}

const loading = (message) => {
  Toast.loading({
    message: message || '加载中...',
    forbidClick: true,
    duration: 0
  })
}

const hidden = () => {
  Toast.clear()
}

const clear = () => {
  Toast.clear()
}

window.$toast = { show, loading, hidden, clear }

export default { show, loading, hidden, clear }
