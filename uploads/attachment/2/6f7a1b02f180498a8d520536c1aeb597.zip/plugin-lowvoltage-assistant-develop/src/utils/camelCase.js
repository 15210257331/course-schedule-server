export function camelCaseToLine(str) {
  return str.replace(/([A-Z])/g, '_$1').toLowerCase()
}

export function lineToCamelCase(str) {
  return str.replace(/_(\w)/g, (all, letter) => letter.toUpperCase())
}

export function objectCamelCaseToLine(obj) {
  const result = {}
  for (const key in obj) {
    result[camelCaseToLine(key)] = obj[key]
  }
  return result
}

export function objectLineToCamelCase(obj) {
  const result = {}
  for (const key in obj) {
    result[lineToCamelCase(key)] = obj[key]
  }
  return result
}
