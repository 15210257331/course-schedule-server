import { Dialog } from 'vant'

const alert = (message, title) => {
  return new Promise((resolve) => {
    Dialog.alert({
      title,
      message,
      confirmButtonColor: '#1989fa'
    }).then(() => {
      resolve()
    })
  })
}

const confirm = (message, title = '提示') => {
  return new Promise((resolve) => {
    Dialog.confirm({
      title,
      message,
      confirmButtonColor: '#1989fa'
    })
      .then(() => {
        resolve()
      })
      .catch(() => {})
  })
}

window.$dialog = { alert, confirm }

export default { alert, confirm }
