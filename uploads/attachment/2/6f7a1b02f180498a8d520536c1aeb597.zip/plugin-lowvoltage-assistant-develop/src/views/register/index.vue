<template>
  <div class="page-register">
    <van-nav-bar
      title="现场登记"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="onBack"
    />
    <div class="page-content">
      <!-- 任务计划制定模块 -->
      <div class="section-card">
        <div class="section-title">任务计划制定</div>
        <van-form @submit="onSubmit" ref="formRef">
          <van-field
            name="bizType"
            label="业务类型"
            required
            :rules="[{ required: true, message: '请选择业务类型' }]"
          >
            <template #input>
              <van-radio-group v-model="form.bizType" direction="horizontal">
                <van-radio
                  v-for="t in bizTypes"
                  :key="t.value"
                  :name="t.value"
                  class="biz-radio"
                >{{ t.label }}</van-radio>
              </van-radio-group>
            </template>
          </van-field>
          <van-field
            v-model="form.planStartDate"
            label="计划开始日期"
            placeholder="请选择"
            is-link
            readonly
            input-align="right"
            required
            :rules="[
              { required: true, message: '请选择开始日期' },
              { validator: () => !form.planEndDate || form.planStartDate <= form.planEndDate, message: '开始日期不能晚于结束日期' }
            ]"
            @click="showStartPicker = true"
          />
          <van-field
            v-model="form.planEndDate"
            label="计划结束日期"
            placeholder="请选择"
            is-link
            readonly
            input-align="right"
            required
            :rules="[
              { required: true, message: '请选择结束日期' },
              { validator: () => !form.planStartDate || form.planEndDate >= form.planStartDate, message: '结束日期不能早于开始日期' }
            ]"
            @click="showEndPicker = true"
          />
          <van-field
            v-model="form.taskDesc"
            name="taskDesc"
            label="任务描述"
            type="textarea"
            placeholder="请输入任务描述"
            rows="4"
            autosize
            maxlength="512"
            show-word-limit
            required
            :rules="[{ required: true, message: '请输入任务描述' }]"
          />
        </van-form>
      </div>
      <!-- 关联用户模块 -->
      <div class="section-card">
        <div class="section-title">
          <span>关联用户</span>
          <van-button size="small" round :color="themeColor" @click="onSelectUser">选择</van-button>
        </div>
        <div class="user-range-tip">用户范围：居民、低压非居</div>
        <div v-if="selectedUsers.length === 0" class="empty-tip">暂未选择关联用户</div>
        <div v-else class="selected-user-list">
          <div
            v-for="(item, idx) in selectedUsers"
            :key="idx"
            class="selected-user-card"
          >
            <div class="selected-user-info">
              <div class="sel-row">
                <span class="sel-label">用户编号</span>
                <span class="sel-value">{{ item.userNo }}</span>
              </div>
              <div class="sel-row">
                <span class="sel-label">用户名称</span>
                <span class="sel-value">{{ item.userName }}</span>
              </div>
              <div class="sel-row">
                <span class="sel-label">用电地址</span>
                <span class="sel-value">{{ item.address }}</span>
              </div>
            </div>
            <van-icon name="delete" class="delete-icon" color="#ee0a24" @click.native="removeUser(idx)" />
          </div>
        </div>
        <div v-if="selectedUsers.length > 0" class="selected-count">
          已选择 <van-tag type="primary" round>{{ selectedUsers.length }}</van-tag> 个用户
        </div>
      </div>
    </div>
    <div class="submit-area">
      <van-button round block type="primary" @click="onSubmit" :loading="submitting" :disabled="selectedUserIds.length === 0">
        提交
      </van-button>
    </div>
    <!-- 日期弹窗 -->
    <van-popup v-model="showStartPicker" position="bottom" round>
      <van-datetime-picker
        v-model="startDate"
        type="date"
        title="选择开始日期"
        @confirm="onStartConfirm"
        @cancel="showStartPicker = false"
      />
    </van-popup>
    <van-popup v-model="showEndPicker" position="bottom" round>
      <van-datetime-picker
        v-model="endDate"
        type="date"
        title="选择结束日期"
        :min-date="startDate"
        @confirm="onEndConfirm"
        @cancel="showEndPicker = false"
      />
    </van-popup>
  </div>
</template>

<script>
import { queryBizType, submitRegister } from '@/api/const'
import { mapState, mapActions } from 'vuex'

export default {
  name: 'RegisterPage',
  data() {
    return {
      // 关联用户
      selectedUserIds: [],
      selectedUsers: [],
      // 任务计划
      form: {
        bizType: '01',
        planStartDate: '',
        planEndDate: '',
        taskDesc: ''
      },
      bizTypes: [],
      startDate: new Date(),
      endDate: new Date(),
      showStartPicker: false,
      showEndPicker: false,
      submitting: false
    }
  },
  computed: {
    ...mapState('common', ['userInfo']),
    themeColor() {
      return ['app'].includes(process.env.VUE_APP_TYPE) ? '#28B67F' : '#1890FF'
    }
  },
  async mounted() {
    try {
      await this.fetchUserInfo()
    } catch (e) {
      console.log('获取用户信息失败', e)
    }

    const navFlag = sessionStorage.getItem('register_nav_flag')

    if (this.$route.query.from === 'user-select') {
      // 从用户选择页确认返回，恢复已选用户和表单数据
      this.loadSelectedUsers()
      this.loadFormData()
      sessionStorage.removeItem('register_nav_flag')
    } else if (navFlag === 'to-user-select') {
      // 从用户选择页按后退返回，保留表单数据，清空已选用户
      this.loadFormData()
      this.selectedUsers = []
      this.selectedUserIds = []
      sessionStorage.removeItem('register_nav_flag')
      sessionStorage.removeItem('register_selected_users')
    } else {
      // 首次进入，清空所有数据
      sessionStorage.removeItem('register_selected_users')
      sessionStorage.removeItem('register_form_data')
      this.selectedUsers = []
      this.selectedUserIds = []
    }
    this.loadBizTypes()
  },
  methods: {
    ...mapActions('common', ['fetchUserInfo']),
    onBack() {
      // 如果是从用户选择页过来的，直接返回首页，避免回退到选择页
      if (this.$route.query.from === 'user-select') {
        this.$router.replace('/home')
      } else {
        this.$router.back()
      }
    },
    loadSelectedUsers() {
      const saved = sessionStorage.getItem('register_selected_users')
      if (saved) {
        try {
          const parsed = JSON.parse(saved)
          this.selectedUsers = parsed
          this.selectedUserIds = parsed.map(u => u.id)
        } catch (e) { /* ignore */ }
      }
    },
    loadFormData() {
      const saved = sessionStorage.getItem('register_form_data')
      if (saved) {
        try {
          const parsed = JSON.parse(saved)
          Object.assign(this.form, parsed)
          // 恢复日期选择器的默认值
          if (parsed.planStartDate) this.startDate = new Date(parsed.planStartDate)
          if (parsed.planEndDate) this.endDate = new Date(parsed.planEndDate)
        } catch (e) { /* ignore */ }
      }
    },
    onSelectUser() {
      // 保存当前表单数据，避免返回后丢失
      sessionStorage.setItem('register_form_data', JSON.stringify(this.form))
      sessionStorage.setItem('register_nav_flag', 'to-user-select')
      // 清除上次的选中条件
      this.selectedUsers = []
      this.selectedUserIds = []
      this.$router.push('/register/user-select')
    },
    removeUser(idx) {
      this.selectedUsers.splice(idx, 1)
      this.selectedUserIds = this.selectedUsers.map(u => u.id)
      sessionStorage.setItem('register_selected_users', JSON.stringify(this.selectedUsers))
    },
    async loadBizTypes() {
      try {
        const params = { codeType: 'snypBizType' }
        const res = await window.$Api.request(queryBizType, params)
        const list = res?.code === '00000' ? (Array.isArray(res.data) ? res.data : []) : []
        this.bizTypes = list.map(item => ({
          value: item.codeClsVal,
          label: item.codeClsValName
        }))
      } catch (err) {
        console.log('获取业务类型失败', err)
      }
    },
    onStartConfirm(value) {
      this.startDate = value
      this.showStartPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.form.planStartDate = fmt(value)
    },
    onEndConfirm(value) {
      this.endDate = value
      this.showEndPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.form.planEndDate = fmt(value)
    },
    async onSubmit() {
      if (this.selectedUserIds.length === 0) {
        window.$toast.show('请至少选择一个用户')
        return
      }
      this.submitting = true
      try {
        const userInfo = await this.fetchUserInfo()
        const params = {
          bizType: this.form.bizType,
          planStartDate: this.form.planStartDate,
          planEndDate: this.form.planEndDate,
          taskDesc: this.form.taskDesc || undefined,
          userNos: this.selectedUserIds,
          creatorId: userInfo?.userNo || '',
          creatorName: userInfo?.userName || '',
          orgNo: userInfo?.orgNo || ''
        }
        const res = await window.$Api.request(submitRegister, params)
        console.log('submitRegister 返回原始数据:', JSON.stringify(res))
        // 统一报文：res.code === '00000' 为成功，数据在 res.data
        if (res?.code === '00000') {
          // 提交成功，清除已保存的草稿数据
          sessionStorage.removeItem('register_form_data')
          sessionStorage.removeItem('register_selected_users')
          sessionStorage.removeItem('register_nav_flag')
          window.$toast.show('提交成功')
          setTimeout(() => {
            this.$router.replace('/home')
          }, 1500)
        } else {
          window.$toast.show(res?.message || '提交失败，请重试')
          this.submitting = false
        }
      } catch (error) {
        window.$toast.show(error.message?.message || error.message || '提交失败，请重试')
      } finally {
        this.submitting = false
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-register {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 70px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.user-range-tip {
  padding: 4px 16px 8px;
  font-size: 12px;
  color: #999;
}
.empty-tip {
  padding: 24px 16px;
  text-align: center;
  font-size: 13px;
  color: #ccc;
}
.selected-user-list {
  padding: 0 16px 8px;
}
.selected-user-card {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  margin-bottom: 8px;
  background: #f7f8fa;
  border-radius: 6px;
}
.selected-user-info {
  flex: 1;
}
.sel-row {
  display: flex;
  line-height: 1.7;
}
.sel-label {
  width: 64px;
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
.sel-value {
  flex: 1;
  font-size: 12px;
  color: #333;
}
.delete-icon {
  flex-shrink: 0;
  margin-left: 8px;
  padding: 4px;
}
.selected-count {
  padding: 10px 16px;
  font-size: 13px;
  color: #666;
  border-top: 1px solid #f5f6fa;
}
.biz-radio {
  margin-right: 8px;
  margin-bottom: 6px;
}
.submit-area {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 8px 16px;
  padding-bottom: calc(8px + env(safe-area-inset-bottom));
  background: #fff;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.06);
  z-index: 10;
}
</style>
