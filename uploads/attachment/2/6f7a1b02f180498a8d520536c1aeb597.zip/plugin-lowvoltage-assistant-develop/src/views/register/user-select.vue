<template>
  <container-view title="选择关联用户">
    <div class="div-head">
      <field-input label="供电单位" v-model="orgName" @click.native="onSelectOrg" :is-link="isMge" readonly />
      <field-input label="用户编号" v-model="filter.userNo" clearable />
      <field-input label="用户名称" v-model="filter.userName" clearable />
      <field-input label="用户地址" v-model="filter.address" :border="false" clearable />
    </div>
    <button-view :fontColor="themeColor" rightStr="查询" :clickRight="onSearch" />
    <div class="list-wrap">
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        :immediate-check="false"
        @load="onLoad"
      >
        <div class="select-all-bar" v-if="userList.length > 0">
          <van-checkbox
            :value="allSelected"
            @click="onToggleAll"
            shape="square"
          >全选</van-checkbox>
          <span class="select-count">已选 {{ selectedIds.length }} 项</span>
        </div>
        <div
          v-for="item in userList"
          :key="item.id"
          class="user-card"
          :class="{ selected: selectedIds.includes(item.id) }"
          @click="toggleUser(item)"
        >
          <div class="card-check">
            <van-icon
              :name="selectedIds.includes(item.id) ? 'checked' : 'circle'"
              :color="selectedIds.includes(item.id) ? themeColor : '#c8c9cc'"
              size="20"
            />
          </div>
          <div class="card-body">
            <div class="card-row">
              <span class="row-label">用户编号</span>
              <span class="row-value">{{ item.userNo }}</span>
            </div>
            <div class="card-row">
              <span class="row-label">用户名称</span>
              <span class="row-value">{{ item.userName }}</span>
            </div>
            <div class="card-row">
              <span class="row-label">用电地址</span>
              <span class="row-value">{{ item.address }}</span>
            </div>
            <div class="card-row">
              <span class="row-label">客户联系人</span>
              <span class="row-value">{{ item.contactPerson }}</span>
            </div>
            <div class="card-row">
              <span class="row-label">联系方式</span>
              <span class="row-value">{{ item.contactPhone }}</span>
            </div>
          </div>
        </div>
      </van-list>
      <van-empty v-if="searched && !loading && userList.length === 0" description="未找到匹配用户" />
    </div>
    <div class="bottom-bar">
      <van-button
        round
        block
        :color="themeColor"
        @click="onConfirm"
        :disabled="selectedIds.length === 0"
      >确定 ({{ selectedIds.length }})</van-button>
    </div>
  </container-view>
</template>

<script>
import ContainerView from '@/components/container-view'
import FieldInput from '@/components/field-input'
import ButtonView from '@/components/button-view'
import { OrgSelector } from '@/libs/publictools-components.umd.min'
import { queryUserList } from '@/api/const'
import { mapState, mapActions } from 'vuex'

export default {
  name: 'RegisterUserSelectPage',
  components: { ContainerView, FieldInput, ButtonView },
  data() {
    return {
      orgName: '',
      filter: {
        orgNo: '',
        userNo: '',
        userName: '',
        address: ''
      },
      userList: [],
      selectedIds: [],
      selectedUsers: [],
      pageNo: 1,
      pageSize: 10,
      total: 0,
      loading: false,
      finished: false,
      searched: false
    }
  },
  computed: {
    ...mapState('common', ['userInfo']),
    themeColor() {
      return ['app'].includes(process.env.VUE_APP_TYPE) ? '#28B67F' : '#1890FF'
    },
    isMge() {
      return this.userInfo?.orgNo && this.userInfo?.orgNo.length < 7
    },
    allSelected() {
      return this.userList.length > 0 && this.selectedIds.length === this.userList.length
    }
  },
  async mounted() {
    try {
      const userInfo = await this.fetchUserInfo()
      if (userInfo) {
        this.orgName = userInfo.orgName || ''
        this.filter.orgNo = userInfo.orgNo || ''
      }
    } catch (e) {
      console.log('获取用户信息失败', e)
    }

    // 恢复已选用户
    const saved = sessionStorage.getItem('register_selected_users')
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        this.selectedUsers = parsed
        this.selectedIds = parsed.map(u => u.id)
      } catch (e) { /* ignore */ }
    }
  },
  methods: {
    ...mapActions('common', ['fetchUserInfo']),
    async onSelectOrg() {
      const userInfo = await this.fetchUserInfo()
      if (!userInfo?.orgNo) {
        window.$toast.show('当前登录账号没有单位信息，请联系管理员维护！')
        return false
      }
      if (!this.isMge) {
        return false
      }
      OrgSelector.$show(userInfo.orgNo).then(res => {
        if (res.text && res.value) {
          this.orgName = res.text
          this.filter.orgNo = res.value
        }
      })
    },
    async onSearch() {
      this.pageNo = 1
      this.userList = []
      this.total = 0
      this.finished = false
      this.loading = false
      this.searched = true
      await this.fetchUsers()
    },
    async onLoad() {
      // 只有滚动到底部时才加载更多，首次查询由 onSearch 触发
      if (!this.searched || this.userList.length === 0) return
      await this.fetchUsers()
    },
    async fetchUsers() {
      try {
        window.$toast.loading()
        const params = {
          orgNo: this.filter.orgNo || undefined,
          userNo: this.filter.userNo || undefined,
          userName: this.filter.userName || undefined,
          address: this.filter.address || undefined,
          pageNo: this.pageNo,
          pageSize: this.pageSize
        }
        const { list, total } = await this.fetchUserListWithTotal(params)
        window.$toast.clear()

        const mapped = (Array.isArray(list) ? list : []).map(item => ({
          id: item.custNo,
          userNo: item.custNo,
          userName: item.custName,
          address: item.address,
          contactPerson: item.contactPerson,
          contactPhone: item.contactPhone
        }))

        if (this.pageNo === 1) {
          this.userList = mapped
        } else {
          this.userList = [...this.userList, ...mapped]
        }
        this.total = total
        this.pageNo++
        this.loading = false

        if (this.userList.length >= total) {
          this.finished = true
        }
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },
    async fetchUserListWithTotal(params) {
      const res = await window.$Api.request(queryUserList, params)
      if (res.code !== '00000') {
        throw new Error(res.message || '查询失败')
      }
      const list = Array.isArray(res.data) ? res.data : []
      const total = res.total ?? 0
      return { list, total }
    },
    toggleUser(item) {
      const idx = this.selectedIds.indexOf(item.id)
      if (idx > -1) {
        this.selectedIds.splice(idx, 1)
        this.selectedUsers.splice(idx, 1)
      } else {
        this.selectedIds.push(item.id)
        this.selectedUsers.push(item)
      }
    },
    onToggleAll() {
      if (this.allSelected) {
        this.selectedIds = []
        this.selectedUsers = []
      } else {
        this.selectedIds = this.userList.map(u => u.id)
        this.selectedUsers = [...this.userList]
      }
    },
    onConfirm() {
      sessionStorage.setItem('register_selected_users', JSON.stringify(this.selectedUsers))
      this.$router.push('/register?from=user-select')
    }
  }
}
</script>

<style lang="less" scoped>
.div-head {
  margin: 16px;
  border-radius: 8px;
  background-color: white;
  box-shadow: 0 2px 6px 0 rgba(61, 61, 61, 0.17);
}
.list-wrap {
  flex: 1;
  overflow-y: auto;
  padding: 0 16px;
}
.select-all-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 4px;
  font-size: 13px;
  background: #f6f9fd;
  border-radius: 6px;
  margin-bottom: 4px;
}
.select-count {
  font-size: 12px;
  color: #999;
}
.user-card {
  display: flex;
  padding: 12px;
  background: #fff;
  border-radius: 8px;
  margin-bottom: 8px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
  cursor: pointer;
  &.selected {
    background: #f0f4ff;
  }
}
.card-check {
  width: 24px;
  padding-top: 2px;
  flex-shrink: 0;
}
.card-body {
  flex: 1;
}
.card-row {
  display: flex;
  line-height: 1.8;
}
.row-label {
  width: 78px;
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
.row-value {
  flex: 1;
  font-size: 12px;
  color: #333;
  text-align: right;
}
.bottom-bar {
  padding: 12px 16px;
  padding-bottom: calc(12px + env(safe-area-inset-bottom));
  background: #fff;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.06);
}
</style>
