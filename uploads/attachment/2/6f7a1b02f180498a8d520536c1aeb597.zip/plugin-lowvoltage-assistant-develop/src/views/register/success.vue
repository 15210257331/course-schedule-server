<template>
  <div class="page-success">
    <van-nav-bar
      title="提交成功"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="goBack"
    />
    <div class="success-content">
      <van-icon name="checked" class="success-icon" color="#07c160" size="64" />
      <div class="success-title">提交成功</div>
      <div class="success-desc">现场服务登记已提交成功，可返回查看记录</div>
      <div class="btn-group">
        <van-button round block type="primary" @click="goWorkbench">
          查看我的台账
        </van-button>
        <van-button round block plain type="primary" class="btn-again" @click="goRegister">
          继续登记
        </van-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'RegisterSuccessPage',
  methods: {
    goBack() {
      this.$router.replace('/register')
    },
    goWorkbench() {
      this.$router.replace('/workbench')
    },
    goRegister() {
      this.$router.replace('/register')
    }
  }
}
</script>

<style scoped lang="less">
.page-success {
  min-height: 100vh;
  background: #f5f6fa;
}
.success-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 80px;
}
.success-icon {
  margin-bottom: 16px;
}
.success-title {
  font-size: 20px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
}
.success-desc {
  font-size: 14px;
  color: #999;
  margin-bottom: 40px;
}
.btn-group {
  width: 80%;
}
.btn-again {
  margin-top: 12px;
}
</style>