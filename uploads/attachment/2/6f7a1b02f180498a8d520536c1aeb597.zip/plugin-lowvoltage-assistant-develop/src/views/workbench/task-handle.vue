<template>
  <div class="page-handle">
    <van-nav-bar title="任务处理" left-arrow :placeholder="true" :safe-area-inset-top="true" :border="false"
      @click-left="$router.back()" />
    <div class="page-content">
      <!-- 基础信息模块 -->
      <div class="section-card">
        <div class="section-title">基础信息</div>
        <van-cell-group :border="false">
          <van-cell title="工单编号" :value="info.orderNo" :border="false" />
          <van-cell title="工单生成时间" :value="info.createTime" :border="false" />
          <van-cell title="用户编号" :value="info.userNo" :border="false" />
          <van-cell title="用户名称" :value="info.userName" :border="false" />
          <van-cell title="用电地址" :value="info.address" :border="false" />
          <van-cell title="客户联系人" :value="info.contactPerson" :border="false" />
          <van-cell title="联系方式" :value="info.contactPhone" :border="false" />
          <van-cell title="业务类型" :value="info.bizTypeName" :border="false" />
          <van-cell title="计划开始日期" :value="info.planStartDate" :border="false" />
          <van-cell title="计划结束日期" :value="info.planEndDate" :border="false" />
        </van-cell-group>
        <div class="task-desc-area">
          <div class="desc-label">任务描述</div>
          <div class="desc-text">{{ info.taskDesc }}</div>
        </div>
      </div>
      <!-- 工单处理模块 -->
      <div class="section-card">
        <div class="section-title">工单处理</div>
        <van-form @submit="onSubmit" ref="formRef">
          <van-field v-model="form.serviceDate" label="服务时间" placeholder="请选择" is-link readonly input-align="right"
            required :rules="[{ required: true, message: ' ' }]" @click="showDatePicker = true" />
          <van-field name="status" label="状态" required :rules="[{ required: true, message: '请选择状态' }]">
            <template #input>
              <van-radio-group v-model="form.status" direction="horizontal">
                <van-radio name="01">未解决</van-radio>
                <van-radio name="02">已解决</van-radio>
              </van-radio-group>
            </template>
          </van-field>
          <van-field v-model="form.content" label="服务内容" type="textarea" placeholder="请输入服务内容" rows="4" autosize
            maxlength="512" show-word-limit required :rules="[{ required: true, message: ' ' }]">
            <template #right-icon>
              <voice-record @recordEnd="onVoiceInput"></voice-record>
            </template>
          </van-field>
          <van-field v-model="form.address" label="服务地址" placeholder="请输入服务地址" clearable maxlength="128" show-word-limit
            input-align="right" />
          <ComponentUploadFile v-model="attachmentsGroupId" :max-count="9" :is-tag="false" :is-view="false"
            take-type="picture" :app-config-param="appConfigParam" :tip="''" @changeList="onAttachmentsListChange"
            style="padding: 10px 16px;" />
        </van-form>
      </div>
    </div>
    <div class="submit-btn-area">
      <van-button round block type="primary" @click="onFormSubmit" :loading="submitting">
        提交
      </van-button>
    </div>
    <!-- 历史处理记录弹窗 -->
    <van-action-sheet v-model="showHistoryPopup" title="历史处理记录">
      <div class="history-popup-body">
        <div v-if="historyList.length === 0" class="popup-empty">
          <van-empty description="暂无历史处理记录" />
        </div>
        <div v-else class="history-section">
          <div class="custom-timeline">
            <div v-for="(item, idx) in historyList" :key="idx" class="timeline-item">
              <div class="timeline-dot" :class="item.status === '02' ? 'solved' : 'unsolved'" />
              <div v-if="idx < historyList.length - 1" class="timeline-line" />
              <div class="timeline-content">
                <div class="history-card">
                  <div class="h-row"><span class="h-label">客户工程师</span><span class="h-value">{{ item.engineerName
                      }}</span>
                  </div>
                  <div class="h-row"><span class="h-label">服务时间</span><span class="h-value">{{ item.serviceDate
                      }}</span>
                  </div>
                  <div class="h-row"><span class="h-label">状态</span><span class="h-value">{{ item.statusName }}</span>
                  </div>
                  <div class="h-row"><span class="h-label">服务内容</span><span class="h-value">{{ item.content }}</span>
                  </div>
                  <div class="h-row"><span class="h-label">服务地址</span><span class="h-value">{{ item.address }}</span>
                  </div>
                  <div v-if="item.attachments && item.attachments.length > 0" class="h-row">
                    <span class="h-label">附件信息</span>
                    <div class="h-attachments">
                      <van-tag v-for="(a, ai) in item.attachments" :key="ai"
                        type="primary" size="small"
                        style="margin-right:4px;margin-bottom:4px;cursor:pointer;" @click.native="previewFile(a)">{{ a.name }}</van-tag>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </van-action-sheet>
    <van-popup v-model="showDatePicker" position="bottom" round>
      <van-datetime-picker v-model="serviceDate" type="date" title="选择服务时间" @confirm="onDateConfirm"
        @cancel="showDatePicker = false" />
    </van-popup>
  </div>
</template>

<script>
import { queryOrderInfo, submitRecord } from '@/api/const'
import { ComponentUploadFile } from '@components/sh-publictools-components'
import { mapActions } from 'vuex'
import appConfigParams from '@/config/igw-config'
import voiceRecord from '@/components/voice-record'

export default {
  name: 'TaskHandlePage',
  components: { ComponentUploadFile, voiceRecord },
  data() {
    return {
      info: {},
      form: {
        serviceDate: '',
        status: '02',
        content: '',
        address: ''
      },
      attachmentsGroupId: '',
      attachmentsList: [],
      appConfigParam: {
        centerSrc: 'flc',
        dispOpenFlag: '01',
        fileKey: 'yx2FileCenter'
      },
      serviceDate: new Date(),
      showDatePicker: false,
      showHistoryPopup: false,
      submitting: false,
      historyList: [],
      loading: true
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    ...mapActions('common', ['fetchUserInfo']),

    async loadData() {
      const orderId = this.$route.query.id
      if (!orderId) return

      try {
        this.loading = true
        window.$toast.loading()

        const res = await window.$Api.request(queryOrderInfo, { orderId })

        // 统一报文：res.code === '00000' 为成功，数据在 res.data
        const data = res?.code === '00000' ? (res.data || {}) : {}

        this.info = data

        const records = Array.isArray(data?.processRecordList) ? data.processRecordList : []
        this.historyList = records.map(item => ({
          engineerName: item.engineerName,
          serviceDate: item.serviceTime,
          status: item.processStatus,
          statusName: item.processStatusName,
          content: item.serviceContent,
          address: item.serviceAddress,
          attachments: (Array.isArray(item.attachments) ? item.attachments : []).map(a => ({
            name: a.fileName,
            type: a.fileType === '02' ? 'video' : 'image',
            picId: a.attachDtlId,
            fileName: a.fileName
          }))
        }))

        window.$toast.clear()
        this.loading = false
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },
    onDateConfirm(value) {
      this.serviceDate = value
      this.showDatePicker = false
      const y = value.getFullYear()
      const m = String(value.getMonth() + 1).padStart(2, '0')
      const d = String(value.getDate()).padStart(2, '0')
      this.form.serviceDate = `${y}-${m}-${d}`
    },
    async previewFile(item) {
      console.log("附件信息",item);
      const fileId = item.picId || item.fileId || item.attachDtlId || ''
      const dynamicPort = this.getParam('dynamicPort')
      const userInfoParam = this.getParam('userInfo')
      let authToken = ''
      try {
        const decoded = JSON.parse(decodeURI(userInfoParam))
        authToken = decoded.authToken || ''
      } catch (e) {
        authToken = ''
      }

      let fileBasePath = `http://172.20.64.153:7740/istateinvoke-server/iStateGridMaspFileDownInvoke?appName=${appConfigParams.appName}&authToken=${authToken}&key=${appConfigParams.key}&path=`
      if (process.env.VUE_APP_TYPE === 'site-prod') {
        fileBasePath = `http://127.0.0.1:${dynamicPort}/istateinvoke-server/iStateGridMaspFileDownInvoke?appName=${appConfigParams.appName}&authToken=${authToken}&key=${appConfigParams.key}&path=`
      }

      const fileUrl = `${fileBasePath}${fileId}`
      console.log('OpenFile', item)
      wx.previewFile({
        url: fileUrl,
        name: item.picName || item.fileName || item.name || '',
        size: Number('1000'),
        hidePreviewMenuList: []
      })
    },
    getParam(variable) {
      const query = window.location.search.substring(1)
      const vars = query.split('&')
      for (let i = 0; i < vars.length; i++) {
        const pair = vars[i].split('=')
        if (pair[0] === variable) {
          return pair[1]
        }
      }
      return ''
    },
    onVoiceInput(translateResult) {
      this.form.content = this.form.content + translateResult
    },
    onAttachmentsListChange(fileList) {
      this.attachmentsList = Array.isArray(fileList) ? fileList : []
    },
    onFormSubmit() {
      this.$refs.formRef.submit()
    },
    async onSubmit() {
      this.submitting = true
      try {
        const orderId = this.$route.query.id
        const userInfo = await this.fetchUserInfo()

        const attachments = this.attachmentsList
          .filter(item => item.attachDtlId)
          .map(item => ({
            fileName: item.fileName || '',
            fileType: '01',
            attachId: item.attachId || this.attachmentsGroupId || '',
            attachDtlId: item.attachDtlId
          }))

        const params = {
          orderId,
          serviceDate: this.form.serviceDate,
          processStatus: this.form.status,
          serviceContent: this.form.content,
          serviceAddress: this.form.address || undefined,
          engineerAccount: userInfo?.userNo || '',
          engineerName: userInfo?.userName || '',
          attachments: attachments.length > 0 ? attachments : undefined,
          attachId: this.attachmentsGroupId || undefined
        }

        const res = await window.$Api.request(submitRecord, params)

        // 统一报文：res.code === '00000' 为成功，数据在 res.data
        if (res?.code === '00000') {
          window.$toast.show('提交成功')
          setTimeout(() => {
            // 返回台账页，keepAlive 的 activated 会刷新统计数据
            this.$router.back()
          }, 1500)
        } else {
          window.$toast.show(res?.message || '提交失败')
          this.submitting = false
        }
      } catch (error) {
        window.$toast.show(error.message?.message || error.message || '提交失败，请重试')
      } finally {
        this.submitting = false
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-handle {
  min-height: 100vh;
  background: #f5f6fa;
}

.page-content {
  padding: 0 16px 80px;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  /* 确保内部定位元素不会脱离滚动容器 */
  position: relative;
  z-index: 1;
}

.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
  /* 创建新的层叠上下文，防止内部 fixed/absolute 定位元素随滚动漂移 */
  position: relative;
  z-index: 1;
}

.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}

.task-desc-area {
  padding: 8px 16px 16px;
}

.desc-label {
  font-size: 13px;
  color: #999;
  margin-bottom: 4px;
}

.desc-text {
  font-size: 14px;
  color: #555;
  line-height: 1.6;
}

.submit-btn-area {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 8px 16px;
  padding-bottom: calc(8px + env(safe-area-inset-bottom));
  background: #fff;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.06);
  z-index: 10;
}

.history-popup-body {
  max-height: 60vh;
  overflow-y: auto;
}

.popup-empty {
  padding: 20px 0;
}

.history-section {
  padding: 12px 16px 16px;
}

.custom-timeline {
  position: relative;
  padding-left: 20px;
}

.timeline-item {
  position: relative;
  padding-bottom: 14px;
}

.timeline-dot {
  position: absolute;
  left: -14px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #07c160;
  background: #fff;
  z-index: 1;

  &.unsolved {
    border-color: #ff976a;
  }

  &.solved {
    border-color: #07c160;
  }
}

.timeline-line {
  position: absolute;
  left: -10px;
  top: 14px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}

.timeline-item:last-child .timeline-line {
  display: none;
}

.timeline-content {
  padding-left: 4px;
}

.history-card {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}

.h-row {
  display: flex;
  line-height: 1.8;
}

.h-label {
  width: 66px;
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}

.h-value {
  flex: 1;
  font-size: 12px;
  color: #333;
  text-align: right;
}

.h-attachments {
  flex: 1;
  text-align: right;
}
</style>