<template>
  <div class="page-filter">
    <van-nav-bar
      title="筛选条件"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div class="filter-card">
        <van-field v-model="filter.custNo" label="用户编号" placeholder="请输入" clearable input-align="right" />
        <van-field v-model="filter.custName" label="用户名称" placeholder="请输入" clearable input-align="right" />
        <van-field v-model="filter.bizTypeLabel" label="业务类型" placeholder="全部" is-link readonly input-align="right" @click="showBizPicker = true" class="filter-field-link" />
        <van-field v-if="isTodo" v-model="filter.planStartDate" label="计划开始日期" placeholder="请选择" is-link readonly input-align="right" @click="showPlanStartPicker = true" class="filter-field-link" />
        <van-field v-if="isTodo" v-model="filter.planEndDate" label="计划结束日期" placeholder="请选择" is-link readonly input-align="right" @click="showPlanEndPicker = true" class="filter-field-link" />
        <van-field v-if="isDone" v-model="filter.serviceStartDate" label="服务开始日期" placeholder="请选择" is-link readonly input-align="right" @click="showSvcStartPicker = true" class="filter-field-link" />
        <van-field v-if="isDone" v-model="filter.serviceEndDate" label="服务结束日期" placeholder="请选择" is-link readonly input-align="right" @click="showSvcEndPicker = true" class="filter-field-link" />
      </div>
      <div class="btn-group">
        <van-button round block plain @click="onReset">重置</van-button>
        <van-button round block type="primary" @click="onConfirm">查询</van-button>
      </div>
    </div>
    <van-popup v-model="showBizPicker" position="bottom" round>
      <van-picker show-toolbar :columns="bizColumns" @confirm="onBizConfirm" @cancel="showBizPicker = false" title="选择业务类型" />
    </van-popup>
    <van-popup v-model="showPlanStartPicker" position="bottom" round>
      <van-datetime-picker v-model="planStartDate" type="date" title="选择计划开始日期" @confirm="onPlanStartConfirm" @cancel="showPlanStartPicker = false" />
    </van-popup>
    <van-popup v-model="showPlanEndPicker" position="bottom" round>
      <van-datetime-picker v-model="planEndDate" type="date" title="选择计划结束日期" :min-date="planStartDate" @confirm="onPlanEndConfirm" @cancel="showPlanEndPicker = false" />
    </van-popup>
    <van-popup v-model="showSvcStartPicker" position="bottom" round>
      <van-datetime-picker v-model="svcStartDate" type="date" title="选择服务开始日期" @confirm="onSvcStartConfirm" @cancel="showSvcStartPicker = false" />
    </van-popup>
    <van-popup v-model="showSvcEndPicker" position="bottom" round>
      <van-datetime-picker v-model="svcEndDate" type="date" title="选择服务结束日期" :min-date="svcStartDate" @confirm="onSvcEndConfirm" @cancel="showSvcEndPicker = false" />
    </van-popup>
  </div>
</template>

<script>
export default {
  name: 'WorkbenchFilterPage',
  data() {
    return {
      filter: {
        custNo: '',
        custName: '',
        bizType: '',
        bizTypeLabel: '',
        planStartDate: '',
        planEndDate: '',
        serviceStartDate: '',
        serviceEndDate: ''
      },
      showBizPicker: false,
      showPlanStartPicker: false,
      showPlanEndPicker: false,
      showSvcStartPicker: false,
      showSvcEndPicker: false,
      planStartDate: new Date(),
      planEndDate: new Date(),
      svcStartDate: new Date(),
      svcEndDate: new Date(),
      bizColumns: [
        { text: '全部', value: '' },
        { text: '催费通知', value: '01' },
        { text: '停电通知', value: '02' },
        { text: '诉求', value: '03' },
        { text: '现场勘察', value: '04' },
        { text: '设备更换', value: '05' },
        { text: '巡视', value: '06' },
        { text: '安全隐患', value: '07' }
      ]
    }
  },
  computed: {
    isTodo() {
      return this.$route.query.tab === 'todo'
    },
    isDone() {
      return this.$route.query.tab === 'done'
    }
  },
  methods: {
    onBizConfirm(value, index) {
      const item = this.bizColumns[index]
      this.filter.bizType = item?.value || ''
      this.filter.bizTypeLabel = item?.text || ''
      this.showBizPicker = false
    },
    onPlanStartConfirm(v) {
      this.planStartDate = v
      this.showPlanStartPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.filter.planStartDate = fmt(v)
    },
    onPlanEndConfirm(v) {
      this.planEndDate = v
      this.showPlanEndPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.filter.planEndDate = fmt(v)
    },
    onSvcStartConfirm(v) {
      this.svcStartDate = v
      this.showSvcStartPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.filter.serviceStartDate = fmt(v)
    },
    onSvcEndConfirm(v) {
      this.svcEndDate = v
      this.showSvcEndPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.filter.serviceEndDate = fmt(v)
    },
    onReset() {
      this.filter = { custNo: '', custName: '', bizType: '', bizTypeLabel: '', planStartDate: '', planEndDate: '', serviceStartDate: '', serviceEndDate: '' }
    },
    onConfirm() {
      const query = { applied: '1' }
      if (this.filter.custNo) query.custNo = this.filter.custNo
      if (this.filter.custName) query.custName = this.filter.custName
      if (this.filter.bizType) query.bizType = this.filter.bizType
      if (this.isTodo) {
        if (this.filter.planStartDate) query.planStartDate = this.filter.planStartDate
        if (this.filter.planEndDate) query.planEndDate = this.filter.planEndDate
      }
      if (this.isDone) {
        if (this.filter.serviceStartDate) query.serviceStartDate = this.filter.serviceStartDate
        if (this.filter.serviceEndDate) query.serviceEndDate = this.filter.serviceEndDate
      }
      // 传递当前tab，返回时保持tab状态
      query.tab = this.$route.query.tab || 'todo'
      this.$router.replace({ path: '/workbench', query })
    }
  }
}
</script>

<style scoped lang="less">
.page-filter {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 16px;
}
.filter-card {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.filter-field-link {
  ::v-deep .van-field__value {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    height: 100%;
  }
  ::v-deep .van-field__body {
    display: flex;
    align-items: center;
  }
  ::v-deep .van-field__control--right {
    display: flex;
    align-items: center;
  }
  ::v-deep .van-field__right-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    margin-top: 0;
    padding-top: 0;
    line-height: 1;
    position: relative;
    top: -1px;
  }
  ::v-deep .van-field__control {
    line-height: inherit;
  }
}
.btn-group {
  display: flex;
  gap: 16px;
  margin-top: 24px;
  padding: 0 16px;
}
</style>