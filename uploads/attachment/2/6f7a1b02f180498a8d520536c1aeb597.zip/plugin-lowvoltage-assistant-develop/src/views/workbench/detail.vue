<template>
  <div class="page-detail">
    <van-nav-bar
      title="工单详情"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <!-- 基础信息模块 -->
      <div class="section-card">
        <div class="section-title">基础信息</div>
        <van-cell-group :border="false">
          <van-cell title="工单编号" :value="info.orderNo" :border="false" />
          <van-cell title="工单生成时间" :value="info.createTime" :border="false" />
          <van-cell title="用户编号" :value="info.userNo" :border="false" />
          <van-cell title="用户名称" :value="info.userName" :border="false" />
          <van-cell title="用电地址" :value="info.address" :border="false" />
          <van-cell title="客户联系人" :value="info.contactPerson" :border="false" />
          <van-cell title="联系方式" :value="info.contactPhone" :border="false" />
          <van-cell title="业务类型" :value="info.bizTypeName" :border="false" />
          <van-cell title="计划开始日期" :value="info.planStartDate" :border="false" />
          <van-cell title="计划结束日期" :value="info.planEndDate" :border="false" />
        </van-cell-group>
        <div class="task-desc-area">
          <div class="desc-label">任务描述</div>
          <div class="desc-text">{{ info.taskDesc }}</div>
        </div>
      </div>
      <!-- 服务详情模块 -->
      <div class="section-card">
        <div class="section-title">
          <span>服务详情</span>
          <van-tag type="primary" size="small">{{ serviceList.length }}条</van-tag>
        </div>
        <div v-if="serviceList.length === 0" class="empty-area">
          <van-empty description="暂无服务记录" />
        </div>
        <div v-else class="service-section">
          <div class="custom-timeline">
            <div
              v-for="(item, idx) in serviceList"
              :key="idx"
              class="timeline-item"
            >
              <div class="timeline-dot" :class="item.status === '02' ? 'solved' : 'unsolved'" />
              <div v-if="idx < serviceList.length - 1" class="timeline-line" />
              <div class="timeline-content">
                <div class="service-card">
                  <div class="s-row"><span class="s-label">客户工程师</span><span class="s-value">{{ item.engineerName }}</span></div>
                  <div class="s-row"><span class="s-label">服务时间</span><span class="s-value">{{ item.serviceDate }}</span></div>
                  <div class="s-row">
                    <span class="s-label">状态</span>
                    <span class="s-value">
                      <van-tag :type="item.status === '02' ? 'success' : 'warning'" size="small">{{ item.statusName }}</van-tag>
                    </span>
                  </div>
                  <div class="s-row"><span class="s-label">服务内容</span><span class="s-value">{{ item.content }}</span></div>
                  <div class="s-row"><span class="s-label">服务地址</span><span class="s-value">{{ item.address }}</span></div>
                  <div v-if="item.attachments.length > 0" class="s-row">
                    <span class="s-label">附件信息</span>
                    <div class="s-attachments">
                      <div
                        v-for="(a, ai) in item.attachments"
                        :key="ai"
                        class="att-item"
                      >
                        <van-icon
                          :name="a.type === 'image' ? 'photo-o' : 'video-o'"
                          :color="a.type === 'image' ? '#2b6ef7' : '#ee0a24'"
                          size="16"
                        />
                        <span class="att-name">{{ a.name }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { queryOrderInfo, queryProcessHistory } from '@/api/const'

export default {
  name: 'WorkbenchDetailPage',
  data() {
    return {
      info: {},
      serviceList: [],
      loading: true
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      const orderId = this.$route.query.id
      if (!orderId) return

      try {
        this.loading = true
        window.$toast.loading()

        const [orderRes, processRes] = await Promise.all([
          window.$Api.request(queryOrderInfo, { orderId }),
          window.$Api.request(queryProcessHistory, { orderId })
        ])

        // 基础信息
        this.info = orderRes?.code === '00000' ? (orderRes.data || {}) : {}

        // 处理记录列表
        const records = processRes?.code === '00000' ? (Array.isArray(processRes.data) ? processRes.data : []) : []
        this.serviceList = records.map(item => ({
          engineerName: item.engineerName,
          serviceDate: item.serviceTime,
          status: item.processStatus,
          statusName: item.processStatusName,
          content: item.serviceContent,
          address: item.serviceAddress,
          attachments: (Array.isArray(item.attachments) ? item.attachments : []).map(a => ({
            name: a.fileName,
            type: a.fileType === '02' ? 'video' : 'image'
          }))
        }))

        window.$toast.clear()
        this.loading = false
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-detail {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.task-desc-area {
  padding: 8px 16px 16px;
}
.desc-label {
  font-size: 13px;
  color: #999;
  margin-bottom: 4px;
}
.desc-text {
  font-size: 14px;
  color: #555;
  line-height: 1.6;
}
.empty-area {
  padding: 10px 0;
}
.service-section {
  padding: 12px 16px 16px;
}
.custom-timeline {
  position: relative;
  padding-left: 20px;
}
.timeline-item {
  position: relative;
  padding-bottom: 14px;
}
.timeline-dot {
  position: absolute;
  left: -14px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #07c160;
  background: #fff;
  z-index: 1;
  &.unsolved { border-color: #ff976a; }
  &.solved { border-color: #07c160; }
}
.timeline-line {
  position: absolute;
  left: -10px;
  top: 14px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}
.timeline-item:last-child .timeline-line { display: none; }
.timeline-content { padding-left: 4px; }
.service-card {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}
.s-row {
  display: flex;
  line-height: 1.8;
}
.s-label {
  width: 72px;
  font-size: 12px;
  color: #999;
  flex-shrink: 0;
}
.s-value {
  flex: 1;
  font-size: 12px;
  color: #333;
  text-align: right;
}
.s-attachments {
  flex: 1;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: flex-end;
}
.att-item {
  display: flex;
  align-items: center;
  gap: 2px;
  background: #fff;
  border-radius: 4px;
  padding: 2px 6px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}
.att-name {
  font-size: 11px;
  color: #666;
  max-width: 70px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>