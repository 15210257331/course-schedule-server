<template>
  <div class="page-workbench">
    <van-nav-bar
      title="我的台账"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="goHome"
    />
    <div class="page-content">
      <!-- Tab 切换 -->
      <van-tabs v-model="activeTab" sticky :lazy-render="false" @change="onTabChange">
        <van-tab :title="'待处理 ' + stats.todoCount" name="todo">
          <div class="search-bar" @click="goFilter">
            <van-icon name="search" color="#c8c9cc" />
            <span>点击进入筛选条件</span>
            <van-icon name="arrow" color="#c8c9cc" />
          </div>
          <van-list
            v-model="todoLoading"
            :finished="todoFinished"
            finished-text="没有更多了"
            @load="onTodoLoad"
          >
            <div v-for="item in todoList" :key="item.id" class="order-card" @click="goDetail(item)">
              <div class="card-top">
                <span class="biz-tag" :style="{ color: getBizColor(item.bizType) }">{{ getBizName(item.bizType) }}</span>
                <van-tag v-if="item.overdue === '02'" type="danger" size="small">超时</van-tag>
              </div>
              <div class="card-row"><span class="row-label">工单编号</span><span class="row-value">{{ item.orderNo }}</span></div>
              <div class="card-row"><span class="row-label">计划开始日期</span><span class="row-value">{{ item.planStartDate }}</span></div>
              <div class="card-row"><span class="row-label">计划结束日期</span><span class="row-value">{{ item.planEndDate }}</span></div>
              <div class="card-divider"></div>
              <div class="card-row"><span class="row-label">用户编号</span><span class="row-value">{{ item.userNo }}</span></div>
              <div class="card-row"><span class="row-label">用户名称</span><span class="row-value">{{ item.userName }}</span></div>
              <div class="card-row"><span class="row-label">用电地址</span><span class="row-value">{{ item.address }}</span></div>
            </div>
          </van-list>
          <van-empty v-if="todoSearched && !todoLoading && todoList.length === 0" description="暂无待处理工单" />
        </van-tab>
        <van-tab :title="'已处理 ' + stats.doneCount" name="done">
          <div class="search-bar" @click="goFilter">
            <van-icon name="search" color="#c8c9cc" />
            <span>点击进入筛选条件</span>
            <van-icon name="arrow" color="#c8c9cc" />
          </div>
          <van-list
            v-model="doneLoading"
            :finished="doneFinished"
            finished-text="没有更多了"
            @load="onDoneLoad"
          >
            <div v-for="item in doneList" :key="item.id" class="order-card" @click="goDetail(item)">
              <div class="card-top">
                <span class="biz-tag" :style="{ color: getBizColor(item.bizType) }">{{ getBizName(item.bizType) }}</span>
              </div>
              <div class="card-row"><span class="row-label">工单编号</span><span class="row-value">{{ item.orderNo }}</span></div>
              <div class="card-row"><span class="row-label">服务时间</span><span class="row-value">{{ item.serviceTime }}</span></div>
              <div class="card-divider"></div>
              <div class="card-row"><span class="row-label">用户编号</span><span class="row-value">{{ item.userNo }}</span></div>
              <div class="card-row"><span class="row-label">用户名称</span><span class="row-value">{{ item.userName }}</span></div>
              <div class="card-row"><span class="row-label">用电地址</span><span class="row-value">{{ item.address }}</span></div>
            </div>
          </van-list>
          <van-empty v-if="doneSearched && !doneLoading && doneList.length === 0" description="暂无已处理工单" />
        </van-tab>
      </van-tabs>
    </div>
  </div>
</template>

<script>
import { queryWorkbenchStats, queryTodoList, queryDoneList } from '@/api/const'
import { mapActions } from 'vuex'

export default {
  name: 'WorkbenchPage',
  data() {
    return {
      activeTab: 'todo',
      stats: { todoCount: 0, doneCount: 0 },
      // 待处理列表
      todoList: [],
      todoLoading: false,
      todoFinished: false,
      todoSearched: false,
      todoPageNo: 1,
      todoPageSize: 10,
      // 已处理列表
      doneList: [],
      doneLoading: false,
      doneFinished: false,
      doneSearched: false,
      donePageNo: 1,
      donePageSize: 10
    }
  },
  mounted() {
    // activated() 会处理首次加载和后续激活，mounted 中无需重复调用
  },
  activated() {
    // keepAlive 下每次页面激活刷新统计数据和列表
    this.loadPageData()
    // 从 query 参数中恢复 tab 状态
    const tabFromQuery = this.$route.query.tab
    if (tabFromQuery === 'todo' || tabFromQuery === 'done') {
      this.activeTab = tabFromQuery
    }
    // 重置 todo 列表，van-list 的 @load 会自动触发首次加载
    this.todoList = []
    this.todoPageNo = 1
    this.todoFinished = false
    this.todoSearched = false
    // 重置 done 列表，等待切换时加载
    this.doneList = []
    this.donePageNo = 1
    this.doneFinished = false
    this.doneSearched = false
    // 如果当前是已处理tab，触发加载
    if (this.activeTab === 'done') {
      this.$nextTick(() => {
        this.onDoneLoad()
      })
    }
  },
  methods: {
    ...mapActions('common', ['fetchUserInfo']),

    /** 调用分页接口并保留 total 信息（统一报文：res.code==='00000'，列表在 res.data，total 在 res.total） */
    async fetchListWithTotal(api, params) {
      const res = await window.$Api.request(api, params)
      // 网关层异常，直接抛错避免 van-list 重复加载
      if (res.resultCode === '9999') {
        throw new Error(res.result?.message || res.resultMsg || '服务异常，请稍后重试')
      }
      if (res.code !== '00000') {
        throw new Error(res.message || '查询失败')
      }
      const list = Array.isArray(res.data) ? res.data : []
      const total = res.total ?? 0
      return { list, total }
    },

    async loadPageData() {
      try {
        const userInfo = await this.fetchUserInfo()
        const engineerAccount = userInfo?.userNo || ''
        if (!engineerAccount) return

        window.$toast.loading()

        // 加载统计
        const statsRes = await window.$Api.request(queryWorkbenchStats, { engineerAccount })
        // 网关层异常，直接抛错避免重复调用
        if (statsRes.resultCode === '9999') {
          throw new Error(statsRes.result?.message || statsRes.resultMsg || '服务异常，请稍后重试')
        }
        if (statsRes.code === '00000' && statsRes.data) {
          this.stats = {
            todoCount: statsRes.data.todoCount || 0,
            doneCount: statsRes.data.doneCount || 0
          }
        }
        window.$toast.clear()
      } catch (err) {
        window.$toast.clear()
        console.log('加载台账统计失败', err)
      }
    },

    /** 获取筛选参数（从 route query 中读取） */
    getTodoFilterParams() {
      const query = this.$route.query
      const params = {}
      if (query.applied === '1') {
        if (query.bizType) params.bizType = query.bizType
        if (query.planStartDate) params.planStartDate = query.planStartDate
        if (query.planEndDate) params.planEndDate = query.planEndDate
      }
      if (query.custNo) params.custNo = query.custNo
      if (query.custName) params.custName = query.custName
      return params
    },

    getDoneFilterParams() {
      const query = this.$route.query
      const params = {}
      if (query.applied === '1') {
        if (query.bizType) params.bizType = query.bizType
        if (query.serviceStartDate) params.serviceStartDate = query.serviceStartDate
        if (query.serviceEndDate) params.serviceEndDate = query.serviceEndDate
      }
      if (query.custNo) params.custNo = query.custNo
      if (query.custName) params.custName = query.custName
      return params
    },

    async onTodoLoad() {
      this.todoSearched = true
      try {
        const userInfo = await this.fetchUserInfo()
        const engineerAccount = userInfo?.userNo || ''

        const params = {
          engineerAccount,
          ...this.getTodoFilterParams(),
          pageNo: this.todoPageNo,
          pageSize: this.todoPageSize
        }

        const { list, total } = await this.fetchListWithTotal(queryTodoList, params)
        const mapped = (list || []).map(item => ({
          ...item,
          overdue: item.overdue || '01'
        }))
        // 去重，避免接口返回重复数据导致 key 冲突
        const uniqueMapped = mapped.filter((item, index, self) =>
          index === self.findIndex(t => t.id === item.id)
        )

        if (this.todoPageNo === 1) {
          this.todoList = uniqueMapped
        } else {
          // 合并时再次去重
          const merged = [...this.todoList, ...uniqueMapped]
          this.todoList = merged.filter((item, index, self) =>
            index === self.findIndex(t => t.id === item.id)
          )
        }
        this.todoPageNo++
        this.todoLoading = false

        if (this.todoList.length >= total) {
          this.todoFinished = true
        }
      } catch (err) {
        this.todoLoading = false
        this.todoFinished = true
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    async onDoneLoad() {
      this.doneSearched = true
      try {
        const userInfo = await this.fetchUserInfo()
        const engineerAccount = userInfo?.userNo || ''

        const params = {
          engineerAccount,
          ...this.getDoneFilterParams(),
          pageNo: this.donePageNo,
          pageSize: this.donePageSize
        }

        const { list, total } = await this.fetchListWithTotal(queryDoneList, params)
        // 去重，避免接口返回重复数据导致 key 冲突
        const uniqueList = (list || []).filter((item, index, self) =>
          index === self.findIndex(t => t.id === item.id)
        )

        if (this.donePageNo === 1) {
          this.doneList = uniqueList
        } else {
          // 合并时再次去重
          const merged = [...this.doneList, ...uniqueList]
          this.doneList = merged.filter((item, index, self) =>
            index === self.findIndex(t => t.id === item.id)
          )
        }
        this.donePageNo++
        this.doneLoading = false

        if (this.doneList.length >= total) {
          this.doneFinished = true
        }
      } catch (err) {
        this.doneLoading = false
        this.doneFinished = true
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    getBizName(type) {
      const m = { '01': '催费通知', '02': '停电通知', '03': '诉求', '04': '现场勘察', '05': '设备更换', '06': '巡视', '07': '安全隐患' }
      return m[type] || '其他'
    },
    getBizColor(type) {
      const m = { '01': '#ff976a', '02': '#ee0a24', '03': '#1989fa', '04': '#07c160', '05': '#7232dd', '06': '#2b6ef7', '07': '#ee0a24' }
      return m[type] || '#999'
    },
    goFilter() {
      this.$router.push({ path: '/workbench/filter', query: { tab: this.activeTab }, replace: true })
    },
    onTabChange(name) {
      if (name === 'todo') {
        if (!this.todoSearched) {
          this.onTodoLoad()
        }
      } else if (name === 'done') {
        if (!this.doneSearched) {
          this.onDoneLoad()
        }
      }
    },
    goDetail(item) {
      if (this.activeTab === 'todo') {
        this.$router.push({ path: '/workbench/task-handle', query: { id: String(item.id) } })
      } else {
        this.$router.push({ path: '/workbench/detail', query: { id: String(item.id) } })
      }
    },
    goHome() {
      this.$router.push('/home')
    }
  }
}
</script>

<style scoped lang="less">
.page-workbench {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.search-bar { display: flex; align-items: center; justify-content: center; gap: 8px; background: #fff; border-radius: 8px; padding: 14px 16px; margin-bottom: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); cursor: pointer; color: #999; font-size: 14px; }
.order-card { background: #fff; border-radius: 8px; padding: 12px 16px; margin-bottom: 10px; box-shadow: 0 1px 4px rgba(0,0,0,0.05); cursor: pointer; }
.card-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
.biz-tag { font-size: 13px; font-weight: 500; }
.card-row { display: flex; line-height: 1.8; }
.row-label { width: 86px; font-size: 12px; color: #999; flex-shrink: 0; }
.row-value { flex: 1; font-size: 12px; color: #333; text-align: right; }
</style>
