<template>
  <container-view title="用户查询">
    <div class="div-head">
      <field-input label="供电单位" v-model="orgName" @click.native="onSelectOrg" :is-link="isMge" readonly />
      <field-input label="用户编号" v-model="params.userNo" clearable />
      <field-input label="用户名称" v-model="params.userName" clearable />
      <field-input label="用户地址" v-model="params.address" :border="false" clearable />
    </div>
    <button-view :fontColor="themeColor" rightStr="查询" :clickRight="onSearch" />
  </container-view>
</template>

<script>
import ContainerView from '@/components/container-view'
import FieldInput from '@/components/field-input'
import ButtonView from '@/components/button-view'
import { OrgSelector } from '@/libs/publictools-components.umd.min'
import { queryUserList } from '@/api/const'
import { mapState, mapActions } from 'vuex'

export default {
  name: 'UserQueryPage',
  components: { ContainerView, FieldInput, ButtonView },
  data() {
    return {
      orgName: '',
      params: {
        orgNo: '', // 单位编码
        userNo: '',     // 用户编号
        userName: '',   // 用户名称
        address: '',   // 用户地址
        pageNo: 1,      // 页数
        pageSize: 10    // 每页数量
      }
    }
  },

  computed: {
    ...mapState('common', ['userInfo']),
    themeColor() {
      return ['app'].includes(process.env.VUE_APP_TYPE) ? '#28B67F' : '#1890FF'
    },
    isMge() {
      return this.userInfo?.orgNo && this.userInfo?.orgNo.length < 7
    }
  },

  async mounted() {
    try {
      const userInfo = await this.fetchUserInfo()
      if (userInfo) {
        this.orgName = userInfo.orgName || ''
        this.params.orgNo = userInfo.orgNo || ''
      }
    } catch (e) {
      console.log('获取用户信息失败', e)
    }
  },

  methods: {
    ...mapActions('common', ['fetchUserInfo']),
    async onSelectOrg() {
      const userInfo = await this.fetchUserInfo()
      if (!userInfo?.orgNo) {
        window.$toast.show('当前登录账号没有单位信息，请联系管理员维护！')
        return false
      }

      if (!this.isMge) {
        return false
      }

      OrgSelector.$show(userInfo.orgNo).then(async res => {
        console.log('选择单位结果', JSON.stringify(res))
        if (res.text && res.value) {
          this.orgName = res.text
          this.params.orgNo = res.value
        }
      })
    },

    async onSearch() {
      try {
        window.$toast.loading()

        const res = await window.$Api.request(queryUserList, this.params)
        window.$toast.clear()
        console.log('=====', res)
        const resList = res?.code === '00000' ? (Array.isArray(res.data) ? res.data : []) : []
        if (!resList.length) {
          window.$toast.show('未查询到用户信息')
          return
        }

        await this.$router.push({
          path: '/user-query/result',
          query: {
            data: JSON.stringify(this.params),
            from: this.$route.query.from || '',
            t: Date.now().toString()
          }
        })
      } catch (err) {
        window.$toast.clear()
        window.$toast.show(err.message?.message || err.message || err)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.div-head {
  margin: 16px;
  border-radius: 8px;
  background-color: white;
  box-shadow: 0 2px 6px 0 rgba(61, 61, 61, 0.17);
}
</style>