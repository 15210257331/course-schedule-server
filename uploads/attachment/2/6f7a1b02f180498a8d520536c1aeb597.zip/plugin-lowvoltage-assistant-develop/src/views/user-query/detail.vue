<template>
  <div class="page-detail">
    <van-nav-bar
      title="客户明细"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <van-loading v-if="loading" size="24px" class="loading-area">加载中...</van-loading>
      <template v-else>
        <!-- 用户基本信息 -->
        <div class="section-card">
          <div class="section-title">用户基本信息</div>
          <van-cell-group :border="false">
            <van-cell title="用户编号" :value="customerInfo.custNo" :border="false" />
            <van-cell title="用户名称" :value="customerInfo.custName" :border="false" />
            <van-cell title="用户分类" :value="customerInfo.custClsName" :border="false" />
            <van-cell title="用电地址" :value="customerInfo.address" :border="false" />
<!--            <van-cell title="联系人" :value="customerInfo.contactPerson" :border="false" />
            <van-cell title="联系电话" :value="customerInfo.contactPhone" :border="false" />-->
          </van-cell-group>
        </div>

        <!-- 现任客户工程师 -->
        <div class="section-card">
          <div class="section-title">现任客户工程师</div>
          <van-cell-group :border="false">
            <van-cell title="姓名" :value="engineerInfo.engineerName" :border="false" />
<!--            <van-cell title="联系电话" :value="engineerInfo.engineerPhone" :border="false" />
            <van-cell title="所属班组" :value="engineerInfo.engineerTeam" :border="false" />-->
            <van-cell title="任职开始日期" :value="engineerInfo.buildTime" :border="false" />
          </van-cell-group>
        </div>

        <!-- 历史变更记录 -->
        <div class="section-card">
          <div class="section-title">历史变更记录</div>
          <div class="timeline-wrap">
            <div v-if="historyList.length === 0" class="no-data">暂无变更记录</div>
            <div v-else class="custom-timeline">
              <div
                v-for="(item, index) in historyList"
                :key="index"
                class="timeline-item"
              >
                <div class="timeline-dot" />
                <div class="timeline-line" />
                <div class="timeline-content">
                  <div class="history-card">
                    <div class="history-field">
                      <span class="field-label">变更时间</span>
                      <span class="field-value">{{ item.changeTime }}</span>
                    </div>
                    <div class="history-field">
                      <span class="field-label">变更原因</span>
                      <span class="field-value">{{ item.changeReason }}</span>
                    </div>
                    <div class="history-field">
                      <span class="field-label">变更前工程师</span>
                      <span class="field-value">{{ item.oldEngineerName }}</span>
                    </div>
                    <div class="history-field">
                      <span class="field-label">变更后工程师</span>
                      <span class="field-value">{{ item.newEngineerName }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { queryCustomerInfo, queryEngineerDetail, queryEngineerHistory } from '@/api/const'

export default {
  name: 'CustomerDetailPage',
  data() {
    return {
      loading: false,
      customerInfo: {},
      engineerInfo: {},
      historyList: []
    }
  },
  mounted() {
    this.loadDetail()
  },
  methods: {
    async loadDetail() {
      const custNo = this.$route.query.custNo
      if (!custNo) {
        window.$toast.show('缺少用户编号')
        return
      }

      try {
        this.loading = true
        window.$toast.loading()

        const [customerRes, engineerRes, historyRes] = await Promise.all([
          window.$Api.request(queryCustomerInfo, { custNo }),
          window.$Api.request(queryEngineerDetail, { custNo }),
          window.$Api.request(queryEngineerHistory, { custNo })
        ])

        window.$toast.clear()
        this.loading = false

        this.customerInfo = customerRes?.code === '00000' ? (customerRes.data || {}) : {}
        this.engineerInfo = engineerRes?.code === '00000' ? (engineerRes.data || {}) : {}
        this.historyList = historyRes?.code === '00000' ? (Array.isArray(historyRes.data) ? historyRes.data : []) : []
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-detail {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.loading-area {
  display: flex;
  justify-content: center;
  align-items: center;
  padding-top: 60px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.timeline-wrap {
  padding: 12px 16px 16px;
}
.no-data {
  text-align: center;
  color: #999;
  font-size: 13px;
  padding: 20px 0;
}
.custom-timeline {
  position: relative;
  padding-left: 20px;
}
.timeline-item {
  position: relative;
  padding-bottom: 16px;
}
.timeline-dot {
  position: absolute;
  left: -14px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #2b6ef7;
  background: #fff;
  z-index: 1;
}
.timeline-line {
  position: absolute;
  left: -10px;
  top: 14px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}
.timeline-item:last-child .timeline-line {
  display: none;
}
.timeline-content {
  padding-left: 8px;
}
.history-card {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}
.history-field {
  display: flex;
  line-height: 1.8;
  .field-label {
    width: 100px;
    font-size: 13px;
    color: #999;
    flex-shrink: 0;
  }
  .field-value {
    flex: 1;
    font-size: 13px;
    color: #333;
  }
}
</style>
