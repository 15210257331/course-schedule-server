<template>
  <div class="page-result">
    <van-nav-bar
      title="查询结果"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div class="result-header" v-if="total > 0">共查询到 {{ total }} 条记录</div>
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
      >
        <div class="result-list">
          <div
            v-for="item in list"
            :key="item.custNo"
            class="user-card"
            @click="goDetail(item)"
          >
            <div class="card-row">
              <span class="card-label">用户编号</span>
              <span class="card-value">{{ item.custNo }}</span>
            </div>
            <div class="card-row">
              <span class="card-label">用户名称</span>
              <span class="card-value">{{ item.custName }}</span>
            </div>
            <div class="card-row">
              <span class="card-label">用电地址</span>
              <span class="card-value">{{ item.address }}</span>
            </div>
            <van-icon name="arrow" class="card-arrow" color="#c8c9cc" />
          </div>
        </div>
      </van-list>
      <van-empty v-if="searched && !loading && list.length === 0" description="暂无匹配用户数据" />
    </div>
  </div>
</template>

<script>
import { queryUserList } from '@/api/const'

export default {
  name: 'UserQueryResultPage',
  data() {
    return {
      list: [],
      loading: false,
      finished: false,
      searched: false,
      pageNo: 1,
      pageSize: 10,
      total: 0,
      searchParams: {}
    }
  },
  mounted() {
    const dataStr = this.$route.query.data
    if (dataStr) {
      const params = JSON.parse(dataStr)
      // 提取搜索条件，去掉分页参数
      const { pageNo, pageSize, ...rest } = params
      this.searchParams = rest
    }
  },
  methods: {
    /** 调用用户列表接口并保留 total 分页信息（统一报文：res.code==='00000'，列表在 res.data，total 在 res.total） */
    async fetchUserListWithTotal(params) {
      const res = await window.$Api.request(queryUserList, params)
      if (res.code !== '00000') {
        throw new Error(res.message || '查询失败')
      }
      const list = Array.isArray(res.data) ? res.data : []
      const total = res.total ?? 0
      return { list, total }
    },

    async onLoad() {
      this.searched = true

      try {
        const params = {
          ...this.searchParams,
          pageNo: this.pageNo,
          pageSize: this.pageSize
        }
        const { list, total } = await this.fetchUserListWithTotal(params)

        if (this.pageNo === 1) {
          this.list = list || []
        } else {
          this.list = [...this.list, ...(list || [])]
        }
        this.total = total
        this.pageNo++
        this.loading = false

        if (this.list.length >= total) {
          this.finished = true
        }
      } catch (err) {
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    goDetail(item) {
      const from = this.$route.query.from
      if (from === 'panorama') {
        this.$router.push({ path: '/panorama', query: { customerName: item.custName, customerNo: item.custNo } })
      } else {
        this.$router.push({ path: '/user-query/detail', query: { custNo: item.custNo } })
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-result {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px;
}
.result-header {
  font-size: 13px;
  color: #999;
  padding: 12px 0 8px;
}
.user-card {
  position: relative;
  background: #fff;
  border-radius: 8px;
  padding: 14px 16px;
  margin-bottom: 10px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
  cursor: pointer;
}
.card-row {
  display: flex;
  align-items: center;
  line-height: 1.8;
}
.card-label {
  width: 72px;
  font-size: 13px;
  color: #999;
  flex-shrink: 0;
}
.card-value {
  flex: 1;
  font-size: 14px;
  color: #333;
  text-align: right;
}
.card-arrow {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
}
</style>