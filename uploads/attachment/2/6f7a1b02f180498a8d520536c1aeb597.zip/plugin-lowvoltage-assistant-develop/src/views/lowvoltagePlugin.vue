<template>
  <div class="lowvoltage-plugin">
    <keep-alive :max="5">
      <router-view v-if="$route.meta.keepAlive" />
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" />
  </div>
</template>

<script>
export default {
  name: 'LowvoltagePlugin',
  props: {
    initialRoute: {
      type: String,
      default: '/home'
    }
  },
  mounted() {
    if (this.initialRoute && this.$router.currentRoute.path === '/') {
      this.$router.replace(this.initialRoute)
    }
  }
}
</script>

<style scoped lang="less">
.lowvoltage-plugin {
  width: 100%;
  min-height: 100vh;
  background: #f5f6fa;
}
</style>
