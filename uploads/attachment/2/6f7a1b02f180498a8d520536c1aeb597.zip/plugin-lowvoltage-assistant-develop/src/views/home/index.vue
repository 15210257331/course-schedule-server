<template>
  <div class="page-home">
    <van-nav-bar title="现场服务助手" :placeholder="true" :safe-area-inset-top="true" :border="false" left-arrow @click-left="closeWindow" />
    <div class="header-banner">
      <div class="app-title">现场服务助手</div>
      <div class="app-desc">为您提供全方位的现场服务</div>
    </div>
    <div class="content">
      <div v-for="item in menuList" :key="item.path" class="menu-card" @click="goPage(item.path)">
        <div class="card-icon" :style="{ background: item.bgColor }">
          <van-icon :name="item.icon" size="28" color="#fff" />
        </div>
        <div class="card-info">
          <div class="card-title">{{ item.title }}</div>
          <div class="card-desc">{{ item.desc }}</div>
        </div>
        <van-icon name="arrow" color="#c8c9cc" class="card-arrow" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
      menuList: [
        { path: '/user-query', title: '工程师查询', desc: '查询用户信息及查看工程师档案', icon: 'contact', bgColor: '#2b6ef7' },
        { path: '/user-query?from=panorama', title: '服务全景', desc: '客户服务概况与时间轴看板', icon: 'chart-trending-o', bgColor: '#07c160' },
        { path: '/register', title: '现场登记', desc: '登记现场服务工单信息', icon: 'edit', bgColor: '#ff976a' },
        { path: '/workbench', title: '我的台账', desc: '个人工作记录与任务台账', icon: 'manager-o', bgColor: '#1989fa' }
      ]
    }
  },
  methods: {
    goPage(path) {
      this.$router.push(path)
    },
    closeWindow() {
      if (window.Vegeta && window.Vegeta.hyDock) {
        window.Vegeta.hyDock.close()
      } else {
        this.$router.go(-1)
      }
    }
  }
}
</script>

<style scoped lang="less">
.page-home {
  min-height: 100vh;
  background: linear-gradient(180deg, #2b6ef7 0%, #4a8af7 100%);
}

.header-banner {
  padding: 20px 24px 40px;
  text-align: center;

  .app-title {
    font-size: 22px;
    font-weight: 600;
    color: #fff;
    margin-bottom: 8px;
  }

  .app-desc {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
  }
}

.content {
  border-radius: 16px 16px 0 0;
  background: #f5f6fa;
  padding: 20px 16px;
  min-height: calc(100vh - 160px);
}

.menu-card {
  display: flex;
  align-items: center;
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  cursor: pointer;
}

.card-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.card-info {
  flex: 1;
  margin-left: 14px;
}

.card-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.card-desc {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}

.card-arrow {
  flex-shrink: 0;
}
</style>