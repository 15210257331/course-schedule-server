<template>
  <div class="page-engineer">
    <van-nav-bar
      title="用户查询"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div class="filter-section">
        <div class="filter-header" @click="showFilter = !showFilter">
          <span class="filter-title">筛选条件</span>
          <van-icon :name="showFilter ? 'arrow-up' : 'arrow-down'" color="#999" />
        </div>
        <van-collapse v-model="showFilter" :border="false">
          <van-collapse-item :name="0" :border="false">
            <div class="filter-form">
              <van-dropdown-menu>
                <van-dropdown-item
                  v-model="orgFilter"
                  :options="orgOptions"
                  @change="onSearch"
                />
              </van-dropdown-menu>
              <van-field
                v-model="form.userNo"
                label="用户编号"
                placeholder="请输入用户编号"
                clearable
                input-align="right"
              />
              <van-field
                v-model="form.userName"
                label="用户名称"
                placeholder="请输入用户名称"
                clearable
                input-align="right"
              />
              <van-field
                v-model="form.address"
                label="用电地址"
                placeholder="请输入用电地址"
                clearable
                input-align="right"
              />
              <div class="filter-actions">
                <van-button size="small" plain @click="onReset">重置</van-button>
                <van-button size="small" type="primary" @click="onSearch">查询</van-button>
              </div>
            </div>
          </van-collapse-item>
        </van-collapse>
      </div>
      <div v-if="loading" class="loading-area">
        <van-loading size="24px">加载中...</van-loading>
      </div>
      <template v-else-if="userList.length > 0">
        <van-pull-refresh v-model="refreshing" @refresh="onSearch">
          <van-list
            v-model="loadingMore"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoadMore"
          >
            <div
              v-for="item in userList"
              :key="item.id"
              class="user-card"
              @click="goDetail(item)"
            >
              <van-cell-group :border="false">
                <van-cell :border="false">
                  <template #title>
                    <div class="card-title">
                      <span class="user-name">{{ item.userName }}</span>
                      <van-tag type="primary" size="small">已建档</van-tag>
                    </div>
                  </template>
                  <template #label>
                    <div class="card-label">用户编号：{{ item.userNo }}</div>
                    <div class="card-label">用电地址：{{ item.address }}</div>
                  </template>
                  <template #right-icon>
                    <van-icon name="arrow" color="#c8c9cc" />
                  </template>
                </van-cell>
              </van-cell-group>
            </div>
          </van-list>
        </van-pull-refresh>
      </template>
      <van-empty v-else-if="!loading && queried" description="暂无匹配用户数据" />
      <van-empty v-else-if="!loading && !queried" description="请输入条件查询用户" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'EngineerPage',
  data() {
    return {
      showFilter: [0],
      orgFilter: '',
      orgOptions: [
        { text: '全部供电单位', value: '' },
        { text: '城东供电所', value: '城东供电所' },
        { text: '城西供电所', value: '城西供电所' },
        { text: '城南供电所', value: '城南供电所' },
        { text: '城北供电所', value: '城北供电所' }
      ],
      form: {
        userNo: '',
        userName: '',
        address: ''
      },
      userList: [],
      allData: [],
      loading: false,
      queried: false,
      refreshing: false,
      loadingMore: false,
      finished: false,
      pageIndex: 1,
      pageSize: 20
    }
  },
  methods: {
    async fetchList() {
      this.loading = true
      try {
        setTimeout(() => {
          this.allData = this.getMockList()
          this.applyFilter()
          this.loading = false
          this.refreshing = false
          this.finished = true
        }, 500)
      } catch (error) {
        this.$toast.show('加载失败')
        this.loading = false
        this.refreshing = false
      }
    },
    applyFilter() {
      this.queried = true
      let filtered = [...this.allData]
      const form = this.form
      if (this.orgFilter) {
        filtered = filtered.filter(item => item.orgName === this.orgFilter)
      }
      if (form.userNo) {
        filtered = filtered.filter(item => item.userNo.includes(form.userNo))
      }
      if (form.userName) {
        filtered = filtered.filter(item => item.userName.includes(form.userName))
      }
      if (form.address) {
        filtered = filtered.filter(item => item.address.includes(form.address))
      }
      this.userList = filtered
    },
    getMockList() {
      return [
        { id: 1, userName: '长山社区01号台区', userNo: 'CS2024001', address: '长山路168号', orgName: '城东供电所' },
        { id: 2, userName: '瑞景园小区02号', userNo: 'RJ2024002', address: '瑞景路88号', orgName: '城东供电所' },
        { id: 3, userName: '阳光花园三期', userNo: 'YG2024003', address: '阳光大道56号', orgName: '城西供电所' },
        { id: 4, userName: '滨江公馆01号', userNo: 'BJ2024004', address: '滨江路12号', orgName: '城南供电所' },
        { id: 5, userName: '翠苑小区04号', userNo: 'CY2024005', address: '翠苑路33号', orgName: '城北供电所' }
      ]
    },
    onSearch() {
      this.pageIndex = 1
      this.finished = false
      this.userList = []
      this.fetchList()
    },
    onReset() {
      this.form = { userNo: '', userName: '', address: '' }
      this.orgFilter = ''
      this.queried = false
      this.userList = []
    },
    onLoadMore() {
      this.pageIndex += 1
    },
    goDetail(item) {
      this.$router.push({ path: '/engineer/detail', query: { id: String(item.id) } })
    }
  }
}
</script>

<style scoped lang="less">
.page-engineer {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px;
}
.filter-section {
  background: #fff;
  border-radius: 8px;
  margin: 12px 0;
  overflow: hidden;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
}
.filter-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
}
.filter-title {
  font-size: 14px;
  font-weight: 500;
  color: #333;
}
.filter-form {
  padding: 0 16px 12px;
}
.filter-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 12px;
}
.loading-area {
  display: flex;
  justify-content: center;
  align-items: center;
  padding-top: 100px;
}
.user-card {
  margin-bottom: 12px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}
.card-title {
  display: flex;
  align-items: center;
  gap: 8px;
  .user-name {
    font-size: 15px;
    font-weight: 500;
    color: #333;
  }
}
.card-label {
  font-size: 13px;
  color: #666;
  margin-top: 4px;
}
</style>