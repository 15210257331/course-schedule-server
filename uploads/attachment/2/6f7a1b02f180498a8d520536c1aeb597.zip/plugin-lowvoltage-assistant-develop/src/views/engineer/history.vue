<template>
  <div class="page-history">
    <van-nav-bar
      title="历史变更记录"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div class="custom-timeline">
        <div
          v-for="item in historyList"
          :key="item.id"
          class="timeline-item"
        >
          <div class="timeline-dot" />
          <div class="timeline-line" />
          <div class="timeline-content">
            <div class="timeline-time">{{ item.changeTime }}</div>
            <div class="history-card">
              <div class="change-row">
                <span class="label">原工程师：</span>
                <span class="value">{{ item.oldEngineerName }}</span>
              </div>
              <div class="change-row">
                <span class="label">新工程师：</span>
                <span class="value">{{ item.newEngineerName }}</span>
              </div>
              <div class="change-row">
                <span class="label">变更原因：</span>
                <span class="value">{{ item.changeReason }}</span>
              </div>
              <div class="change-row">
                <span class="label">操作人：</span>
                <span class="value">{{ item.operator }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'EngineerHistoryPage',
  data() {
    return {
      historyList: []
    }
  },
  mounted() {
    this.loadHistory()
  },
  methods: {
    loadHistory() {
      this.historyList = [
        { id: 6, changeTime: '2026-03-20', oldEngineerName: '陈晨', newEngineerName: '张伟', changeReason: '岗位调整', operator: '系统管理员' },
        { id: 5, changeTime: '2025-12-01', oldEngineerName: '王芳', newEngineerName: '陈晨', changeReason: '人员轮换', operator: '系统管理员' },
        { id: 4, changeTime: '2025-06-15', oldEngineerName: '刘洋', newEngineerName: '王芳', changeReason: '区域调整', operator: '系统管理员' },
        { id: 3, changeTime: '2024-12-01', oldEngineerName: '赵明', newEngineerName: '刘洋', changeReason: '岗位调整', operator: '系统管理员' },
        { id: 2, changeTime: '2024-06-15', oldEngineerName: '李强', newEngineerName: '赵明', changeReason: '人员轮换', operator: '系统管理员' },
        { id: 1, changeTime: '2023-09-01', oldEngineerName: '孙磊', newEngineerName: '李强', changeReason: '区域调整', operator: '系统管理员' }
      ]
    }
  }
}
</script>

<style scoped lang="less">
.page-history {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 16px;
}
.custom-timeline {
  position: relative;
  padding-left: 20px;
}
.timeline-item {
  position: relative;
  padding-bottom: 20px;
}
.timeline-dot {
  position: absolute;
  left: -14px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #2b6ef7;
  background: #fff;
  z-index: 1;
}
.timeline-line {
  position: absolute;
  left: -10px;
  top: 14px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}
.timeline-item:last-child .timeline-line {
  display: none;
}
.timeline-content {
  padding-left: 8px;
}
.timeline-time {
  font-size: 12px;
  color: #999;
  margin-bottom: 6px;
}
.history-card {
  background: #fff;
  border-radius: 8px;
  padding: 12px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.05);
}
.change-row {
  display: flex;
  margin-bottom: 4px;
  font-size: 13px;
  .label {
    color: #999;
    width: 80px;
    flex-shrink: 0;
  }
  .value {
    color: #333;
    flex: 1;
  }
}
</style>