<template>
  <div class="page-detail">
    <van-nav-bar
      title="工程师查询"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div class="section-card">
        <div class="section-title">客户基本信息</div>
        <van-cell-group :border="false">
          <van-cell title="用户编号" :value="customerInfo.userNo" :border="false" />
          <van-cell title="用户名称" :value="customerInfo.userName" :border="false" />
          <van-cell title="用户分类" :value="customerInfo.userType" :border="false" />
          <van-cell title="用电地址" :value="customerInfo.address" :border="false" />
        </van-cell-group>
      </div>
      <div class="section-card">
        <div class="section-title">现任客户工程师</div>
        <van-cell-group :border="false">
          <van-cell title="姓名" :value="engineerInfo.name" :border="false" />
          <van-cell title="任职开始日期" :value="engineerInfo.startDate" :border="false" />
        </van-cell-group>
      </div>
      <div class="section-card">
        <div class="section-title">
          <span>历史变更记录</span>
          <van-icon name="bell" color="#2b6ef7" />
        </div>
        <div class="timeline-wrap">
          <div v-if="historyList.length === 0" class="no-data">暂无变更记录</div>
          <div class="custom-timeline">
            <div
              v-for="item in historyList"
              :key="item.id"
              class="timeline-item"
            >
              <div class="timeline-dot" />
              <div class="timeline-line" />
              <div class="timeline-content">
                <div class="history-card">
                  <div class="history-field">
                    <span class="field-label">变更时间</span>
                    <span class="field-value">{{ item.changeTime }}</span>
                  </div>
                  <div class="history-field">
                    <span class="field-label">变更原因</span>
                    <span class="field-value">{{ item.changeReason }}</span>
                  </div>
                  <div class="history-field">
                    <span class="field-label">变更前客户工程师</span>
                    <span class="field-value">{{ item.oldEngineerName }}</span>
                  </div>
                  <div class="history-field">
                    <span class="field-label">变更后客户工程师</span>
                    <span class="field-value">{{ item.newEngineerName }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'EngineerDetailPage',
  data() {
    return {
      customerInfo: {},
      engineerInfo: {},
      historyList: []
    }
  },
  mounted() {
    this.loadDetail()
  },
  methods: {
    loadDetail() {
      this.customerInfo = {
        userNo: 'CS2024001',
        userName: '长山社区01号台区',
        userType: '居民用户',
        address: '长山路168号'
      }
      this.engineerInfo = {
        name: '张伟',
        startDate: '2024-01-15'
      }
      this.historyList = [
        { id: 6, changeTime: '2026-03-20', changeReason: '岗位调整', oldEngineerName: '陈晨', newEngineerName: '张伟' },
        { id: 5, changeTime: '2025-12-01', changeReason: '人员轮换', oldEngineerName: '王芳', newEngineerName: '陈晨' },
        { id: 4, changeTime: '2025-06-15', changeReason: '区域调整', oldEngineerName: '刘洋', newEngineerName: '王芳' },
        { id: 3, changeTime: '2024-12-01', changeReason: '岗位调整', oldEngineerName: '赵明', newEngineerName: '刘洋' },
        { id: 2, changeTime: '2024-06-15', changeReason: '人员轮换', oldEngineerName: '李强', newEngineerName: '赵明' },
        { id: 1, changeTime: '2023-09-01', changeReason: '区域调整', oldEngineerName: '孙磊', newEngineerName: '李强' }
      ]
    }
  }
}
</script>

<style scoped lang="less">
.page-detail {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.timeline-wrap {
  padding: 12px 16px 16px;
}
.no-data {
  text-align: center;
  color: #999;
  font-size: 13px;
  padding: 20px 0;
}
.custom-timeline {
  position: relative;
  padding-left: 20px;
}
.timeline-item {
  position: relative;
  padding-bottom: 16px;
}
.timeline-dot {
  position: absolute;
  left: -14px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #2b6ef7;
  background: #fff;
  z-index: 1;
}
.timeline-line {
  position: absolute;
  left: -10px;
  top: 14px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}
.timeline-item:last-child .timeline-line {
  display: none;
}
.timeline-content {
  padding-left: 8px;
}
.history-card {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}
.history-field {
  display: flex;
  line-height: 1.8;
  .field-label {
    width: 110px;
    font-size: 13px;
    color: #999;
    flex-shrink: 0;
  }
  .field-value {
    flex: 1;
    font-size: 13px;
    color: #333;
  }
}
</style>