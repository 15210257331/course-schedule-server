<template>
  <div class="page-select">
    <van-nav-bar
      title="选择用户"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <div v-if="loading" class="loading-area">
        <van-loading size="24px">加载中...</van-loading>
      </div>
      <template v-else-if="list.length > 0">
        <div class="result-header">管辖用户（{{ list.length }}）</div>
        <div class="result-list">
          <div
            v-for="item in list"
            :key="item.id"
            class="user-card"
            @click="goPanorama(item)"
          >
            <div class="card-row">
              <span class="card-label">用户编号</span>
              <span class="card-value">{{ item.userNo }}</span>
            </div>
            <div class="card-row">
              <span class="card-label">用户名称</span>
              <span class="card-value">{{ item.userName }}</span>
            </div>
            <div class="card-row">
              <span class="card-label">用电地址</span>
              <span class="card-value">{{ item.address }}</span>
            </div>
            <van-icon name="arrow" class="card-arrow" color="#c8c9cc" />
          </div>
        </div>
      </template>
      <van-empty v-else description="暂无管辖用户数据" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'PanoramaUserSelectPage',
  data() {
    return {
      list: [],
      loading: false
    }
  },
  mounted() {
    this.loadUsers()
  },
  methods: {
    getMockData() {
      return [
        { id: 1, userName: '长山社区01号台区', userNo: 'CS2024001', address: '长山路168号' },
        { id: 2, userName: '瑞景园小区02号', userNo: 'RJ2024002', address: '瑞景路88号' },
        { id: 3, userName: '阳光花园三期', userNo: 'YG2024003', address: '阳光大道56号' },
        { id: 4, userName: '滨江公馆01号', userNo: 'BJ2024004', address: '滨江路12号' },
        { id: 5, userName: '翠苑小区04号', userNo: 'CY2024005', address: '翠苑路33号' },
        { id: 6, userName: '桃源居小区', userNo: 'TY2024006', address: '桃源路99号' },
        { id: 7, userName: '锦绣花园', userNo: 'JX2024007', address: '锦绣大道28号' },
        { id: 8, userName: '望江公寓', userNo: 'WJ2024008', address: '望江路55号' }
      ]
    },
    loadUsers() {
      this.loading = true
      setTimeout(() => {
        this.list = this.getMockData()
        this.loading = false
      }, 500)
    },
    goPanorama(item) {
      this.$router.push({
        path: '/panorama',
        query: { customerName: item.userName, customerNo: item.userNo }
      })
    }
  }
}
</script>

<style scoped lang="less">
.page-select {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px;
}
.loading-area {
  display: flex;
  justify-content: center;
  align-items: center;
  padding-top: 60px;
}
.result-header {
  font-size: 13px;
  color: #999;
  padding: 12px 0 8px;
}
.user-card {
  position: relative;
  background: #fff;
  border-radius: 8px;
  padding: 14px 16px;
  margin-bottom: 10px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
  cursor: pointer;
}
.card-row {
  display: flex;
  align-items: center;
  line-height: 1.8;
}
.card-label {
  width: 72px;
  font-size: 13px;
  color: #999;
  flex-shrink: 0;
}
.card-value {
  flex: 1;
  font-size: 14px;
  color: #333;
  text-align: right;
}
.card-arrow {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
}
</style>