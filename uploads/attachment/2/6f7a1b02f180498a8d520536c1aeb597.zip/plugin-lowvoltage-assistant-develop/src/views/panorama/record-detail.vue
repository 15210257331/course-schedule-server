<template>
  <div class="page-detail">
    <van-nav-bar
      title="服务记录详情"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <!-- 基础信息模块 -->
      <div class="section-card">
        <van-cell-group :border="false">
          <van-cell title="工单编号" :value="info.orderNo" :border="false" />
          <van-cell title="工单生成时间" :value="info.createTime" :border="false" />
          <van-cell title="用户编号" :value="info.userNo" :border="false" />
          <van-cell title="用户名称" :value="info.userName" :border="false" />
          <van-cell title="用电地址" :value="info.address" :border="false" />
          <van-cell title="客户联系人" :value="info.contactPerson" :border="false" />
          <van-cell title="联系方式" :value="info.contactPhone" :border="false" />
          <van-cell title="业务类型" :value="info.bizTypeName" :border="false" />
          <van-cell title="计划开始日期" :value="info.planStartDate" :border="false" />
          <van-cell title="计划结束日期" :value="info.planEndDate" :border="false" />
        </van-cell-group>
        <div class="task-desc">
          <div class="desc-label">任务描述</div>
          <div class="desc-text">{{ info.taskDesc }}</div>
        </div>
      </div>
      <!-- 服务详情模块 -->
      <div class="section-card">
        <div class="section-title">
          <span>服务详情</span>
          <van-tag type="primary" size="small">{{ serviceList.length }}条</van-tag>
        </div>
        <div v-if="serviceList.length === 0" class="empty-area">
          <van-empty description="暂无服务记录" />
        </div>
        <div v-else class="service-timeline">
          <div
            v-for="(item, idx) in serviceList"
            :key="idx"
            class="service-item"
          >
            <div class="item-dot" :class="item.processStatus === '01' ? 'unsolved' : 'solved'" />
            <div v-if="idx < serviceList.length - 1" class="item-line" />
            <div class="item-content">
              <div class="item-header">
                <span class="item-time">{{ item.serviceTime }}</span>
                <van-tag
                  :type="item.processStatus === '01' ? 'warning' : 'success'"
                  size="small"
                >{{ item.processStatusName }}</van-tag>
              </div>
              <div class="item-body">
                <div class="item-field">
                  <span class="field-label">客户工程师</span>
                  <span class="field-value">{{ item.engineerName }}</span>
                </div>
                <div class="item-field">
                  <span class="field-label">服务内容</span>
                  <span class="field-value">{{ item.serviceContent }}</span>
                </div>
                <div class="item-field">
                  <span class="field-label">服务地址</span>
                  <span class="field-value">{{ item.serviceAddress }}</span>
                </div>
                <div class="item-field">
                  <span class="field-label">附件信息</span>
                </div>
                <div class="attachment-list">
                  <div
                    v-for="(att, attIdx) in item.attachments"
                    :key="attIdx"
                    class="attachment-item"
                    @click="previewAttachment(att)"
                  >
                    <van-icon :name="att.fileType === 'video' ? 'video-o' : 'photo-o'" :color="att.fileType === 'video' ? '#ee0a24' : '#2b6ef7'" size="20" />
                    <span class="att-name">{{ att.fileName }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { queryOrderInfo, queryProcessHistory } from '@/api/const'

export default {
  name: 'RecordDetailPage',
  data() {
    return {
      loading: false,
      info: {},
      serviceList: []
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      const orderId = this.$route.query.id
      if (!orderId) {
        window.$toast.show('缺少工单ID')
        return
      }

      try {
        this.loading = true
        window.$toast.loading()

        const [orderRes, processRes] = await Promise.all([
          window.$Api.request(queryOrderInfo, { orderId }),
          window.$Api.request(queryProcessHistory, { orderId })
        ])

        window.$toast.clear()
        this.loading = false

        this.info = orderRes?.code === '00000' ? (orderRes.data || {}) : {}
        this.serviceList = processRes?.code === '00000' ? (Array.isArray(processRes.data) ? processRes.data : []) : []
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },
    previewAttachment(att) {
      window.$toast.show('附件预览: ' + att.fileName)
    }
  }
}
</script>

<style scoped lang="less">
.page-detail {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.task-desc {
  padding: 8px 16px 16px;
}
.desc-label {
  font-size: 13px;
  color: #999;
  margin-bottom: 4px;
}
.desc-text {
  font-size: 14px;
  color: #555;
  line-height: 1.6;
}
.empty-area {
  padding: 10px 0;
}
.service-timeline {
  padding: 12px 16px 16px;
}
.service-item {
  position: relative;
  padding-left: 24px;
  margin-bottom: 16px;
}
.item-dot {
  position: absolute;
  left: 0;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #07c160;
  background: #fff;
  z-index: 1;
  &.unsolved {
    border-color: #ff976a;
  }
  &.solved {
    border-color: #07c160;
  }
}
.item-line {
  position: absolute;
  left: 4px;
  top: 14px;
  width: 2px;
  height: calc(100% + 4px);
  background: #e8e8e8;
}
.service-item:last-child .item-line {
  display: none;
}
.item-content {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}
.item-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}
.item-time {
  font-size: 12px;
  color: #999;
}
.item-body {
  margin-top: 4px;
}
.item-field {
  display: flex;
  line-height: 1.8;
  .field-label {
    width: 72px;
    font-size: 12px;
    color: #999;
    flex-shrink: 0;
  }
  .field-value {
    flex: 1;
    font-size: 12px;
    color: #333;
    text-align: right;
  }
}
.attachment-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 4px;
  padding-left: 72px;
}
.attachment-item {
  display: flex;
  align-items: center;
  gap: 4px;
  background: #fff;
  border-radius: 4px;
  padding: 4px 8px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
  cursor: pointer;
}
.att-name {
  font-size: 11px;
  color: #666;
  max-width: 80px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>