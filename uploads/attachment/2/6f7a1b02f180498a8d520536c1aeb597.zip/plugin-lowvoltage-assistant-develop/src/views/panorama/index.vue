<template>
  <div class="page-panorama">
    <van-nav-bar
      title="服务全景"
      left-arrow
      :placeholder="true"
      :safe-area-inset-top="true"
      :border="false"
      @click-left="$router.back()"
    />
    <div class="page-content">
      <!-- 基础信息模块 -->
      <div class="section-card">
        <div class="section-title">基础信息</div>
        <van-cell-group :border="false">
          <van-cell title="用户编号" :value="customer.custNo" :border="false" />
          <van-cell title="用户名称" :value="customer.custName" :border="false" />
          <van-cell title="用电地址" :value="customer.address" :border="false" />
          <van-cell title="客户联系人" :value="customer.contactPerson" :border="false" />
          <van-cell title="联系方式" :value="customer.contactPhone" :border="false" />
        </van-cell-group>
      </div>
      <!-- 服务概览模块 -->
      <div class="section-card">
        <div class="section-title">
          <span>服务概览</span>
          <div class="time-filter">
            <van-dropdown-menu direction="down" :overlay="false">
              <van-dropdown-item v-model="timeRange" :options="timeOptions" @change="onTimeRangeChange" />
            </van-dropdown-menu>
          </div>
        </div>
        <div class="stats-grid">
          <div
            v-for="stat in statsList"
            :key="stat.type"
            :class="['stat-item', activeBizType === stat.type ? 'active' : '']"
            @click="onBizTypeClick(stat.type)"
          >
            <div class="stat-value" :style="{ color: stat.color }">{{ stat.count }}</div>
            <div class="stat-label">{{ stat.label }}</div>
          </div>
        </div>
      </div>
      <!-- 服务记录列表模块 -->
      <div class="section-card">
        <div class="section-title">
          <span>服务记录列表</span>
          <van-tag v-if="listTotal" type="primary" size="small">{{ listTotal }}条</van-tag>
        </div>
        <van-list
          v-model="listLoading"
          :finished="listFinished"
          finished-text="没有更多了"
          @load="onListLoad"
        >
          <template v-if="filteredList.length > 0">
            <div class="timeline-section">
              <div class="custom-timeline">
                <div
                  v-for="item in filteredList"
                  :key="item.id"
                  class="timeline-item"
                  @click="goRecordDetail(item)"
                >
                  <div class="timeline-dot" :style="{ borderColor: getBizTypeColor(item.bizType) }" />
                  <div class="timeline-line" />
                  <div class="timeline-content">
                    <div class="record-card">
                      <div class="card-top">
                        <span class="biz-type" :style="{ color: getBizTypeColor(item.bizType) }">{{ getBizTypeName(item.bizType) }}</span>
                        <van-tag :type="getStatusType(item.orderStatus)" size="small">{{ item.orderStatusName }}</van-tag>
                      </div>
                      <div class="card-field">
                        <span class="field-label">工单编号</span>
                        <span class="field-value">{{ item.orderNo }}</span>
                      </div>
                      <div class="card-field">
                        <span class="field-label">服务时间</span>
                        <span class="field-value">{{ item.planStartDate }}</span>
                      </div>
                      <div class="card-field">
                        <span class="field-label">客户工程师</span>
                        <span class="field-value">{{ item.engineerName }}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </van-list>
        <van-empty v-if="!loading && !listLoading && filteredList.length === 0" description="暂无服务记录" />
      </div>
    </div>
    <van-popup v-model="showDatePicker" position="bottom" round>
      <van-datetime-picker
        v-model="customStartDate"
        type="date"
        title="选择开始日期"
        @confirm="onCustomStartConfirm"
        @cancel="showDatePicker = false"
      />
    </van-popup>
    <van-popup v-model="showDateEndPicker" position="bottom" round>
      <van-datetime-picker
        v-model="customEndDate"
        type="date"
        title="选择结束日期"
        :min-date="customStartDate"
        @confirm="onCustomEndConfirm"
        @cancel="showDateEndPicker = false"
      />
    </van-popup>
    <!-- 列表筛选弹窗 -->
    <van-popup v-model="showBizTypePicker" position="bottom" round>
      <van-picker
        :columns="bizTypeColumns"
        @confirm="onBizTypeConfirm"
        @cancel="showBizTypePicker = false"
        title="选择业务类型"
      />
    </van-popup>
    <van-popup v-model="showEngineerPicker" position="bottom" round>
      <van-picker
        :columns="engineerColumns"
        @confirm="onEngineerConfirm"
        @cancel="showEngineerPicker = false"
        title="选择客户工程师"
      />
    </van-popup>
    <van-popup v-model="showStartDatePicker" position="bottom" round>
      <van-datetime-picker
        v-model="listStartDate"
        type="date"
        title="选择开始日期"
        @confirm="onListStartConfirm"
        @cancel="showStartDatePicker = false"
      />
    </van-popup>
    <van-popup v-model="showEndDatePicker" position="bottom" round>
      <van-datetime-picker
        v-model="listEndDate"
        type="date"
        title="选择结束日期"
        :min-date="listStartDate"
        @confirm="onListEndConfirm"
        @cancel="showEndDatePicker = false"
      />
    </van-popup>
  </div>
</template>

<script>
import { queryCustomerInfo, queryOrderStats, queryOrderList } from '@/api/const'

const BIZ_TYPE_MAP = {
  '01': { label: '催费', color: '#ff976a' },
  '02': { label: '停电', color: '#ee0a24' },
  '03': { label: '诉求', color: '#1989fa' },
  '04': { label: '现场勘察', color: '#07c160' },
  '05': { label: '设备更换', color: '#7232dd' },
  '06': { label: '巡视', color: '#2b6ef7' },
  '07': { label: '安全隐患', color: '#ee0a24' }
}

const STATS_KEY_MAP = {
  '01': 'urgeNoticeCount',
  '02': 'powerOffNoticeCount',
  '03': 'appealCount',
  '04': 'siteSurveyCount',
  '05': 'deviceReplaceCount',
  '06': 'patrolCount',
  '07': 'safetyHazardCount'
}

export default {
  name: 'PanoramaPage',
  data() {
    return {
      customer: {},
      loading: false,
      // 时间筛选
      timeRange: '3m',
      timeOptions: [
        { text: '近3个月', value: '3m' },
        { text: '近半年', value: '6m' }
      ],
      showDatePicker: false,
      showDateEndPicker: false,
      customStartDate: new Date(),
      customEndDate: new Date(),
      customStartStr: '',
      customEndStr: '',
      // 业务类型筛选
      activeBizType: '',
      // 统计数据
      listTotal: 0,
      statsList: [
        { type: '01', label: '催费', count: 0, color: '#ff976a' },
        { type: '02', label: '停电', count: 0, color: '#ee0a24' },
        { type: '03', label: '诉求', count: 0, color: '#1989fa' },
        { type: '04', label: '现场勘察', count: 0, color: '#07c160' },
        { type: '05', label: '设备更换', count: 0, color: '#7232dd' },
        { type: '06', label: '巡视', count: 0, color: '#2b6ef7' },
        { type: '07', label: '安全隐患', count: 0, color: '#ee0a24' }
      ],
      // 服务记录列表
      allRecords: [],
      filteredList: [],
      pageNo: 1,
      pageSize: 10,
      listLoading: true,
      listFinished: false,
      // 列表筛选弹窗
      showBizTypePicker: false,
      showEngineerPicker: false,
      showStartDatePicker: false,
      showEndDatePicker: false,
      listStartDate: new Date(),
      listEndDate: new Date(),
      listFilter: {
        bizType: '',
        bizTypeLabel: '',
        engineer: '',
        engineerLabel: '',
        startDate: '',
        endDate: ''
      },
      bizTypeColumns: [
        { text: '全部', value: '' },
        { text: '催费', value: '01' },
        { text: '停电', value: '02' },
        { text: '诉求', value: '03' },
        { text: '现场勘察', value: '04' },
        { text: '设备更换', value: '05' },
        { text: '巡视', value: '06' },
        { text: '安全隐患', value: '07' }
      ],
      engineerColumns: ['全部', '张伟', '李强', '王芳', '刘洋']
    }
  },
  mounted() {
    this.loadPageData()
  },
  methods: {
    /** 构建查询参数 */
    buildQueryParams(extra) {
      const custNo = this.$route.query.customerNo
      const params = { custNo }
      // 计算时间范围
      const now = new Date()
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      if (this.timeRange === '3m') {
        const start = new Date(now)
        start.setMonth(start.getMonth() - 3)
        params.planStartDateStart = fmt(start)
        params.planStartDateEnd = fmt(now)
      } else if (this.timeRange === '6m') {
        const start = new Date(now)
        start.setMonth(start.getMonth() - 6)
        params.planStartDateStart = fmt(start)
        params.planStartDateEnd = fmt(now)
      } else if (this.timeRange === 'custom') {
        if (this.customStartStr && this.customEndStr) {
          params.planStartDateStart = this.customStartStr
          params.planStartDateEnd = this.customEndStr
        }
      }
      // 业务类型
      if (this.activeBizType) {
        params.bizType = this.activeBizType
      }
      return { ...params, ...extra }
    },

    async loadPageData() {
      const custNo = this.$route.query.customerNo
      if (!custNo) return

      try {
        this.loading = true
        window.$toast.loading()

        // 并行加载客户信息和统计数据
        const [customerRes] = await Promise.all([
          window.$Api.request(queryCustomerInfo, { custNo })
        ])
        this.customer = customerRes?.code === '00000' ? (customerRes.data || {}) : {}

        // 加载统计和列表（带上当前筛选条件）
        await this.fetchStatsAndList()

        window.$toast.clear()
        this.loading = false
      } catch (err) {
        window.$toast.clear()
        this.loading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    async fetchStatsAndList() {
      // 重置列表分页状态
      this.pageNo = 1
      this.allRecords = []
      this.listFinished = false
      this.listLoading = true

      const params = this.buildQueryParams()
      const listParams = {
        ...params,
        pageNo: this.pageNo,
        pageSize: this.pageSize
      }
      try {
        const [statsRes, listRes] = await Promise.all([
          window.$Api.request(queryOrderStats, params),
          window.$Api.request(queryOrderList, listParams)
        ])

        // 更新统计数据
        if (statsRes?.code === '00000' && statsRes.data) {
          this.statsList = this.statsList.map(item => ({
            ...item,
            count: statsRes.data[STATS_KEY_MAP[item.type]] || 0
          }))
          // 汇总所有业务类型的总条数（来自 EMSS_20260624007 接口）
          this.listTotal = Object.values(STATS_KEY_MAP).reduce((sum, key) => sum + (statsRes.data[key] || 0), 0)
        }

        // 更新列表数据（第一页）
        const newRecords = listRes?.code === '00000' ? (Array.isArray(listRes.data) ? listRes.data : []) : []
        this.allRecords = newRecords
        this.pageNo++
        this.applyListFilter()
        this.listLoading = false
      } catch (err) {
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    async onListLoad() {
      try {
        const params = this.buildQueryParams()
        const listParams = {
          ...params,
          pageNo: this.pageNo,
          pageSize: this.pageSize
        }
        const listRes = await window.$Api.request(queryOrderList, listParams)
        const newRecords = listRes?.code === '00000' ? (Array.isArray(listRes.data) ? listRes.data : []) : []

        this.allRecords = [...this.allRecords, ...newRecords]
        this.pageNo++
        this.listLoading = false

        if (newRecords.length < this.pageSize) {
          this.listFinished = true
        }

        this.applyListFilter()
      } catch (err) {
        this.listLoading = false
        window.$toast.show(err.message?.message || err.message || err)
      }
    },

    /** 列表端的筛选（只在当前 allRecords 中过滤 bizType，不做 API 调用） */
    applyListFilter() {
      let list = [...this.allRecords]
      // 列表端 bizType 筛选（弹窗中的筛选）
      if (this.listFilter.bizType) {
        list = list.filter(item => item.bizType === this.listFilter.bizType)
      }
      if (this.listFilter.engineer) {
        list = list.filter(item => item.engineerName === this.listFilter.engineer)
      }
      if (this.listFilter.startDate) {
        list = list.filter(item => item.planStartDate >= this.listFilter.startDate)
      }
      if (this.listFilter.endDate) {
        list = list.filter(item => item.planStartDate <= this.listFilter.endDate)
      }
      // 按时间倒序
      list.sort((a, b) => (b.createTime || b.planStartDate || '').localeCompare(a.createTime || a.planStartDate || ''))
      this.filteredList = list
    },

    /** 时间范围切换 */
    onTimeRangeChange(value) {
      this.timeRange = value
      if (value === 'custom') {
        this.showDatePicker = true
      } else {
        this.fetchStatsAndList()
      }
    },

    onCustomStartConfirm(value) {
      this.customStartDate = value
      this.showDatePicker = false
      this.showDateEndPicker = true
    },

    onCustomEndConfirm(value) {
      this.customEndDate = value
      this.showDateEndPicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.customStartStr = fmt(this.customStartDate)
      this.customEndStr = fmt(this.customEndDate)
      this.fetchStatsAndList()
    },

    /** 顶部统计业务类型点击 → 切换筛选，重新加载统计和列表 */
    onBizTypeClick(type) {
      this.activeBizType = this.activeBizType === type ? '' : type
      this.fetchStatsAndList()
    },

    /** 顶部时间 + bizType 联动 → 列表也同步更新（已在 fetchStatsAndList 中覆盖） */
    // 列表端的额外独立筛选弹窗
    onBizTypeConfirm(value) {
      const item = this.bizTypeColumns.find(c => c.text === value)
      this.listFilter.bizType = item ? item.value : ''
      this.listFilter.bizTypeLabel = value === '全部' ? '' : value
      this.showBizTypePicker = false
      this.applyListFilter()
    },

    onEngineerConfirm(value) {
      this.listFilter.engineer = value === '全部' ? '' : value
      this.listFilter.engineerLabel = value === '全部' ? '' : value
      this.showEngineerPicker = false
      this.applyListFilter()
    },

    onListStartConfirm(value) {
      this.listStartDate = value
      this.showStartDatePicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.listFilter.startDate = fmt(value)
    },

    onListEndConfirm(value) {
      this.listEndDate = value
      this.showEndDatePicker = false
      const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      this.listFilter.endDate = fmt(value)
    },

    onResetListFilter() {
      this.listFilter = { bizType: '', bizTypeLabel: '', engineer: '', engineerLabel: '', startDate: '', endDate: '' }
      this.applyListFilter()
    },

    onApplyListFilter() {
      this.applyListFilter()
    },

    getBizTypeName(type) {
      return BIZ_TYPE_MAP[type]?.label || '其他'
    },

    getBizTypeColor(type) {
      return BIZ_TYPE_MAP[type]?.color || '#999'
    },

    getStatusType(status) {
      const map = { '01': 'warning', '02': 'primary', '03': 'success' }
      return map[status] || 'default'
    },

    goRecordDetail(item) {
      this.$router.push({
        path: '/panorama/record-detail',
        query: { id: item.orderId }
      })
    }
  }
}
</script>

<style scoped lang="less">
.page-panorama {
  min-height: 100vh;
  background: #f5f6fa;
}
.page-content {
  padding: 0 16px 16px;
}
.section-card {
  background: #fff;
  border-radius: 8px;
  margin-bottom: 12px;
  overflow: hidden;
}
.section-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px 0;
  font-size: 15px;
  font-weight: 500;
  color: #333;
}
.time-filter {
  :deep(.van-dropdown-menu__bar) {
    box-shadow: none;
    height: 28px;
  }
  :deep(.van-dropdown-menu__title) {
    font-size: 12px;
    color: #2b6ef7;
  }
}
.stats-grid {
  display: flex;
  flex-wrap: wrap;
  padding: 12px 12px 4px;
  gap: 8px;
}
.stat-item {
  width: calc(25% - 6px);
  background: #f7f8fa;
  border-radius: 8px;
  padding: 10px 4px;
  text-align: center;
  border: 1px solid transparent;
  cursor: pointer;
  &.active {
    border-color: #2b6ef7;
    background: #f0f4ff;
  }
  .stat-value {
    font-size: 18px;
    font-weight: 600;
  }
  .stat-label {
    font-size: 11px;
    color: #666;
    margin-top: 2px;
  }
}
.list-filter-section {
  border-top: 1px solid #f5f6fa;
  padding: 4px 0;
}
.list-filter-inner {
  background: #f7f8fa;
  margin: 0 12px;
  border-radius: 6px;
  padding: 4px 0;
}
.list-filter-actions {
  display: flex;
  justify-content: center;
  gap: 24px;
  padding: 8px 0 12px;
}
.timeline-section {
  padding: 12px 16px 16px;
}
.custom-timeline {
  position: relative;
  padding-left: 20px;
}
.timeline-item {
  position: relative;
  padding-bottom: 14px;
}
.timeline-dot {
  position: absolute;
  left: -14px;
  top: 6px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #2b6ef7;
  background: #fff;
  z-index: 1;
}
.timeline-line {
  position: absolute;
  left: -10px;
  top: 16px;
  width: 2px;
  height: calc(100% - 14px);
  background: #e8e8e8;
}
.timeline-item:last-child .timeline-line {
  display: none;
}
.timeline-content {
  padding-left: 4px;
}
.record-card {
  background: #f7f8fa;
  border-radius: 6px;
  padding: 10px 12px;
}
.card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}
.biz-type {
  font-size: 13px;
  font-weight: 500;
}
.card-field {
  display: flex;
  line-height: 1.8;
  .field-label {
    font-size: 12px;
    color: #999;
    flex-shrink: 0;
  }
  .field-value {
    flex: 1;
    font-size: 12px;
    color: #333;
    text-align: right;
  }
}
</style>