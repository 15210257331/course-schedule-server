import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routeList = () => {
  let list = []
  const routerModules = require.context('./modules', true, /\.route\.js/)
  routerModules.keys().forEach((key) => {
    list = list.concat(routerModules(key).default)
  })
  return list
}

const router = new VueRouter({
  routes: routeList(),
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    }
    return { x: 0, y: 0 }
  }
})

export default router