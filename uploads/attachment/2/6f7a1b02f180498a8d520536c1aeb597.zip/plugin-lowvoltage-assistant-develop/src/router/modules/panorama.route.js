export default [
  {
    path: '/panorama',
    name: 'panorama',
    component: () => import('@/views/panorama'),
    meta: {
      title: '服务全景',
      keepAlive: false
    }
  },
  {
    path: '/panorama/user-select',
    name: 'panorama-user-select',
    component: () => import('@/views/panorama/user-select'),
    meta: {
      title: '用户选择',
      keepAlive: false
    }
  },
  {
    path: '/panorama/record-detail',
    name: 'panorama-record-detail',
    component: () => import('@/views/panorama/record-detail'),
    meta: {
      title: '服务记录',
      keepAlive: false
    }
  }
]