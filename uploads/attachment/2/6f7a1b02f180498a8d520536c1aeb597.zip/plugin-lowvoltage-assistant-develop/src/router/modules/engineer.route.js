export default [
  {
    path: '/engineer',
    name: 'engineer',
    component: () => import('@/views/engineer'),
    meta: {
      title: '工程师档案',
      keepAlive: true
    }
  },
  {
    path: '/engineer/detail',
    name: 'engineer-detail',
    component: () => import('@/views/engineer/detail'),
    meta: {
      title: '档案详情',
      keepAlive: false
    }
  },
  {
    path: '/engineer/history',
    name: 'engineer-history',
    component: () => import('@/views/engineer/history'),
    meta: {
      title: '历史变更',
      keepAlive: false
    }
  }
]