export default [
  {
    path: '/workbench',
    name: 'workbench',
    component: () => import('@/views/workbench'),
    meta: {
      title: '我的台账',
      keepAlive: true
    }
  },
  {
    path: '/workbench/detail',
    name: 'workbench-detail',
    component: () => import('@/views/workbench/detail'),
    meta: {
      title: '工单详情',
      keepAlive: false
    }
  },
  {
    path: '/workbench/filter',
    name: 'workbench-filter',
    component: () => import('@/views/workbench/filter'),
    meta: {
      title: '筛选条件',
      keepAlive: false
    }
  },
  {
    path: '/workbench/task-handle',
    name: 'workbench-task-handle',
    component: () => import('@/views/workbench/task-handle'),
    meta: {
      title: '任务处理',
      keepAlive: false
    }
  }
]