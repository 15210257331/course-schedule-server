export default [
  {
    path: '/user-query',
    name: 'user-query',
    component: () => import('@/views/user-query'),
    meta: {
      title: '用户查询',
      keepAlive: true
    }
  },
  {
    path: '/user-query/result',
    name: 'user-query-result',
    component: () => import('@/views/user-query/result'),
    meta: {
      title: '查询结果',
      keepAlive: false
    }
  },
  {
    path: '/user-query/detail',
    name: 'user-query-detail',
    component: () => import('@/views/user-query/detail'),
    meta: {
      title: '客户明细',
      keepAlive: false
    }
  }
]