export default [
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/register'),
    meta: {
      title: '现场登记',
      keepAlive: false
    }
  },
  {
    path: '/register/user-select',
    name: 'register-user-select',
    component: () => import('@/views/register/user-select'),
    meta: {
      title: '选择关联用户',
      keepAlive: false
    }
  },
  {
    path: '/register/success',
    name: 'register-success',
    component: () => import('@/views/register/success'),
    meta: {
      title: '提交成功',
      keepAlive: false
    }
  }
]