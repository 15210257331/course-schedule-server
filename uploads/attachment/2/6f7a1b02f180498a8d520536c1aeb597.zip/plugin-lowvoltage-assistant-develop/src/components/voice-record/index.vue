<template>
  <div class="voice" @touchstart="ontouchstart" @touchend="ontouchend">
    <svg t="1696648574320" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4017" width="20" height="20"><path d="M512 704c105.6 0 192-86.4 192-192V256c0-105.6-86.4-192-192-192s-192 86.4-192 192v256c0 105.6 86.4 192 192 192z" fill="#1296db" p-id="4018"></path><path d="M832 512c0-19.2-12.8-32-32-32s-32 12.8-32 32c0 140.8-115.2 256-256 256s-256-115.2-256-256c0-19.2-12.8-32-32-32s-32 12.8-32 32c0 166.4 128 300.8 288 316.8V896h-160c-19.2 0-32 12.8-32 32s12.8 32 32 32h384c19.2 0 32-12.8 32-32s-12.8-32-32-32h-160v-67.2c160-16 288-150.4 288-316.8z" fill="#1296db" p-id="4019"></path></svg>
    <div v-if="isSpeak" class="circle"></div>
  </div>
</template>

<script>
import { Toast } from 'vant'
export default {
  name:'voice-record',
  data() {
    return {
      isRecord: false,
      isSpeak: false
    }
  },
  props: {},
  watch:{},
  methods: {
    ontouchstart(e) {
      e.preventDefault()
      this.timeOut = setTimeout(() => {
        console.log('在这里执行长按事件---', this.timeOut)
        window.wx.startRecord()
        Toast.loading({
          message: '请说话...',
          loadingType: 'spinner',
          duration: 0
        })
        this.isSpeak = true
        this.timeOut = 0
        this.isRecord = true
      }, 500)
    },
    ontouchend(e) {
      e.preventDefault()
      clearTimeout(this.timeOut)
      console.log('isrecord', this.isRecord);
      if (this.timeOut !== 0) {
        Toast('长按录音')
      } else {
        if (!this.isRecord) {
          return
        }
        Toast.clear()
        this.onRecordEnd()
        this.isRecord = false
      }
    },
    onRecordEnd() {
      this.isSpeak = false
      let that = this
      window.wx.stopRecord({
        success: function (res) {
          let localId = res.localId
          console.log('录音结果', res)
          window.wx.translateVoice({
            localId: localId, // 需要识别的音频的本地Id，由录音相关接口获得，音频时长不能超过60秒
            isShowProgressTips: 1, // 默认为1，显示进度提示
            success: function (res) {
              console.log('语音识别结果------', res);
              if (res.translateResult =="") {
                return
              }
              that.$emit('recordEnd', res.translateResult.slice(0,res.translateResult.length-1))
            }
          })
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.voice {
  padding: 0 5px;
  display: flex;
  align-items: center;
  position: relative;
  .circle {
    --scale: 1;
    position: absolute;
    top: 35%;
    right: -8px;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    border-radius: 50%;
    width: 28px;
    height: 28px;
    animation: pulse 3s infinite ease-in-out;
    transition: background 2s ease-in-out;
    /* apparently having using var in rgb breaks sass... */
    background: rgba(92, 190, 254, 0.2);
    mix-blend-mode: luminosity;
  }
}
</style>
