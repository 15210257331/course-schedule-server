<template>
  <div class="div-view" :class="{'div-page': appFlag}">
    <van-nav-bar
      :class="{'app-top': appFlag}"
      :title="title || $route.meta.title"
      :left-text="leftText"
      :right-text="rightText"
      :left-arrow="leftArrow"
      :border="border"
      :fixed="fixed"
      @click-left="onClickLeft"
      @click-right="onClickRight"
      safe-area-inset-top>
      <template #right>
        <slot name="right"></slot>
      </template>
    </van-nav-bar>
    <div class="div-container" :class="{'app-top': appFlag}">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'container-view',

  props: {
    title: {
      type: String,
      default: ''
    },
    fontColor: {
      type: String,
      default: '#18BA88'
    },
    fontSize: {
      type: String,
      default: '22px'
    },
    leftText: {
      type: String,
      default: ''
    },
    leftArrow: {
      type: Boolean,
      default: true
    },
    rightText: {
      type: String,
      default: ''
    },
    fixed: {
      type: Boolean,
      default: true
    },
    border: {
      type: Boolean,
      default: false
    },
    closeWindow: {
      type: Boolean,
      required: false,
      default: false
    },
    leftClickEmit: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data() {
    return {}
  },

  computed: {
    appFlag() {
      return ['app'].includes(process.env.VUE_APP_TYPE)
    },
  },

  watch: {},
  created() {},
  mounted() {},
  destroyed() {},
  methods: {
    onClickLeft() {
      if (this.closeWindow) {
        window.Vegeta?.hyDock?.close()
        return
      } else if (this.leftClickEmit) {
        this.$emit('onLeft')
        return
      }
      this.$router.go(-1)
    },
    onClickRight() {
      this.$emit('onRight')
    }
  }
}
</script>

<style scoped lang="less">
.div-view {
  height: 100vh;
  background-size: 100% 100%;
  background-repeat: no-repeat;
  background-image: linear-gradient(180deg, #1890ff 0%, #f6f9fd 20%, #ffffff 100%);
  background-color: #f6f9fd;

  .app-top {
    margin-top: 24px;
  }
}

.div-page {
  background-image: url('~@/assets/images/bg-home.png');
  background-size: 100% 196px;
  background-repeat: no-repeat;
}

.div-container {
  display: flex;
  flex-direction: column;
  padding-top: constant(safe-area-inset-top);
  padding-top: env(safe-area-inset-top);
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
  position: fixed;
  top: 44px;
  left: 0;
  right: 0;
  bottom: 0;
  overflow-y: hidden;
}

.div-content {
  flex: 1;
  overflow-y: scroll;
}

/deep/ .van-nav-bar {
  background-color: transparent;

  .van-nav-bar__title {
    color: white;
    font-size: 18px;
    font-weight: bold;
  }

  .van-nav-bar__arrow {
    color: white;
    font-size: 18px;
  }

  .van-nav-bar__right {
    font-size: 16px;
    color: #ffffff;
  }
}
</style>