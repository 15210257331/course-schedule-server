<template>
  <div class="field" :class="{'border':border}">
    <van-field
      :label="label"
      v-model="inputValue"
      :type="inputType"
      :placeholder="holderStr"
      :input-align="inputAlign"
      :maxlength="maxlength"
      :required="required"
      :readonly="readonly"
      :clearable="clearable"
      :is-link="isLink">
      <template #label>
        <slot name="label"/>
      </template>
      <template #input>
        <slot name="input"/>
      </template>
      <template #right-icon>
        <slot name="right-icon"/>
        <span v-if="rightUnit" class="right">{{ rightUnit }}</span>
      </template>
    </van-field>
  </div>
</template>

<script>
export default {
  name: 'FieldInput',

  model: {
    props: 'value',
    event: 'change'
  },

  props: {
    value: [String, Number],
    label: String,
    rightUnit: String,
    rightIcon: String,
    placeholder: {
      type: String,
      default: '请输入'
    },
    inputType: {
      type: String,
      default: 'text'
    },
    maxlength: {
      type: Number,
      default: 24
    },
    clearable: Boolean,
    required: Boolean,
    readonly: Boolean,
    isLink: Boolean,
    showFlag: Boolean,
    border: {
      type: Boolean,
      default: true
    },
    inputAlign: {
      type: String,
      default: 'right'
    }
  },

  data() {
    return {
      inputValue: ''
    }
  },

  computed: {
    holderStr() {
      if (this.readonly) {
        return '请选择'
      }
      return this.placeholder
    }
  },

  watch: {
    value: {
      handler() {
        this.inputValue = this.value
      },
      immediate: true,
      deep: true
    },
    inputValue(val) {
      this.$emit('change', val)
    }
  },

  mounted() {
    this.inputValue = this.value
  }
}
</script>

<style scoped lang="less">
.field {
  position: relative;
}

.right {
  color: #666666;
  font-size: 14px;
  margin-left: 4px;
}

.border {
  &::after {
    position: absolute;
    box-sizing: border-box;
    content: ' ';
    pointer-events: none;
    right: 16px;
    bottom: 0;
    left: 16px;
    border-bottom: 1px solid #F5F5F5;
  }
}

/deep/ .van-field {
  background-color: transparent;

  .van-field__label {
    color: #666666;
    font-size: 14px;
    font-weight: 400;
    width: max-content;
  }

  .van-field__right-icon {
    padding: 0;
    margin: 0;
    display: flex;
    align-items: center;
  }

  .van-cell__right-icon {
    padding: 0;
    margin: 0;
    display: flex;
    align-items: center;
  }
}
</style>