<template>
  <div class="cell-item">
    <div class="cell-name" :style="{ fontSize: fontSize + 'px' }">{{ name }}</div>
    <div class="cell-value-wrap">
      <span class="cell-value" :style="{ fontSize: fontSize + 'px' }">{{ value }}</span>
      <span v-if="unit" class="cell-unit">{{ unit }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CellItem',
  props: {
    name: {
      type: String,
      default: ''
    },
    value: {
      type: [String, Number],
      default: ''
    },
    unit: {
      type: String,
      default: ''
    },
    fontSize: {
      type: Number,
      default: 14
    }
  }
}
</script>

<style scoped lang="less">
.cell-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0;
}
.cell-name {
  color: #646566;
  flex-shrink: 0;
}
.cell-value-wrap {
  display: flex;
  align-items: center;
}
.cell-value {
  color: #323233;
  font-weight: 500;
}
.cell-unit {
  color: #969799;
  font-size: 12px;
  margin-left: 4px;
}
</style>
