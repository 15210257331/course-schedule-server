let components = []
const componentList = require.context('.', true, /\.vue$/)
componentList.keys().forEach((val) => {
  const value = componentList(val)
  components.push(value.default)
})

const install = (Vue) => {
  if (install.installed) return
  install.installed = true
  components.forEach((component) => {
    Vue.component(component.name, component)
  })
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install,
  ...components
}
