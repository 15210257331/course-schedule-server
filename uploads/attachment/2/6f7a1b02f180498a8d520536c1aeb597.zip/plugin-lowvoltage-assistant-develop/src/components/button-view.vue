<template>
  <div class="div-button">
    <slot></slot>
    <van-button
      :style="{
      marginRight: '16px',
      color: fontColor,
      fontSize: fontSize,
      fontWeight: fontWeight,
      borderRadius: borderRadius,
      borderColor: fontColor}"
      @click="clickLeft"
      :text="leftStr"
      v-if="leftStr"/>
    <van-button
      :style="{
      color: '#FFFFFF',
      fontSize: fontSize,
      fontWeight: fontWeight,
      borderRadius: borderRadius,
      backgroundColor: fontColor,
      borderColor: fontColor}"
      @click="clickRight"
      :text="rightStr"
      v-if="rightStr"/>
  </div>
</template>

<script>
export default {
  name: 'ButtonView',

  props: {
    fontColor: {
      type: String,
      default: '#1890FF'
    },
    fontSize: {
      type: String,
      default: '16px'
    },
    fontWeight: {
      type: String,
      default: '500'
    },
    borderRadius: {
      type: String,
      default: '20px'
    },
    leftStr: String,
    rightStr: {
      type: String,
      default: '提交'
    },
    clickLeft: {
      type: Function,
      default: function () {}
    },
    clickRight: {
      type: Function,
      default: function () {}
    }
  }
}
</script>

<style lang="less" scoped>
.div-button {
  padding: 12px 16px;
  display: flex;
  align-items: center;

  button {
    flex: 1;
    height: 40px;
    color: white;
    font-size: 16px;
    font-weight: 500;
    border-radius: 20px;
    border: 1px solid white;
  }
}
</style>