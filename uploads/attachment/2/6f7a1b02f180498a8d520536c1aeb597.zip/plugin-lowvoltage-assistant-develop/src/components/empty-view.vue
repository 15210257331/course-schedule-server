<template>
  <div class="empty-view">
    <van-image v-if="image" :src="image" class="empty-image" />
    <div class="empty-description">{{ description }}</div>
  </div>
</template>

<script>
export default {
  name: 'EmptyView',
  props: {
    description: {
      type: String,
      default: '暂无数据'
    },
    image: {
      type: String,
      default: ''
    }
  }
}
</script>

<style scoped lang="less">
.empty-view {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
}
.empty-image {
  width: 160px;
  height: 160px;
}
.empty-description {
  margin-top: 16px;
  font-size: 14px;
  color: #969799;
}
</style>
