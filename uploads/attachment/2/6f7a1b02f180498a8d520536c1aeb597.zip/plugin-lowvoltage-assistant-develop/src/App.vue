<template>
  <div id="app">
    <keep-alive :max="5">
      <router-view :key="$route.fullPath" v-if="$route.meta.keepAlive" />
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="less">
#app {
  width: 100%;
  min-height: 100vh;
  background: #f5f6fa;
}
</style>