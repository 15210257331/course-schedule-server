import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import user from './modules/user'
import workorder from './modules/workorder'
import schedule from './modules/schedule'
import common from './modules/common'
import getters from './getters'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    user,
    workorder,
    schedule,
    common
  },
  getters
})

export default store