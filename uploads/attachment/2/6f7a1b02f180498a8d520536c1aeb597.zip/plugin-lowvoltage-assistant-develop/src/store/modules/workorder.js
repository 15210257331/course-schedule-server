const state = {
  workorderList: [],
  currentWorkorder: null,
  filterConditions: {}
}

const mutations = {
  SET_WORKORDER_LIST(state, list) {
    state.workorderList = list
  },
  SET_CURRENT_WORKORDER(state, order) {
    state.currentWorkorder = order
  },
  SET_FILTER_CONDITIONS(state, conditions) {
    state.filterConditions = conditions
  }
}

const actions = {
  setWorkorderList({ commit }, list) {
    commit('SET_WORKORDER_LIST', list)
  },
  setCurrentWorkorder({ commit }, order) {
    commit('SET_CURRENT_WORKORDER', order)
  },
  setFilterConditions({ commit }, conditions) {
    commit('SET_FILTER_CONDITIONS', conditions)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}