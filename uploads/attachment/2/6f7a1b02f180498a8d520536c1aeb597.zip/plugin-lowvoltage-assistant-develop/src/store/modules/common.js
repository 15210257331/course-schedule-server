const state = {
  engineerList: [],
  servicePanorama: null,
  userInfo: null
}

const mutations = {
  SET_ENGINEER_LIST(state, list) {
    state.engineerList = list
  },
  SET_SERVICE_PANORAMA(state, data) {
    state.servicePanorama = data
  },
  storeUserInfo(state, info) {
    state.userInfo = info
  }
}

const actions = {
  setEngineerList({ commit }, list) {
    commit('SET_ENGINEER_LIST', list)
  },
  setServicePanorama({ commit }, data) {
    commit('SET_SERVICE_PANORAMA', data)
  },
  async fetchUserInfo({ commit, state }) {
    if (state.userInfo) {
      return state.userInfo
    }
    const userInfo = await window.Vegeta.hyDock.getUserInfo()
    if (!userInfo) {
      console.error('无法读取用户信息')
      return
    }

    if (process.env.VUE_APP_TYPE === 'dev' || process.env.VUE_APP_TYPE === 'uat') {
      userInfo.userNo = 'D96100153'
      userInfo.userName = '测试工程师'
      userInfo.orgNo = '31402'
      userInfo.orgName = '上海市南测试公司'
      window.Vegeta.hyUtils.setSessionstorage({ userInfo })
    }

    console.log('userInfo====', userInfo)
    commit('storeUserInfo', userInfo)
    return userInfo
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}