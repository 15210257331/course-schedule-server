const state = {
  userInfo: null,
  userList: [],
  selectedUser: null
}

const mutations = {
  SET_USER_INFO(state, info) {
    state.userInfo = info
  },
  SET_USER_LIST(state, list) {
    state.userList = list
  },
  SET_SELECTED_USER(state, user) {
    state.selectedUser = user
  }
}

const actions = {
  setUserInfo({ commit }, info) {
    commit('SET_USER_INFO', info)
  },
  setUserList({ commit }, list) {
    commit('SET_USER_LIST', list)
  },
  selectUser({ commit }, user) {
    commit('SET_SELECTED_USER', user)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}