const state = {
  scheduleList: [],
  currentDate: null
}

const mutations = {
  SET_SCHEDULE_LIST(state, list) {
    state.scheduleList = list
  },
  SET_CURRENT_DATE(state, date) {
    state.currentDate = date
  }
}

const actions = {
  setScheduleList({ commit }, list) {
    commit('SET_SCHEDULE_LIST', list)
  },
  setCurrentDate({ commit }, date) {
    commit('SET_CURRENT_DATE', date)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}