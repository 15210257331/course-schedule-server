const state = {
  loading: false,
  title: '低压服务助手',
  showTitleBar: false
}

const mutations = {
  SET_LOADING(state, loading) {
    state.loading = loading
  },
  SET_TITLE(state, title) {
    state.title = title
  },
  SET_SHOW_TITLE_BAR(state, show) {
    state.showTitleBar = show
  }
}

const actions = {
  setLoading({ commit }, loading) {
    commit('SET_LOADING', loading)
  },
  setTitle({ commit }, title) {
    commit('SET_TITLE', title)
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}