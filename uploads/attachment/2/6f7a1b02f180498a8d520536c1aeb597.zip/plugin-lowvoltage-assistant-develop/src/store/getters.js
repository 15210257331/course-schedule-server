const getters = {
  loading: state => state.app.loading,
  title: state => state.app.title,
  userInfo: state => state.user.userInfo,
  userList: state => state.user.userList,
  selectedUser: state => state.user.selectedUser,
  workorderList: state => state.workorder.workorderList,
  currentWorkorder: state => state.workorder.currentWorkorder
}

export default getters