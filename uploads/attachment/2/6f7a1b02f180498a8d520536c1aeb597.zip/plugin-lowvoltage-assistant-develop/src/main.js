import Es6Promise from 'es6-promise'
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import 'lib-flexible'
import '@/assets/less/index.less'
import '@/api'
import '@/utils'

import DialogUtils from '@/utils/dialog'
import toastUtils from '@/utils/toast.js'

// 引入 Vant 组件
import Vant from 'vant'
import 'vant/lib/index.less'
import 'vant/lib/icon/local.css'
Vue.use(Vant)

import Components from '@/components'
Vue.use(Components)

import appConfigParams from './config/igw-config'
require('es6-promise').polyfill()

Es6Promise.polyfill()

// 获取加密参数
const getParam = (variable) => {
  const query = decodeURI(window.location.search).substring(1)
  const vars = query.split('&')
  for (let i = 0; i < vars.length; i += 1) {
    const pair = vars[i].split('=')
    if (pair[0] === variable) {
      return pair[1]
    }
  }
  return ''
}
const packageName = getParam('packageName')
const appName = getParam('appName')
const appUrl = getParam('appUrl')

// 埋点引入
import masVueTrackWookong from '@utils/mas-vue-track-wookong'
const packageInfo = {
  default: {
    name: 'com.ls.shanghai.main.igw',
    version: '0.1.0'
  }
}
// 注册埋点组件
Vue.use(masVueTrackWookong, {
  showlog: false,
  encryp: true,
  router,
  packageInfo,
  url: appUrl,
  appName
})

// 链路采集引入
import ExectionUtils from '@/libs/ExceptionReporting.umd'
const appArr = appName.split('$')
let exePararms = {
  startTask: true,
  appId: appArr[0],
  workspaceId: appArr[1],
  pluginName: packageName,
}
// 根据具体项目判断，非正式环境需要指定公司环境的上报地址
if (process.env.VUE_APP_TYPE !== 'prod') {
  exePararms.H5ExectionUrl = 'http://172.20.64.153:7770/mam-service-mobiletracks-pre/collection/uploadErrorLog'
  exePararms.HttpExectionUrl = 'http://172.20.64.153:7770/mam-service-mobiletracks-pre/collection/uploadLinkLog'
}
Vue.use(ExectionUtils, exePararms)

// 引入集成依赖包
import Vegeta from '@utils/vegeta-base'
Vue.use(Vegeta, { ...appConfigParams })

// 生产环境初始化桥接
if (process.env.VUE_APP_PLATFORM === 'app') {
  try {
    window.Vegeta.hyDock.initTitleStyle({ showTitleBar: false })
  } catch (e) {
    console.log('Vegeta 桥接初始化失败', e)
  }
}

// 调试
import Eruda from 'eruda'
if (process.env.VUE_APP_TYPE === 'prod') {
  window.Vegeta.hyDock.getDataCacheInfo('debugFlag').then((res) => {
    console.log(`---debugFlag`, res)
    if (res.result === '1' || res === '1') {
      Eruda.init()
    }
  }).catch((err) => {
    console.log(`---debugFlag err`, err)
  })
}

window.$toast = toastUtils
window.$dialog = DialogUtils
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app')
