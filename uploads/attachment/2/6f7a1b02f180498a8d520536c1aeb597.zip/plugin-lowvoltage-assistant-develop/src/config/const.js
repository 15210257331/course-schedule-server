/** 常量定义 */

// 功能入口菜单
export const MENU_LIST = [
  { path: '/user-query', title: '用户查询', desc: '查询用户信息及工程师档案', icon: 'contact', bgColor: '#2b6ef7' },
  { path: '/panorama', title: '服务全景', desc: '客户服务概况与时间轴看板', icon: 'chart-trending-o', bgColor: '#07c160' },
  { path: '/register', title: '现场登记', desc: '登记现场服务工单信息', icon: 'edit', bgColor: '#ff976a' },
  { path: '/workbench', title: '我的台账', desc: '个人工作记录与任务台账', icon: 'manager-o', bgColor: '#1989fa' }
]

// 工单状态
export const WORKORDER_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  CLOSED: 'closed'
}

// 状态颜色映射
export const STATUS_COLOR_MAP = {
  pending: '#ff976a',
  processing: '#1989fa',
  completed: '#07c160',
  closed: '#969799'
}
