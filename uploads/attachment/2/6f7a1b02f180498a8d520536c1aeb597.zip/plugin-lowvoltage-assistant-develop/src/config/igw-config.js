let appConfig = {
  needAuth: false, // 是否需要走安全交互平台
  serviceUrl: 'http://172.20.64.153:7740/istateinvoke-server/iStateGridInvoke',
  appName: '20220117102454068000001092750725$20191213104235236000001015701523$ANDROID',
  iscpIP: '221.237.156.102', // 安全交互开放的ip
  iscpPort: '20082', // 安全交互平台开放给的端口
  iscpAppid: 'shandong', // 安全交互平台开放的应用标识
  serviceIp: '221.12.172.56', // 前置服务的ip地址
  servicePort: '1080', // 前置服务的端口
  env: 'uat', // 环境 uat、prod
  resource: 'masp',
  key: 'wkrpt', // // 文件中转中心 key
  appId: '1006943', // 应用 agentID
  encryp: true, // 是否接口加密
  openSign: true, // 是否开启签名
  hasSGMap: true,
  // H5异常上报api
  H5ExectionUrl: `http://172.20.64.153:7770/mam-service-mobiletracks-pre/collection/uploadErrorLog`,
  // 请求链路异常上报api
  HttpExectionUrl: `http://172.20.64.153:7770/mam-service-mobiletracks-pre/collection/uploadLinkLog`,
  uploadUrl: `http://172.20.64.153:7740/istateinvoke-server/iStateGridMaspFileInvoke`,
  uploadUrl2: `http://172.20.64.153:7740/istateinvoke-server/iStateGridMaspBase64FileInvoke`,
  fileKey: 'yx2FileCenter',
  attachDtlCateg: '01',
  centerSrc: 'flc',
  dispOpenFlag: '2',
} // 本地开发配置项

if (process.env.VUE_APP_TYPE === 'site-prod') {
  appConfig = {
    encryp: true,
    openSign: true,
    needAuth: false, // 是否需要走安全交互平台
    serviceUrl: '/istateinvoke-server/iStateGridInvoke',
    appName: '20211021100349051032121026671077$20211021100043059032121022441464$ANDROID', // 支撑平台标识
    iscpIP: '140.207.4.121', // 安全交互开放的ip
    iscpPort: '80', // 安全交互平台开放给的端口
    iscpAppid: 'e0d5a60f165c4e7b9fe1075e449f10bb', // 安全交互平台开放的应用标识
    serviceIp: '188.188.6.237', // 前置服务的ip地址
    servicePort: '18080', // 前置服务的端口
    env: 'prod', // 环境 uat、prod
    resource: 'masp', // 来源
    key: 'wkrpt', // // 文件中转中心 key
    appId: '1000760', // 应用 agentID
    platform: 'igw', // 指定平台
    uploadUrl: `/istateinvoke-server/iStateGridMaspFileInvoke`,
    fileKey: 'ydzcptWebdavx',
    centerSrc: 'bac',
    attachDtlCateg: '01',
    dispOpenFlag: '2',
    hasSGMap: true,
  }
}

//判断主应用是正式环境还是测试环境 通过获取跳转携带appName参数 存在就重新赋值
const getParam = (variable) => {
  const query = window.location.search.substring(1)
  const vars = query.split('&')
  for (let i = 0; i < vars.length; i++) {
    const pair = vars[i].split('=')
    if (pair[0] === variable) {
      return pair[1]
    }
  }
  return ''
}
if (getParam('appName')) {
  console.log(getParam('appName'), '获取路由携带appName')
  appConfig.appName = getParam('appName')
}

const appConfigParams = appConfig
export default appConfigParams
