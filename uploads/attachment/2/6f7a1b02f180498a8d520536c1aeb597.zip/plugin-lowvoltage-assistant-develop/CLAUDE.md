# Lowvoltage Assistant - Development Documentation

## Project Overview

A Vue2-based mobile application for low-voltage service assistance, designed to work in hybrid mode - can be built as a plugin library OR deployed as a standalone app.

## Project Structure

```
plugin-lowvoltage-assistant/
├── public/                 # Static assets
├── src/                    # Main application source
│   ├── assets/            # Static resources (images, styles)
│   │   └── less/          # LESS style files
│   │       └── var.less   # Theme variables
│   ├── components/        # Reusable Vue components
│   ├── views/             # Page-level components
│   ├── router/            # Vue Router configuration
│   ├── store/             # Vuex store modules
│   ├── utils/             # Utility functions
│   ├── App.vue            # Root component
│   └── main.js            # Application entry point
├── packages/               # Plugin library source (for lib build)
├── lib/                    # Built plugin library output
├── dist/                   # Built application output
├── dist_zip/               # Zipped distribution archives
├── .env.dev               # Development environment
├── .env.uat               # UAT environment
├── .env.prod              # Production environment
├── .env.site-prod         # Site-specific production environment
├── vue.config.js          # Vue CLI configuration
├── babel.config.js        # Babel configuration
└── jsconfig.json          # IDE path aliases
```

## Development Commands

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Build for UAT
npm run uat

# Build for site-specific production
npm run site:prod

# Build as plugin library
npm run lib
```

## Tech Stack

- **Framework**: Vue 2.6.x
- **Build Tool**: Vue CLI 4.5.x
- **UI Library**: Vant 2.x
- **State Management**: Vuex 3.x
- **Router**: Vue Router 3.x
- **CSS Preprocessor**: LESS
- **Mobile Adaptation**: lib-flexible + postcss-pxtorem (1rem = 37.5px)

## Path Aliases

- `@/` → `src/` - Main application source
- `#/` → `packages/` - Plugin library source

## Environment Variables

| Variable | Description |
|----------|-------------|
| `NODE_ENV` | Environment mode (development/production) |
| `VUE_APP_TYPE` | Build type (dev/uat/prod/site-prod) |
| `VUE_APP_PLATFORM` | Platform identifier (app) |

## Build Output

- **Application Build**: `dist/` directory + zipped archive in `dist_zip/`
- **Library Build**: `lib/` directory with UMD/CommonJS/ES modules

## IGW Integration

This project is designed to integrate with the IGW (Internal Gateway) platform as a micro-frontend plugin. The library build mode (`npm run lib`) produces a plugin bundle that can be loaded dynamically by the host application.

## Code Standards

- Use JavaScript (not TypeScript) for Vue2 compatibility
- Follow Vue2 Options API patterns
- Use Vant components for mobile UI
- Implement responsive design using px-to-rem conversion