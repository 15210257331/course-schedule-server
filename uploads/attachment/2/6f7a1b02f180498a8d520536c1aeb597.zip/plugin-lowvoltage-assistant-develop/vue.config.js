const FileManagerPlugin = require('filemanager-webpack-plugin')
const pxtorem = require('postcss-pxtorem')
const moment = require('moment')
const path = require('path')

const resolve = (dir) => path.join(__dirname, dir)

module.exports = {
  publicPath: './',
  productionSourceMap: false,
  parallel: false,
  devServer: {
    open: true
  },
  pages: {
    index: {
      entry: 'src/main.js',
      template: 'public/index.html',
      filename: 'index.html'
    }
  },
  transpileDependencies: ['*'],
  configureWebpack: (config) => {
    config.plugins.push(new FileManagerPlugin({
      events: {
        onEnd: {
          mkdir: ['./dist_zip'],
          archive: [{
            source: './dist',
            destination: `./dist_zip/${process.env.VUE_APP_TYPE}-${moment().format('MMDDHHmm')}.zip`
          }]
        }
      }
    }))
  },
  chainWebpack: (config) => {
    config.resolve.alias.set('@', path.resolve('src'))
    config.module.rule('js').include.add(resolve('src'))
    config.entry.app = resolve('./src/main.js')
  },
  css: {
    extract: true,
    loaderOptions: {
      postcss: {
        plugins: [pxtorem({ rootValue: 37.5, propList: ['*'] })]
      },
      less: {
        lessOptions: {
          modifyVars: {
            hack: `true; @import "./src/assets/less/var.less";`
          }
        }
      }
    }
  }
}